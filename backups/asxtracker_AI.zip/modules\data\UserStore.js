/**
 * UserStore.js
 * Handles real-time synchronization of user data (Shares and Cash) from Firestore.
 */

import { db } from '../auth/AuthService.js';
import { AppState } from '../state/AppState.js';
import { StateAuditor } from '../state/StateAuditor.js';
import { ToastManager } from '../ui/ToastManager.js';
import {
    collection,
    query,
    onSnapshot,
    addDoc,
    updateDoc,
    deleteDoc,
    doc,
    getDoc,
    getDocs,
    where,
    limit,
    serverTimestamp,
    arrayUnion,
    arrayRemove,
    setDoc
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";
import { ALL_SHARES_ID, PORTFOLIO_ID, SIMULATIONS_WATCHLIST_ID } from '../utils/AppConstants.js';

const APP_ID = "asx-watchlist-app";

export class UserStore {
    constructor() {
        this.unsubscribeShares = null;
        this.unsubscribeCash = null;
        this.unsubscribeWatchlists = null;
        this.unsubscribeDashboard = null;
        this.unsubscribeOverrides = null;
        this._lastPrefsJson = null; // Cache for deep equality checks
        this.isReady = false;
    }

    /**
     * Internal helper to handle write errors.
     * Triggers global reconnection flow if permission denied.
     */
    _handleWriteError(error, context) {
        if (error.code === 'permission-denied') {
            document.dispatchEvent(new CustomEvent('auth-reconnect-needed'));
        } else {
            console.error(`UserStore Error in ${context}:`, error);
            ToastManager.error(`Failed to save data: ${error.message}`);
        }
    }

    /**
     * Subscribes to changes in the user's shares and cash categories.
     * @param {string} userId - The current user's UID.
     * @param {function(Object): void} onDataChange - Callback invoked with { shares, cash } on updates.
     * @returns {function} Unsubscribe function to clean up listeners.
     */
    subscribe(userId, onDataChange) {
        if (!userId || !db) {
            return () => { };
        }

        this.isReady = false;

        const sharesRef = collection(db, `artifacts/${APP_ID}/users/${userId}/shares`);
        const cashRef = collection(db, `artifacts/${APP_ID}/users/${userId}/cashCategories`);
        const watchlistsRef = collection(db, `artifacts/${APP_ID}/users/${userId}/watchlists`);
        // Removed overridesRef - moving to preferences doc for rule-compliance

        // Helper to notify listener (DEBOUNCED via setTimeout)
        // Firestore fires onSnapshot for shares, cash, and watchlists independently.
        // Each fires in a separate setTimeout (Firestore internal scheduling), so
        // queueMicrotask cannot batch them. Using setTimeout with a 20ms window
        // batches all 3 into a SINGLE "DATA_UPDATED" event.
        let _notifyTimer = null;
        const notify = () => {
            if (_notifyTimer) clearTimeout(_notifyTimer);
            _notifyTimer = setTimeout(() => {
                _notifyTimer = null;
                this.isReady = true;
                AppState.isDataReady = true;

                // LEGACY: Keep onDataChange for now to prevent breakage during migration
                if (onDataChange) onDataChange(AppState.data);

                // REACTIVE BROADCST: Use semantic event bus
                StateAuditor.emit('DATA_UPDATED', AppState.data);
            }, 20); // 20ms window: enough to catch all 3 snapshots (~7ms apart)
        };

        // Subscribe to Shares
        this.unsubscribeShares = onSnapshot(query(sharesRef), (snapshot) => {
            const shares = [];
            snapshot.forEach((doc) => {
                shares.push({ ...doc.data(), id: doc.id });
            });
            AppState.data.shares = shares;
            notify();
        }, (error) => {
            if (error.code === 'permission-denied') return;
        });

        // Subscribe to Cash Categories
        this.unsubscribeCash = onSnapshot(query(cashRef), (snapshot) => {
            const cash = [];
            snapshot.forEach((doc) => {
                const d = doc.data();
                if (d.category === 'other') {
                }
                cash.push({ ...d, id: doc.id });
            });
            AppState.data.cash = cash;
            notify();
        }, (error) => {
            if (error.code === 'permission-denied') return;
        });

        // Subscribe to Watchlists
        this.unsubscribeWatchlists = onSnapshot(query(watchlistsRef), (snapshot) => {
            const watchlists = [];
            snapshot.forEach((doc) => {
                watchlists.push({ ...doc.data(), id: doc.id });
            });
            // Sort by creation time if available, or name
            watchlists.sort((a, b) => (a.createdAt?.seconds || 0) - (b.createdAt?.seconds || 0));

            AppState.data.watchlists = watchlists;
            notify();
        }, (error) => {
            if (error.code === 'permission-denied') return;
        });

        // Removed overrides snapshot - will be handled via Preferences subscription


        // Return cleanup function
        return () => {
            this.isReady = false;
            AppState.isDataReady = false;
            if (this.unsubscribeShares) this.unsubscribeShares();
            if (this.unsubscribeCash) this.unsubscribeCash();
            if (this.unsubscribeWatchlists) this.unsubscribeWatchlists();
            if (this.unsubscribeDashboard) this.unsubscribeDashboard();

            // ARCHITECTURAL REFINEMENT:
            // Do NOT aggressively clear AppState.data on unsubscribe.
            // This causes the "Flash of Death" if a re-subscription happens immediately (e.g. auth refresh).
            // Data will be overwritten by the next snapshot anyway.
        };
    }

    /**
     * Subscribes to the central User Preferences document.
     * Use this for Scanner Rules, Theme Settings, etc.
     * @param {string} userId 
     * @param {function(Object): void} onDataChange 
     * @returns {function} Unsubscribe function
     */
    subscribeToPreferences(userId, onDataChange) {
        if (!userId || !onDataChange) return () => { };

        const prefsRef = doc(db, `artifacts/${APP_ID}/users/${userId}/preferences/config`);
        return onSnapshot(prefsRef, (docSnap) => {
            if (docSnap.exists()) {
                const data = docSnap.data();
                // Extract overrides and put them in AppState
                AppState.data.dividendOverrides = data.dividendOverrides || {};
                onDataChange(data, docSnap.metadata);
            } else {
                onDataChange(null, docSnap.metadata);
            }
        }, (err) => {
        });
    }

    /**
     * Adds a new watchlist for the user.
     * @param {string} userId
     * @param {string} name
     * @param {boolean} excludeFromAll
     * @returns {Promise<string|null>} The new watchlist ID or null.
     */
    async addWatchlist(userId, name, excludeFromAll = false) {
        if (!userId || !name) return null;
        const watchlistsRef = collection(db, `artifacts/${APP_ID}/users/${userId}/watchlists`);
        try {
            const docRef = await addDoc(watchlistsRef, {
                name: name,
                excludeFromAll: !!excludeFromAll,
                createdAt: serverTimestamp()
            });
            return docRef.id;
        } catch (e) {
            return null;
        }
    }

    /**
     * Adds a new share to the user's collection.
     * @param {string} userId
     * @param {Object} shareData
     * @returns {Promise<string|null>} The new share ID or null.
     */
    async addShare(userId, shareData) {
        if (!userId || !shareData) return null;
        const sharesRef = collection(db, `artifacts/${APP_ID}/users/${userId}/shares`);

        // SERVER-SIDE DEDUPLICATION: Last line of defense against race conditions
        const symbol = (shareData.code || shareData.shareName || '').trim().toUpperCase();
        if (symbol) {
            try {
                const q = query(sharesRef, where('code', '==', symbol), limit(1));
                const snap = await getDocs(q);
                if (!snap.empty) {
                    const existingDoc = snap.docs[0];
                    return existingDoc.id;
                }
            } catch (err) {
            }
        }

        try {
            const dataToSave = this._sanitizeData({
                ...shareData,
                muted: shareData.muted ?? false,  // Ensure muted state is explicitly set
                createdAt: serverTimestamp()
            });

            const docRef = await addDoc(sharesRef, dataToSave);
            return docRef.id;
        } catch (e) {
            this._handleWriteError(e, 'addShare');
            throw e;
        }
    }

    /**
     * Strips redundant 'id' from the top-level object to prevent Firestore duplication,
     * but PRESERVES it for nested objects where 'id' is a semantic key (like category themes).
     * @param {Object} data 
     * @param {boolean} isNested - internal recursion flag
     * @returns {Object}
     */
    _sanitizeData(data, isNested = false) {
        if (data === undefined) return null;
        if (data === null || typeof data !== 'object') return data;

        if (Array.isArray(data)) {
            return data.map(item => this._sanitizeData(item, true));
        }

        const sanitized = {};
        Object.keys(data).forEach(key => {
            // ONLY strip 'id' if we are at the top level of a document save.
            // If we are inside an array or a nested object, the 'id' is likely 
            // a critical identifier (e.g. for User Categories or Stock IDs).
            if (!isNested && key === 'id') return;

            const value = data[key];
            if (value !== undefined) {
                sanitized[key] = this._sanitizeData(value, true);
            }
        });
        return sanitized;
    }

    /**
     * Updates a share in the user's collection.
     */
    async updateShare(userId, shareId, data) {
        if (!userId || !shareId || !data) return;
        const shareRef = doc(db, `artifacts/${APP_ID}/users/${userId}/shares`, shareId);

        const sanitizedData = this._sanitizeData({
            ...data,
            updatedAt: serverTimestamp()
        });

        try {
            await updateDoc(shareRef, sanitizedData);
        } catch (e) {
            if (e.code === 'not-found' || e.message.includes('No document to update')) {
                // Resurrect: Use setDoc to recreate with same ID (preserve references)
                try {
                    const fullData = this._sanitizeData({
                        ...data,
                        createdAt: serverTimestamp(),
                        updatedAt: serverTimestamp()
                    });
                    await setDoc(shareRef, fullData);
                } catch (resurrectError) {
                    this._handleWriteError(resurrectError, 'updateShare-Resurrect');
                    throw resurrectError;
                }
            } else {
                this._handleWriteError(e, 'updateShare');
                throw e;
            }
        }
    }

    /**
     * Adds a new cash asset category.
     * @param {string} userId 
     * @param {Object} data - { name, balance, category }
     */
    async addCashCategory(userId, data) {
        if (!userId || !data) throw new Error("Missing userId or data");
        const ref = collection(db, `artifacts/${APP_ID}/users/${userId}/cashCategories`);
        const docRef = await addDoc(ref, {
            ...data,
            updatedAt: serverTimestamp()
        });
        return docRef.id;
    }

    /**
     * Updates an existing cash asset.
     * @param {string} userId 
     * @param {string} assetId 
     * @param {Object} data - { name, balance, category }
     */
    async updateCashCategory(userId, assetId, data) {
        if (!userId || !assetId || !data) throw new Error("Missing userId, assetId, or data");
        const ref = doc(db, `artifacts/${APP_ID}/users/${userId}/cashCategories`, assetId);
        await updateDoc(ref, {
            ...data,
            updatedAt: serverTimestamp()
        });
    }

    /**
     * Deletes a cash asset.
     * @param {string} userId 
     * @param {string} assetId 
     */
    async deleteCashCategory(userId, assetId) {
        if (!userId || !assetId) throw new Error("Missing userId or assetId");
        const ref = doc(db, `artifacts/${APP_ID}/users/${userId}/cashCategories`, assetId);
        await deleteDoc(ref);
    }

    /**
     * Deletes a share from the user's collection.
     * @param {string} userId
     * @param {string} shareId
     */
    async deleteShare(userId, shareId) {
        if (!userId || !shareId) return;
        const shareRef = doc(db, `artifacts/${APP_ID}/users/${userId}/shares`, shareId);
        try {
            await deleteDoc(shareRef);
        } catch (e) {
        }
    }

    /**
     * Updates local sort preference for a watchlist.
     * @param {string} userId 
     * @param {string} watchlistId 
     * @param {Object} sortConfig { field: 'name'|'price'|'change', direction: 'asc'|'desc' }
     */
    async updateWatchlistSort(userId, watchlistId, sortConfig) {
        if (!userId || !watchlistId || !sortConfig) return;

        // SYSTEM GUARD: Never attempt to save sort to virtual system watchlists (No doc exists)
        const systemIds = [ALL_SHARES_ID, PORTFOLIO_ID, 'search', 'ALL', 'portfolio', SIMULATIONS_WATCHLIST_ID];
        if (systemIds.includes(watchlistId)) return;

        try {
            const ref = doc(db, `artifacts/${APP_ID}/users/${userId}/watchlists`, watchlistId);
            await updateDoc(ref, {
                sortConfig: sortConfig,
                updatedAt: serverTimestamp()
            });
        } catch (e) {
        }
    }

    /**
     * Updates the name or other metadata of a watchlist.
     * @param {string} userId 
     * @param {string} watchlistId 
     * @param {Object} updates 
     */
    async updateWatchlist(userId, watchlistId, updates) {
        if (!userId || !watchlistId || !updates) return;
        const ref = doc(db, `artifacts/${APP_ID}/users/${userId}/watchlists`, watchlistId);
        try {
            await updateDoc(ref, {
                ...updates,
                updatedAt: serverTimestamp()
            });
        } catch (e) {
        }
    }

    /**
     * Renames a watchlist. (Alias for updateWatchlist targeting 'name')
     * @param {string} userId
     * @param {string} watchlistId
     * @param {string} newName
     */
    async renameWatchlist(userId, watchlistId, newName) {
        return this.updateWatchlist(userId, watchlistId, { name: newName });
    }

    /**
     * Provisions a new user document if it doesn't exist.
     * @param {string} userId 
     */
    async provisionUser(userId) {
        if (!userId) return;
        const userRef = doc(db, `artifacts/${APP_ID}/users/${userId}`);
        try {
            const snap = await getDoc(userRef); // Requires getDoc import if not present
            if (!snap.exists()) {
                await setDoc(userRef, {
                    createdAt: serverTimestamp(),
                    lastLogin: serverTimestamp()
                });
            } else {
                // Update last login (Non-blocking race avoidance)
                try {
                    await updateDoc(userRef, { lastLogin: serverTimestamp() });
                } catch (err) {
                }
            }
        } catch (e) {
        }
    }

    /**
     * Removes a stock from a specific watchlist.
     * @param {string} userId 
     * @param {string} watchlistId 
     * @param {string} code 
     */
    async removeStock(userId, watchlistId, code) {
        if (!userId || !watchlistId || !code) return;
        const codeUpper = code.toUpperCase();

        try {
            // 1. Scrub Master Share Documents (Most common)
            const ref = collection(db, `artifacts/${APP_ID}/users/${userId}/shares`);

            // We look for any documents where the code matches
            // We can't query array-contains and equality on another field easily without composite indexes
            // but we can query by name and filter locally or just use multiple queries for backwards compatibility
            const q = query(ref, where("shareName", "==", codeUpper));
            const snap = await getDocs(q);

            for (const d of snap.docs) {
                const data = d.data();
                const watchlistIds = data.watchlistIds || [];
                const legacyId = data.watchlistId;

                // Case A: Legacy match (Exact match on singular property)
                if (legacyId === watchlistId) {
                    await deleteDoc(d.ref);
                    continue;
                }

                // Case B: Array match
                if (watchlistIds.includes(watchlistId)) {
                    if (watchlistIds.length <= 1 && !data.portfolioShares) {
                        // Last home and no holdings? Delete it.
                        await deleteDoc(d.ref);
                    } else {
                        // Just unlink it
                        await updateDoc(d.ref, {
                            watchlistIds: arrayRemove(watchlistId),
                            updatedAt: serverTimestamp()
                        });
                    }
                }
            }

            // 2. Scrub Watchlist "stocks" arrays (New Architecture Support)
            // Some watchlists store their stock codes in a 'stocks' array on the watchlist doc itself.
            const wlRef = doc(db, `artifacts/${APP_ID}/users/${userId}/watchlists`, watchlistId);
            try {
                // We use arrayRemove on both the code AND the id in case both are used
                await updateDoc(wlRef, {
                    stocks: arrayRemove(codeUpper),
                    updatedAt: serverTimestamp()
                });
            } catch (wlErr) {
                // Might fail if system watchlist (no doc) or array doesn't exist; safe to ignore.
            }

        } catch (e) {
            console.error("UserStore: Error removing stock from watchlist:", e);
        }
    }

    /**
     * Determines if a stock code should be excluded from the global All Shares view.
     * Excluded if the code exists solely in watchlists that have excludeFromAll === true.
     * @param {string} code 
     * @param {Array} allShares 
     * @param {Array} watchlists 
     * @returns {boolean}
     */
    isShareExcludedFromGlobal(code, allShares, watchlists) {
        if (!code) return false;
        const codeUpper = code.trim().toUpperCase();

        // Find all matching share documents in user's shares
        const matches = allShares.filter(s => 
            (s.shareName || s.code || '').trim().toUpperCase() === codeUpper
        );

        if (matches.length === 0) return false;

        // Check if any match is in the portfolio (units > 0)
        const inPortfolio = matches.some(s => 
            (parseFloat(s.portfolioShares) || parseFloat(s.units) || parseFloat(s.owned) || 0) > 0
        );
        if (inPortfolio) return false;

        // Collect all watchlist IDs where these matches belong
        const watchlistIds = new Set();
        matches.forEach(s => {
            if (Array.isArray(s.watchlistIds)) {
                s.watchlistIds.forEach(id => watchlistIds.add(String(id)));
            }
            if (s.watchlistId) {
                watchlistIds.add(String(s.watchlistId));
            }
        });

        // If it's not in any watchlists, don't exclude it
        if (watchlistIds.size === 0) return false;

        // Check if ALL watchlists it belongs to are excluded
        const systemIds = ['ALL', 'PORTFOLIO', 'CASH', 'DASHBOARD', 'SIMULATIONS', 'SEARCH', 'portfolio'];
        
        for (const wId of watchlistIds) {
            // If it's in a system watchlist, it is a non-excluded view
            if (systemIds.includes(wId.toUpperCase()) || wId.toLowerCase() === 'portfolio') {
                return false;
            }

            // Find the custom watchlist
            const wl = watchlists.find(w => w.id === wId);
            // If watchlist is not found or is NOT marked as excluded, then the stock is not solely in excluded watchlists
            if (!wl || wl.excludeFromAll !== true) {
                return false;
            }
        }

        // Exclude since it is only in watchlists marked as excluded
        return true;
    }

    /**
     * Retrieves specific shares for a given watchlist.
     * Logic: If ALL_SHARES_ID, return all. If Portfolio, return own.
     * If specific Watchlist ID, filter logic needed (Architecture dependent).
     * Based on AppService usage, it likely filters the *provided list* of shares,
     * OR fetches subcollection.
     * Re-implementing based on "Zero-Cost" architecture suggestions:
     * AppService passes (shares, watchlistId), so this is a FILTER function.
     */
    getWatchlistData(shares, watchlistId) {
        if (!shares || !Array.isArray(shares)) return [];

        // 1. ALL SHARES: Return everything except excluded curiosity codes
        if (!watchlistId || watchlistId === ALL_SHARES_ID) {
            const watchlists = AppState.data?.watchlists || [];
            return shares.filter(s => {
                const code = s.shareName || s.code;
                return !this.isShareExcludedFromGlobal(code, shares, watchlists);
            });
        }

        // 1.5. SIMULATIONS WATCHLIST: Return shares marked as simulated
        if (watchlistId === SIMULATIONS_WATCHLIST_ID) {
            return shares.filter(s => s.isSimulated === true || s.simulatedActive === true);
        }

        // 2. FILTER LOGIC (Portfolio + Custom)
        // The 'shares' array contains ALL tracked items (owned + watched).
        // We must filter for items that contain the requested watchlistId in their 'watchlistIds' array.
        // This fixes:
        // - Portfolio showing unowned items (was bypassing filter)
        // - Custom watchlists showing nothing (was checking non-existent single 'watchlistId' prop)

        return shares.filter(s => {
            // SPECIAL CASE: Portfolio view includes any share with owned units (shares > 0)
            if (watchlistId === PORTFOLIO_ID) {
                const units = parseFloat(s.portfolioShares) || 0;
                if (units > 0) return true;
                // Continue to check if it's explicitly in the 'portfolio' watchlist too
            }

            // Robustness: Handle array (standard), single string (legacy), or missing
            if (Array.isArray(s.watchlistIds)) {
                return s.watchlistIds.includes(watchlistId);
            }
            if (s.watchlistId === watchlistId) {
                return true; // Legacy fallback
            }
            return false;
        });
    }

    /**
     * Adds a stock to a specific watchlist.
     * @param {string} userId 
     * @param {string} watchlistId 
     * @param {string} symbol 
     * @param {number} price 
     * @param {string} timestamp 
     */
    async addStock(userId, watchlistId, symbol, price, timestamp, explicitDocId = null) {
        if (!userId || !watchlistId || !symbol) return;

        // FIX: Check for existing share first to prevent duplicates (Link Mode)
        const shares = AppState.data.shares || [];

        let existingId = explicitDocId;
        let existing = null;

        if (existingId) {
            // Verify it exists in memory for legacy check (optional but good for consistency)
            existing = shares.find(s => s.id === existingId);
        } else {
            // FIX: Robust Case-Insensitive Lookup to prevent duplicates
            const symbolUpper = (symbol || '').trim().toUpperCase();
            existing = shares.find(s =>
                (s.shareName || '').trim().toUpperCase() === symbolUpper ||
                (s.code || '').trim().toUpperCase() === symbolUpper
            );

            if (existing) {
                existingId = existing.id;
            }
        }

        if (existingId) {
            const ref = doc(db, `artifacts/${APP_ID}/users/${userId}/shares`, existingId);

            // Migration: Ensure the legacy singular 'watchlistId' is included in the new array
            const idsToUnion = [watchlistId];
            if (existing && existing.watchlistId) idsToUnion.push(existing.watchlistId);

            try {
                await updateDoc(ref, {
                    watchlistIds: arrayUnion(...idsToUnion),
                    updatedAt: serverTimestamp()
                });
                return existing.id;
            } catch (e) {
                // FIX: Handle Ghost Share (Exists in AppState but not in DB)
                if (e.code === 'not-found' || e.message.includes('No document to update')) {
                    // Fallback to Create New Logic (below)
                } else {
                    return null;
                }
            }
        }

        // Fallback: Create New (Primary Record)
        return this.addShare(userId, {
            code: symbol,
            shareName: symbol,
            watchlistId: watchlistId,
            watchlistIds: [watchlistId], // Initialize Array
            purchasePrice: price,
            purchaseDate: timestamp,
            units: 0,
            muted: false  // Initialize mute state
        });
    }

    /**
     * Deletes a watchlist and all associated metadata.
     * Note: Does NOT delete shares inside it (Shares are in subcollection 'shares' linked by ID, or separate logic).
     * Based on architecture, shares are independent.
     * @param {string} userId 
     * @param {string} watchlistId 
     */
    async deleteWatchlist(userId, watchlistId) {
        if (!userId || !watchlistId) return;
        const ref = doc(db, `artifacts/${APP_ID}/users/${userId}/watchlists`, watchlistId);
        try {
            await deleteDoc(ref);
        } catch (e) {
            console.error("UserStore: Error deleting watchlist:", e);
        }
    }

    // --- GENERIC HELPERS ---

    /**
     * Generic fetch for any subcollection.
     * @param {string} userId 
     * @param {string} collectionName 
     */
    async getAllDocuments(userId, collectionName) {
        const ref = collection(db, `artifacts/${APP_ID}/users/${userId}/${collectionName}`);
        const snap = await getDocs(ref);
        const results = [];
        snap.forEach(doc => results.push({ id: doc.id, ...doc.data() }));
        return results;
    }

    /**
     * Fetches recorded portfolio history snapshots.
     * @param {string} userId 
     */
    async getHistorySnapshots(userId) {
        if (!userId) return [];
        const ref = collection(db, `artifacts/${APP_ID}/users/${userId}/history`);
        const q = query(ref); // Newest first is handled by UI sorting if needed
        const snap = await getDocs(q);
        const results = [];
        snap.forEach(doc => results.push({ id: doc.id, ...doc.data() }));
        return results;
    }

    /**
     * One-time database scrub routine: Detects and deletes corrupted out-of-hours snapshots from Firestore.
     * @param {string} userId
     * @returns {Promise<{ scanned: number, deleted: number, deletedRecords: Array }>}
     */
    async cleanCorruptedHistorySnapshots(userId) {
        if (!userId) return { scanned: 0, deleted: 0, deletedRecords: [] };
        const ref = collection(db, `artifacts/${APP_ID}/users/${userId}/history`);
        const snap = await getDocs(query(ref));
        const docs = [];
        snap.forEach(docSnap => {
            docs.push({ id: docSnap.id, docId: docSnap.id, ...docSnap.data() });
        });

        const { ChartDataSanitizer } = await import('../utils/ChartDataSanitizer.js');
        const corrupted = ChartDataSanitizer.identifyCorruptedSnapshotDocs(docs);

        const deletedRecords = [];
        for (const item of corrupted) {
            if (item.id) {
                try {
                    const docRef = doc(db, `artifacts/${APP_ID}/users/${userId}/history`, item.id);
                    await deleteDoc(docRef);
                    deletedRecords.push(item);
                } catch (e) {
                    console.error('[UserStore] Failed to delete corrupted snapshot:', item.id, e);
                }
            }
        }

        return {
            scanned: docs.length,
            deleted: deletedRecords.length,
            deletedRecords
        };
    }

    /**
     * Generic document addition with metadata.
     */
    async addDocument(userId, collectionName, data) {
        if (!userId || !collectionName || !data) return null;
        const ref = collection(db, `artifacts/${APP_ID}/users/${userId}/${collectionName}`);
        try {
            const dataToSave = this._sanitizeData({
                ...data,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            });
            const docRef = await addDoc(ref, dataToSave);
            return docRef.id;
        } catch (e) {
            return null;
        }
    }

    async updateDocument(userId, collectionName, docId, data) {
        if (!userId || !collectionName || !docId || !data) return;
        const ref = doc(db, `artifacts/${APP_ID}/users/${userId}/${collectionName}`, docId);

        const sanitizedData = this._sanitizeData({
            ...data,
            updatedAt: serverTimestamp()
        });

        try {
            await updateDoc(ref, sanitizedData);
        } catch (e) {
            // FIX: Handle Ghost Document Resurrect
            if (e.code === 'not-found' || e.message.includes('No document to update')) {
                const fullData = this._sanitizeData({
                    ...data,
                    createdAt: serverTimestamp(),
                    updatedAt: serverTimestamp()
                });
                await setDoc(ref, fullData);
            } else {
                throw e;
            }
        }
    }

    async deleteDocument(userId, collectionName, docId) {
        const ref = doc(db, `artifacts/${APP_ID}/users/${userId}/${collectionName}`, docId);
        await deleteDoc(ref);
    }

    /**
     * Saves user preferences (Scanner Rules, UI Settings) to a central config doc.
     * @param {string} userId
     * @param {Object} data
     */
    async savePreferences(userId, data) {
        if (!userId || !data) {
            console.warn('UserStore: savePreferences blocked - missing userId or data');
            return;
        }
        const docRef = doc(db, `artifacts/${APP_ID}/users/${userId}/preferences/config`);
        try {
            // Sanitize data to remove undefined values which Firestore does not support
            const sanitizedData = this._sanitizeData(data);

            await setDoc(docRef, {
                ...sanitizedData,
                modified: data.modified || Date.now(),
                updatedAt: serverTimestamp()
            }, { merge: true });

        } catch (e) {
            this._handleWriteError(e, 'savePreferences');
            throw e;
        }
    }

    /**
     * EMERGENCY: Deletes all user documents in known sub-collections.
     * @param {string} userId 
     */
    async wipeAllData(userId) {
        if (!userId) return;

        const subCollections = ['shares', 'cashCategories', 'watchlists', 'preferences'];
        const results = [];

        for (const colName of subCollections) {
            const docs = await this.getAllDocuments(userId, colName);

            const deletePromises = docs.map(async (d) => {
                try {
                    await this.deleteDocument(userId, colName, d.id);
                    return { id: d.id, collection: colName, status: 'deleted' };
                } catch (err) {
                    return { id: d.id, collection: colName, status: 'failed', error: err.message };
                }
            });

            const collectionResults = await Promise.allSettled(deletePromises);
            results.push(...collectionResults);
        }

        return results;
    }

    /**
     * Saves a manual dividend override for a ticker.
     * Pivot: Saves into the preferences/config document to bypass rule restrictions.
     */
    async saveDividendOverride(userId, ticker, data) {
        if (!userId || !ticker) return { ok: false, error: 'Missing params' };
        const ref = doc(db, `artifacts/${APP_ID}/users/${userId}/preferences/config`);
        try {
            // Nest the data under a 'dividendOverrides' map
            const update = {
                [`dividendOverrides.${ticker.toUpperCase()}`]: {
                    ...data,
                    updatedAt: Date.now()
                }
            };
            await updateDoc(ref, update).catch(async (err) => {
                 // Fallback if preferences doc doesn't exist
                 if (err.code === 'not-found') {
                     await setDoc(ref, { dividendOverrides: { [ticker.toUpperCase()]: data } }, { merge: true });
                 } else throw err;
            });
            return { ok: true };
        } catch (e) {
            this._handleWriteError(e, 'saveDividendOverride');
            return { ok: false, error: e.message };
        }
    }
}
