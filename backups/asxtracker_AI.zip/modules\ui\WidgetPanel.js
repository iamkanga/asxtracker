/**
 * WidgetPanel.js
 * Renders the configurable Widget Panel surface.
 * Consumes data from AppState and NotificationStore.
 *
 * DESIGN NOTE: Cash items with category === 'shares' are EXCLUDED from cash
 * calculations to prevent double-counting (they mirror AppState.data.shares).
 * This matches PortfolioChartUI.js logic.
 */
import { AppState } from '../state/AppState.js';
import { notificationStore } from '../state/NotificationStore.js';
import { StateAuditor } from '../state/StateAuditor.js';
import { CSS_CLASSES, IDS, EVENTS, UI_ICONS, UI_LABELS, DASHBOARD_SYMBOLS, DASHBOARD_LINKS, CASH_WATCHLIST_ID } from '../utils/AppConstants.js';
import { formatCurrency, formatPercent } from '../utils/formatters.js';
import { LinkHelper } from '../utils/LinkHelper.js';
import { MarketSchedule } from '../utils/MarketSchedule.js';
import { convertAssetToAud } from '../utils/CurrencyHelper.js';

export const WIDGET_MODULES = [
    { id: 'day_performance', label: 'Day Performance', description: "Today's portfolio gain/loss detail", icon: 'fa-calendar-day', renderer: '_renderDayPerformance', default: true },
    { id: 'dashboard_snapshot', label: 'Dashboard Snapshot', description: 'Live indexes, currencies & commodities', icon: 'fa-globe', renderer: '_renderDashboardSnapshot', default: true },
    { id: 'portfolio_summary', label: 'Wealth Summary', description: 'Total wealth: Shares, Super, Cash & Assets', icon: 'fa-wallet', renderer: '_renderPortfolioSummary', default: true },
    { id: 'market_movers', label: 'Market Movers', description: 'Top 6 biggest movers on the ASX', icon: 'fa-rocket', renderer: '_renderMarketMovers', default: true },
    { id: 'active_targets', label: 'Active Target Alerts', description: 'Configured price targets and distances', icon: 'fa-crosshairs', renderer: '_renderActiveTargets', default: true },
    { id: 'notifications', label: 'Latest Alerts', description: 'Most recent price alerts & notifications', icon: 'fa-bell', renderer: '_renderNotifications', default: true },
    { id: 'top_movers', label: 'Watchlist Movers', description: 'Top daily % movers in your portfolio', icon: 'fa-bolt', renderer: '_renderTopMovers', default: false },
    { id: 'top_holdings', label: 'Top Holdings', description: 'Your largest positions by value', icon: 'fa-trophy', renderer: '_renderTopHoldings', default: false },
    { id: 'cash_breakdown', label: 'Cash & Assets', description: 'Breakdown of non-share assets', icon: 'fa-piggy-bank', renderer: '_renderCashBreakdown', default: false },
    { id: 'watchlist_summary', label: 'Watchlists', description: 'Quick view of your watchlists', icon: 'fa-list', renderer: '_renderWatchlistSummary', default: false },
    { id: 'market_snapshot', label: 'Market Snapshot', description: 'ASX 200 index overview', icon: 'fa-chart-line', renderer: '_renderMarketSnapshot', default: false }
];

// Dashboard name map for readable labels
const DASHBOARD_NAMES = {
    '^GSPC': 'S&P 500', '^DJI': 'Dow Jones', '^IXIC': 'Nasdaq',
    '^FTSE': 'FTSE 100', '^N225': 'Nikkei 225', '^HSI': 'Hang Seng',
    '^STOXX50E': 'Euro Stoxx 50', '^AXJO': 'ASX 200', '^AORD': 'All Ords',
    '^VIX': 'VIX', 'XJO': 'ASX 200', 'XKO': 'ASX 300',
    'GC=F': 'Gold', 'SI=F': 'Silver', 'CL=F': 'Crude Oil',
    'BZ=F': 'Brent Oil', 'HG=F': 'Copper', 'TIO=F': 'Iron Ore',
    'BTC-USD': 'BTC/USD', 'BTC-AUD': 'BTC/AUD',
    'AUDUSD=X': 'AUD/USD', 'AUDGBP=X': 'AUD/GBP', 'AUDEUR=X': 'AUD/EUR',
    'AUDJPY=X': 'AUD/JPY', 'AUDTHB=X': 'AUD/THB', 'AUDNZD=X': 'AUD/NZD',
    'USDTHB=X': 'USD/THB', 'YAP=F': 'SPI 200', 'NICKEL': 'Nickel',
    'XAUUSD=X': 'Gold Spot', 'XAGUSD=X': 'Silver Spot',
    'COMMODITIES': 'Commodities'
};

// Categorize dashboard symbols for smart formatting
const INDEX_SYMBOLS = new Set([
    '^AXJO', '^AORD', '^GSPC', '^DJI', '^IXIC', '^FTSE', '^N225', '^HSI',
    '^STOXX50E', '^VIX', 'XJO', 'XKO', 'XAO', 'YAP=F'
]);
const CURRENCY_SYMBOLS = new Set([
    'AUDUSD=X', 'AUDGBP=X', 'AUDEUR=X', 'AUDJPY=X', 'AUDTHB=X', 'AUDNZD=X',
    'USDTHB=X', 'XAUUSD=X', 'XAGUSD=X'
]);

export class WidgetPanel {
    constructor() {
        this.container = null;
        this.overlay = null;
        this.isInitialized = false;
    }

    init(container) {
        if (this.isInitialized) return;
        this.container = container;
        this.container.classList.add(CSS_CLASSES.WIDGET_PANEL);
        this.container.classList.add(CSS_CLASSES.WIDGET_HIDDEN);

        this._setupOverlay();

        this.isInitialized = true;
        this._bindEvents();
    }

    _setupOverlay() {
        if (this.overlay) return;
        this.overlay = document.createElement('div');
        this.overlay.id = IDS.WIDGET_OVERLAY;
        this.overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(4px);
            -webkit-backdrop-filter: blur(4px);
            z-index: 19999;
            display: none;
            opacity: 0;
            transition: opacity 0.3s ease, visibility 0.3s;
            pointer-events: auto;
            visibility: hidden;
        `;
        this.overlay.addEventListener('click', () => {
            this.toggle();
        });
        document.body.appendChild(this.overlay);
    }

    _bindEvents() {
        document.addEventListener(EVENTS.REFRESH_WATCHLIST, () => this.render());
        document.addEventListener(EVENTS.NOTIFICATION_UPDATE, () => this.render());
        document.addEventListener(EVENTS.WIDGET_CONFIG_CHANGED, () => this.render());

        // Reactive price updates: refresh distances and cards when prices tick
        StateAuditor.on(EVENTS.PRICES_UPDATED, () => {
            if (this.container && !this.container.classList.contains(CSS_CLASSES.WIDGET_HIDDEN)) {
                this.render();
            }
        });
        document.addEventListener(EVENTS.PRICES_UPDATED, () => {
            if (this.container && !this.container.classList.contains(CSS_CLASSES.WIDGET_HIDDEN)) {
                this.render();
            }
        });

        // Keyboard support (Escape to close)
        window.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.container && !this.container.classList.contains(CSS_CLASSES.WIDGET_HIDDEN)) {
                this.toggle();
            }
        });
    }

    toggle() {
        if (!this.container) {
            return;
        }

        const isHidden = this.container.classList.toggle(CSS_CLASSES.WIDGET_HIDDEN);

        if (!isHidden) {
            // OPENING
            if (this.overlay) {
                this.overlay.style.display = 'block';
                requestAnimationFrame(() => {
                    this.overlay.style.opacity = '1';
                    this.overlay.style.visibility = 'visible';
                });
            }

            document.body.appendChild(this.container);
            this.container.style.display = 'flex';
            this.container.style.visibility = 'visible';
            this.container.style.opacity = '1';
            
            this.render();
        } else {
            // CLOSING
            if (this.overlay) {
                this.overlay.style.opacity = '0';
                this.overlay.style.visibility = 'hidden';
                setTimeout(() => {
                    if (this.container.classList.contains(CSS_CLASSES.WIDGET_HIDDEN)) {
                        this.overlay.style.display = 'none';
                    }
                }, 300);
            }

            setTimeout(() => {
                if (this.container.classList.contains(CSS_CLASSES.WIDGET_HIDDEN)) {
                    this.container.style.display = 'none';
                }
            }, 300);
        }
    }

    render() {
        if (!this.container) return;
        if (this.container.classList.contains(CSS_CLASSES.WIDGET_HIDDEN)) {
            return;
        }

        const scrollContainer = this.container.querySelector('.widget-scroll-container');
        const prevScroll = scrollContainer ? scrollContainer.scrollTop : 0;

        const config = AppState.preferences?.widgetConfig || this._getDefaultConfig();
        const stats = this._getPortfolioStats();
        const dateOptions = { weekday: 'long', month: 'long', day: 'numeric' };
        const dateStr = new Date().toLocaleDateString('en-AU', dateOptions);

        const getIndexHtml = (code, fallbackCode) => {
            const item = AppState.livePrices?.get(code) || AppState.livePrices?.get(fallbackCode) || { pctChange: 0 };
            const pct = item.pctChange || 0;
            const isUp = pct >= 0;
            const colorVar = isUp ? 'var(--color-positive)' : 'var(--color-negative)';
            return `<span style="color: ${colorVar} !important; font-weight: 700;">${isUp ? '+' : ''}${pct.toFixed(2)}%</span>`;
        };

        const asxHtml = getIndexHtml('^AXJO', 'XJO');
        const spxHtml = getIndexHtml('^GSPC', 'INX');
        const portHtml = `<span style="color: ${stats.isUp ? 'var(--color-positive)' : 'var(--color-negative)'} !important; font-weight: 700;">${stats.isUp ? '+' : ''}${stats.dayPct.toFixed(2)}%</span>`;

        // Styles for deep gradients
        const positiveGradient = 'linear-gradient(135deg, rgba(6, 255, 79, 0.45) 0%, rgba(10, 10, 12, 1) 100%)';
        const negativeGradient = 'linear-gradient(135deg, rgba(255, 49, 49, 0.45) 0%, rgba(10, 10, 12, 1) 100%)';
        const activeGradient = stats.isUp ? positiveGradient : negativeGradient;

        let html = `
            <!-- HEADER -->
            <div class="${CSS_CLASSES.BRIEFING_HEADER}" style="padding: 24px 20px 10px 20px; background: linear-gradient(to bottom, rgba(0,0,0,0.4), transparent);">
                <div class="${CSS_CLASSES.BRIEFING_TITLE_ROW}" style="display: flex; justify-content: space-between; align-items: center;">
                    <h1 style="font-size: 1.6rem; margin: 0; font-weight: 700; color: #fff;">${this._getGreeting()}</h1>
                    <div style="display: flex; gap: 4px; align-items: center;">
                        <button class="${CSS_CLASSES.VISUAL_BTN}" id="${IDS.WIDGET_SETTINGS_TRIGGER}" title="Settings" style="background: transparent; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border: none; color: rgba(255,255,255,0.6); cursor: pointer; font-size: 1.1rem;">
                            <i class="fas ${UI_ICONS.COG}"></i>
                        </button>
                        <button class="${CSS_CLASSES.MODAL_CLOSE_BTN}" id="${IDS.WIDGET_CLOSE_TRIGGER}" title="Close" style="background: transparent; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border: none; color: rgba(255,255,255,0.6); cursor: pointer; font-size: 1.1rem;">
                            <i class="fas ${UI_ICONS.CLOSE}"></i>
                        </button>
                    </div>
                </div>
                <div class="${CSS_CLASSES.BRIEFING_DATE}" style="margin-top: 4px; opacity: 0.6; font-size: 0.8rem; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">${dateStr}</div>
            </div>

            <div class="${CSS_CLASSES.W_FULL} widget-scroll-container" style="flex: 1; overflow-y: auto; padding-bottom: 30px;">
                ${(AppState.health?.status === 'stale' || AppState.health?.status === 'offline' || (typeof navigator !== 'undefined' && !navigator.onLine)) ? `
                    <div class="${CSS_CLASSES.WIDGET_WARNING_BANNER}" style="margin: 0 16px 8px 16px; padding: 8px 12px; background: rgba(255, 179, 0, 0.15); border: 1px solid rgba(255, 179, 0, 0.4); border-radius: 6px; color: #ffb300; font-size: 0.75rem; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                        <i class="fas fa-triangle-exclamation"></i>
                        <span>Quotes may be delayed or offline</span>
                    </div>
                ` : ''}
        `;

        // 2. DYNAMIC MODULES
        const activeModules = WIDGET_MODULES
            .filter(module => {
                const userPref = config.find(c => c.id === module.id);
                return userPref ? userPref.visible : module.default;
            })
            .sort((a, b) => {
                const indexA = config.findIndex(c => c.id === a.id);
                const indexB = config.findIndex(c => c.id === b.id);
                if (indexA === -1 && indexB === -1) return 0;
                if (indexA === -1) return 1;
                if (indexB === -1) return -1;
                return indexA - indexB;
            });

        html += activeModules.map((module, index) => {
            // Check if this module should be promoted to Hero (only if it's first and hero-capable)
            const isHeroCandidate = ['portfolio_summary', 'day_performance'].includes(module.id);
            const shouldBeHero = isHeroCandidate && index === 0;

            if (shouldBeHero) {
                return `
                    <div class="${CSS_CLASSES.WIDGET_SECTION_WRAPPER}" style="padding: 12px 16px;">
                        <div class="${CSS_CLASSES.WIDGET_HERO_CARD} ${stats.isUp ? 'is-up' : 'is-down'}" id="${IDS.WIDGET_PORTFOLIO_HERO}" 
                             style="width: 100%; min-height: auto; padding: 18px; background: ${activeGradient}; box-shadow: 0 4px 20px rgba(0,0,0,0.4); cursor: pointer; border: none !important;">
                            
                            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px;">
                                <div style="display: flex; align-items: center; gap: 6px; font-size: 0.75rem; letter-spacing: 1.5px; color: rgba(255,255,255,0.8); font-weight: 800; margin-top: 2px;">
                                    ASX TRACKER <img src="gemini-icon.png" style="width: 14px; height: 14px;">
                                </div>
                                <div style="display: flex; flex-direction: column; gap: 6px; align-items: flex-end;">
                                    <div style="display: flex; align-items: center; justify-content: flex-end; gap: 8px;">
                                        <span style="font-size: 0.75rem; color: rgba(255,255,255,0.6); font-weight: 700; text-transform: uppercase;">ASX 200</span>
                                        <span style="font-size: 0.9rem; min-width: 65px; text-align: right;">${asxHtml}</span>
                                    </div>
                                    <div style="display: flex; align-items: center; justify-content: flex-end; gap: 8px;">
                                        <span style="font-size: 0.75rem; color: rgba(255,255,255,0.6); font-weight: 700; text-transform: uppercase;">S&P 500</span>
                                        <span style="font-size: 0.9rem; min-width: 65px; text-align: right;">${spxHtml}</span>
                                    </div>
                                    <div style="display: flex; align-items: center; justify-content: flex-end; gap: 8px;">
                                        <span style="font-size: 0.75rem; color: rgba(255,255,255,0.6); font-weight: 700; text-transform: uppercase;">Portfolio</span>
                                        <span style="font-size: 0.9rem; min-width: 65px; text-align: right;">${portHtml}</span>
                                    </div>
                                </div>
                            </div>

                            <div style="display: flex; flex-direction: column; align-items: flex-start; text-align: left; padding: 5px 0 0 0; width: 100%;">
                                <div style="display: flex; align-items: center; gap: 6px; font-size: 0.75rem; color: rgba(255,255,255,0.6); font-weight: 700; text-transform: uppercase; margin-bottom: 4px;">
                                    <i class="fas ${module.icon}" style="font-size: 0.75rem; opacity: 0.8;"></i>
                                    <span>${module.label}</span>
                                </div>
                                <div style="font-size: 2.1rem; font-weight: 800; color: #fff; line-height: 1.1; margin-bottom: ${module.id === 'portfolio_summary' ? '8px' : '12px'};">
                                    ${module.id === 'portfolio_summary' ? formatCurrency(stats.totalValue) : (stats.dayChange >= 0 ? '+' : '') + formatCurrency(stats.dayChange)}
                                </div>
                                
                                 ${module.id === 'portfolio_summary' ? (() => {
                                    const totalVal = stats.totalValue || 0;
                                    const superPct = totalVal > 0 ? ((stats.superValue / totalVal) * 100) : 0;
                                    const cashPct = totalVal > 0 ? ((stats.cashInBankValue / totalVal) * 100) : 0;
                                    const sharePct = totalVal > 0 ? ((stats.shareValue / totalVal) * 100) : 0;
                                    const otherPct = totalVal > 0 ? ((stats.otherValue / totalVal) * 100) : 0;

                                    const superColor = this._getCategoryColor('super');
                                    const bankColor = this._getCategoryColor('cash_in_bank');
                                    const shareColor = this._getCategoryColor('shares');
                                    const otherColor = this._getCategoryColor('other');

                                    return `
                                        <!-- Macro Balance Stacked Progress Bar in Hero -->
                                        <div class="${CSS_CLASSES.WIDGET_PROGRESS_BAR}" style="margin-bottom: 15px;">
                                            ${superPct > 0 ? `<div style="width: ${superPct.toFixed(1)}%; background: ${superColor}; height: 100%;" title="Super: ${superPct.toFixed(1)}%"></div>` : ''}
                                            ${cashPct > 0 ? `<div style="width: ${cashPct.toFixed(1)}%; background: ${bankColor}; height: 100%;" title="Cash: ${cashPct.toFixed(1)}%"></div>` : ''}
                                            ${sharePct > 0 ? `<div style="width: ${sharePct.toFixed(1)}%; background: ${shareColor}; height: 100%;" title="Shares: ${sharePct.toFixed(1)}%"></div>` : ''}
                                            ${otherPct > 0 ? `<div style="width: ${otherPct.toFixed(1)}%; background: ${otherColor}; height: 100%;" title="Other Assets: ${otherPct.toFixed(1)}%"></div>` : ''}
                                        </div>

                                        <!-- Asset Breakout in Hero -->
                                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; width: 100%; margin-bottom: 18px; margin-top: 5px;">
                                            <div style="display: flex; flex-direction: column; gap: 2px;">
                                                <span style="font-size: 0.65rem; color: rgba(255,255,255,0.5); font-weight: 700; text-transform: uppercase;">Super</span>
                                                <span style="font-size: 1.45rem; font-weight: 800; color: ${superColor};">
                                                    ${formatCurrency(stats.superValue)} <span style="font-size: 0.75rem; font-weight: 700; color: rgba(255,255,255,0.55);">(${superPct.toFixed(1)}%)</span>
                                                </span>
                                            </div>
                                            <div style="display: flex; flex-direction: column; gap: 2px; align-items: flex-end; text-align: right;">
                                                <span style="font-size: 0.65rem; color: rgba(255,255,255,0.5); font-weight: 700; text-transform: uppercase;">Cash</span>
                                                <span style="font-size: 1.45rem; font-weight: 800; color: ${bankColor};">
                                                    ${formatCurrency(stats.cashInBankValue)} <span style="font-size: 0.75rem; font-weight: 700; color: rgba(255,255,255,0.55);">(${cashPct.toFixed(1)}%)</span>
                                                </span>
                                            </div>
                                            <div style="display: flex; flex-direction: column; gap: 2px;">
                                                <span style="font-size: 0.65rem; color: rgba(255,255,255,0.5); font-weight: 700; text-transform: uppercase;">Shares</span>
                                                <span style="font-size: 1.45rem; font-weight: 800; color: ${shareColor};">
                                                    ${formatCurrency(stats.shareValue)} <span style="font-size: 0.75rem; font-weight: 700; color: rgba(255,255,255,0.55);">(${sharePct.toFixed(1)}%)</span>
                                                </span>
                                            </div>
                                            <div style="display: flex; flex-direction: column; gap: 2px; align-items: flex-end; text-align: right;">
                                                <span style="font-size: 0.65rem; color: rgba(255,255,255,0.5); font-weight: 700; text-transform: uppercase;">Other Assets</span>
                                                <span style="font-size: 1.45rem; font-weight: 800; color: ${otherColor};">
                                                    ${formatCurrency(stats.otherValue)} <span style="font-size: 0.75rem; font-weight: 700; color: rgba(255,255,255,0.55);">(${otherPct.toFixed(1)}%)</span>
                                                </span>
                                            </div>
                                        </div>
                                    `;
                                })() : `
                                    <div style="font-size: 0.75rem; color: rgba(255,255,255,0.6); font-weight: 700; text-transform: uppercase;">Day Change</div>
                                `}

                                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 4px;">
                                    <div style="font-size: 1.4rem; font-weight: 800; color: ${stats.isUp ? 'var(--color-positive)' : 'var(--color-negative)'}; display: flex; align-items: center; gap: 6px;">
                                        <i class="fas ${stats.isUp ? 'fa-arrow-trend-up' : 'fa-arrow-trend-down'}"></i>
                                        ${stats.dayPct.toFixed(2)}%
                                    </div>
                                    <div style="display: flex; align-items: center; gap: 12px; font-size: 0.85rem; font-weight: 700;">
                                        <span style="color: var(--color-positive); display: flex; align-items: center; gap: 4px;">
                                            ${stats.winners} <i class="fas fa-arrow-trend-up" style="font-size: 0.7rem;"></i>
                                        </span>
                                        <span style="color: var(--color-negative); display: flex; align-items: center; gap: 4px;">
                                            ${stats.losers} <i class="fas fa-arrow-trend-down" style="font-size: 0.7rem;"></i>
                                        </span>
                                        <span style="color: rgba(255, 255, 255, 0.4);">${stats.unchanged}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            }

            const content = this[module.renderer]();
            if (!content || (typeof content === 'string' && content.includes('empty') && module.id !== 'active_targets')) return '';

            return `
                <div class="${CSS_CLASSES.WIDGET_SECTION_WRAPPER}" style="padding: 8px 16px;">
                    <div class="${CSS_CLASSES.WIDGET_SECTION_CARD}" style="background: ${activeGradient}; padding: 18px 0; box-shadow: 0 4px 15px rgba(0,0,0,0.3); border: none !important;">
                        <div class="${CSS_CLASSES.WIDGET_SECTION_HEADER}" style="padding: 0 18px 15px 18px; display: flex; justify-content: space-between; align-items: center;">
                            <div style="display: flex; align-items: center; gap: 6px; font-size: 0.75rem; letter-spacing: 1.5px; color: rgba(255,255,255,0.8); font-weight: 800;">
                                <i class="fas ${module.icon}" style="font-size: 0.8rem; opacity: 0.9;"></i>
                                <span style="text-transform: uppercase;">${module.label}</span>
                            </div>
                            ${module.id === 'dashboard_snapshot' ? '<i class="fas fa-pen" style="cursor: pointer; opacity: 0.4; font-size: 0.8rem;" onclick="document.dispatchEvent(new CustomEvent(\'open-widget-dashboard-picker\'))"></i>' : ''}
                        </div>
                        <div class="${CSS_CLASSES.WIDGET_SECTION_CONTENT}">
                            ${content}
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        html += `</div>`; // Close scroll container
        this.container.innerHTML = html;

        const newScrollContainer = this.container.querySelector('.widget-scroll-container');
        if (newScrollContainer && prevScroll > 0) {
            newScrollContainer.scrollTop = prevScroll;
        }

        this._bindUIActions();
        this._initClocks();
    }

    _bindUIActions() {
        if (!this.container) return;

        const closeBtn = this.container.querySelector(`#${IDS.WIDGET_CLOSE_TRIGGER}`);
        if (closeBtn) closeBtn.onclick = () => this.toggle();

        const settingsBtn = this.container.querySelector(`#${IDS.WIDGET_SETTINGS_TRIGGER}`);
        if (settingsBtn) {
            settingsBtn.onclick = () => {
                document.dispatchEvent(new CustomEvent('open-widget-config'));
            };
        }

        const heroCard = this.container.querySelector(`#${IDS.WIDGET_PORTFOLIO_HERO}`);
        if (heroCard) {
            heroCard.onclick = () => {
                this.toggle();
                document.dispatchEvent(new CustomEvent(EVENTS.OPEN_PORTFOLIO_VIEW));
            };
        }
    }

    _getDefaultConfig() {
        return WIDGET_MODULES.map(m => ({ id: m.id, visible: m.default }));
    }

    // ──────────────────────────────────────────
    // Shared Helpers
    // ──────────────────────────────────────────

    _getPortfolioStats() {
        const holdings = this._getPortfolioHoldings();
        const cashItems = this._getCashItems();

        const shareValue = holdings.reduce((acc, h) => acc + h.value, 0);
        const dayChange = holdings.reduce((acc, h) => acc + h.dayChangeValue, 0);
        
        // Break out cash assets
        let superValue = 0;
        let cashInBankValue = 0;
        let otherValue = 0;

        cashItems.forEach(c => {
            const val = convertAssetToAud(c);
            const category = (c.category || '').toLowerCase();
            if (category === 'super') superValue += val;
            else if (category === 'cash_in_bank' || category === 'cash' || category === 'term_deposit') cashInBankValue += val;
            else otherValue += val;
        });

        const cashValue = superValue + cashInBankValue + otherValue;
        const totalValue = shareValue + cashValue;
        const prevShareValue = shareValue - dayChange;
        const dayPct = prevShareValue > 0 ? ((dayChange / prevShareValue) * 100) : 0;

        // Winners/Losers/Flat Logic
        const liveHoldings = holdings.filter(h => h.price > 0);
        const winners = liveHoldings.filter(h => h.pctChange > 0).length;
        const losers = liveHoldings.filter(h => h.pctChange < 0).length;
        const unchanged = liveHoldings.length - winners - losers;

        return {
            totalValue,
            shareValue,
            superValue,
            cashInBankValue,
            otherValue,
            cashValue,
            dayChange,
            dayPct,
            isUp: dayChange >= 0,
            winners,
            losers,
            unchanged
        };
    }

    _getGreeting() {
        const hour = new Date().getHours();
        if (hour < 12) return UI_LABELS.GOOD_MORNING || 'Good Morning';
        if (hour < 17) return UI_LABELS.GOOD_AFTERNOON || 'Good Afternoon';
        return UI_LABELS.GOOD_EVENING || 'Good Evening';
    }

    _getPortfolioHoldings() {
        const shares = AppState.data.shares || [];
        const livePrices = AppState.livePrices || new Map();
        const dedupMap = new Map();

        shares.forEach(s => {
            if (AppState.hiddenAssets && AppState.hiddenAssets.has(String(s.id))) return;
            const units = parseFloat(s.portfolioShares) || 0;
            if (units <= 0) return;
            const code = (s.shareName || s.code || '').trim().toUpperCase();
            if (!code) return;

            const existing = dedupMap.get(code);
            if (existing) {
                existing.units += units;
            } else {
                dedupMap.set(code, { code, units });
            }
        });

        const results = [];
        dedupMap.forEach(item => {
            const liveData = livePrices.get(item.code) || {};
            const price = parseFloat(liveData.live) || 0;
            const change = parseFloat(liveData.change) || 0;
            const pctChange = parseFloat(liveData.pctChange) || 0;

            results.push({
                code: item.code,
                units: item.units,
                price,
                value: price * item.units,
                change,
                pctChange,
                dayChangeValue: change * item.units
            });
        });
        return results;
    }

    _getCashItems() {
        return (AppState.data.cash || []).filter(c => c.category !== 'shares' && (!AppState.hiddenAssets || !AppState.hiddenAssets.has(String(c.id))));
    }

    /**
     * Smart price formatter for dashboard items.
     * - Indexes: plain number (no $ sign)
     * - Currencies: 4 decimal places (no $ sign)
     * - Commodities/Crypto: $ with 2dp
     */
    _formatDashboardPrice(code, price) {
        const upCode = code.toUpperCase();
        if (INDEX_SYMBOLS.has(upCode) || INDEX_SYMBOLS.has(code)) {
            return price >= 1000 ? Number(price).toLocaleString('en-AU', { maximumFractionDigits: 1 }) : price.toFixed(1);
        }
        if (CURRENCY_SYMBOLS.has(upCode) || CURRENCY_SYMBOLS.has(code)) {
            return price.toFixed(4);
        }
        return formatCurrency(price);
    }

    /**
     * Resolves the theme color for a specific asset category.
     * Checks AppState.preferences.userCategories first, then falls back to standards.
     * @param {string} categoryId 
     * @returns {string} Hex color
     */
    _getCategoryColor(categoryId) {
        if (!categoryId) return 'var(--color-accent)';
        
        // 1. Core equities portfolio in Wealth Summary always uses the dedicated theme token
        if (categoryId === 'shares') {
            const userPrefs = AppState.preferences?.userCategories || [];
            const userPref = userPrefs.find(c => c.id === 'shares');
            // Ignore legacy auto-seeded olive (#808000) or coffee (#a49393) overrides
            if (userPref && userPref.color && !['#808000', '#a49393'].includes(userPref.color.toLowerCase())) {
                return userPref.color;
            }
            return 'var(--asset-shares, #00D2FF)';
        }

        // 2. Check User Overrides in AppState
        const userPrefs = AppState.preferences?.userCategories || [];
        let userPref = userPrefs.find(c => c.id === categoryId);
        
        // Special case: if we want cash/cash_in_bank color, check both
        if ((!userPref || !userPref.color) && (categoryId === 'cash_in_bank' || categoryId === 'cash')) {
            userPref = userPrefs.find(c => c.id === 'cash') || userPrefs.find(c => c.id === 'cash_in_bank');
        }

        if (userPref && userPref.color) return userPref.color;

        // 3. Standard Category Fallbacks (Mirroring App variables)
        const standardColors = {
            'shares': 'var(--asset-shares, #00D2FF)',
            'super': 'var(--asset-super, #9C27B0)',
            'cash_in_bank': 'var(--asset-cash-in-bank, #1A237E)',
            'cash': 'var(--asset-cash, #2196F3)',
            'other': 'var(--asset-other, #424242)'
        };

        return standardColors[categoryId] || 'var(--color-accent)';
    }

    // ──────────────────────────────────────────
    // Module Renderers
    // ──────────────────────────────────────────

    _renderDayPerformance() {
        const holdings = this._getPortfolioHoldings().filter(h => h.price > 0);
        if (!holdings.length) return `<div class="${CSS_CLASSES.WIDGET_EMPTY}">No live portfolio data.</div>`;

        const totalValue = holdings.reduce((acc, h) => acc + h.value, 0);
        const totalDayChange = holdings.reduce((acc, h) => acc + h.dayChangeValue, 0);
        const prevTotal = totalValue - totalDayChange;
        const totalPct = prevTotal > 0 ? ((totalDayChange / prevTotal) * 100) : 0;

        const winners = holdings.filter(h => h.pctChange > 0).length;
        const losers = holdings.filter(h => h.pctChange < 0).length;
        const unchanged = holdings.length - winners - losers;

        const dayClass = totalDayChange >= 0 ? CSS_CLASSES.TEXT_UP : CSS_CLASSES.TEXT_DOWN;
        const daySign = totalDayChange >= 0 ? '+' : '';

        return `
            <div class="widget-stat-grid" style="padding: 0 18px 12px 18px;">
                <div class="widget-stat-row" style="justify-content: space-between; padding-bottom: 8px; margin-bottom: 8px;">
                    <div class="widget-stat-item" style="align-items: flex-start;">
                        <label class="${dayClass}">Day Change</label>
                        <span class="value ${dayClass}">${daySign}${formatCurrency(Math.abs(totalDayChange))}</span>
                    </div>
                    <div class="widget-stat-item" style="align-items: flex-end; text-align: right;">
                        <label class="${dayClass}">Day Return</label>
                        <span class="value ${dayClass}">${daySign}${totalPct.toFixed(2)}%</span>
                    </div>
                </div>
                <div class="widget-stat-row" style="margin-top: 6px;">
                    <div class="widget-stat-item widget-stat-small">
                        <label>Winners</label>
                        <span class="value text-up">${winners}</span>
                    </div>
                    <div class="widget-stat-item widget-stat-small">
                        <label>Losers</label>
                        <span class="value text-down">${losers}</span>
                    </div>
                    <div class="${CSS_CLASSES.WIDGET_STAT_ITEM} ${CSS_CLASSES.WIDGET_STAT_SMALL}">
                        <label>Flat</label>
                        <span class="value" style="color:var(--text-muted);">${unchanged}</span>
                    </div>
                </div>
            </div>
        `;
    }

    _renderPortfolioSummary() {
        const stats = this._getPortfolioStats();
        const dayClass = stats.dayChange >= 0 ? CSS_CLASSES.TEXT_UP : CSS_CLASSES.TEXT_DOWN;
        const daySign = stats.dayChange >= 0 ? '+' : '';

        // Resolve colors
        const shareColor = this._getCategoryColor('shares');
        const superColor = this._getCategoryColor('super');
        const bankColor = this._getCategoryColor('cash_in_bank');
        const otherColor = this._getCategoryColor('other');

        // Macro balance percentage splits
        const totalVal = stats.totalValue || 0;
        const superPct = totalVal > 0 ? ((stats.superValue / totalVal) * 100) : 0;
        const cashPct = totalVal > 0 ? ((stats.cashInBankValue / totalVal) * 100) : 0;
        const sharePct = totalVal > 0 ? ((stats.shareValue / totalVal) * 100) : 0;
        const otherPct = totalVal > 0 ? ((stats.otherValue / totalVal) * 100) : 0;

        return `
            <div class="${CSS_CLASSES.WIDGET_STAT_GRID}" style="padding: 0 18px 12px 18px;">
                <div class="${CSS_CLASSES.WIDGET_STAT_ITEM}">
                    <label>Net Wealth Overview</label>
                    <span class="value">${formatCurrency(stats.totalValue)}</span>
                    <!-- Macro Balance Stacked Progress Bar -->
                    <div class="${CSS_CLASSES.WIDGET_PROGRESS_BAR}" style="margin-top: 8px;">
                        ${superPct > 0 ? `<div style="width: ${superPct.toFixed(1)}%; background: ${superColor}; height: 100%;" title="Super: ${superPct.toFixed(1)}%"></div>` : ''}
                        ${cashPct > 0 ? `<div style="width: ${cashPct.toFixed(1)}%; background: ${bankColor}; height: 100%;" title="Cash: ${cashPct.toFixed(1)}%"></div>` : ''}
                        ${sharePct > 0 ? `<div style="width: ${sharePct.toFixed(1)}%; background: ${shareColor}; height: 100%;" title="Shares: ${sharePct.toFixed(1)}%"></div>` : ''}
                        ${otherPct > 0 ? `<div style="width: ${otherPct.toFixed(1)}%; background: ${otherColor}; height: 100%;" title="Other Assets: ${otherPct.toFixed(1)}%"></div>` : ''}
                    </div>
                </div>
                <div class="${CSS_CLASSES.WIDGET_STAT_ROW}" style="margin-top: 10px; justify-content: space-between;">
                    <div class="${CSS_CLASSES.WIDGET_STAT_ITEM} ${CSS_CLASSES.WIDGET_STAT_SMALL}">
                        <label>Super</label>
                        <span class="value" style="color: ${superColor}; font-size: 1.25rem; font-weight: 800;">
                            ${formatCurrency(stats.superValue)} <span style="font-size: 0.72rem; font-weight: 700; color: rgba(255,255,255,0.55); margin-left: 2px;">(${superPct.toFixed(1)}%)</span>
                        </span>
                    </div>
                    <div class="${CSS_CLASSES.WIDGET_STAT_ITEM} ${CSS_CLASSES.WIDGET_STAT_SMALL}" style="align-items: flex-end; text-align: right;">
                        <label>Cash</label>
                        <span class="value" style="color: ${bankColor}; font-size: 1.25rem; font-weight: 800;">
                            ${formatCurrency(stats.cashInBankValue)} <span style="font-size: 0.72rem; font-weight: 700; color: rgba(255,255,255,0.55); margin-left: 2px;">(${cashPct.toFixed(1)}%)</span>
                        </span>
                    </div>
                </div>
                <div class="${CSS_CLASSES.WIDGET_STAT_ROW}" style="margin-top: 10px; justify-content: space-between;">
                    <div class="${CSS_CLASSES.WIDGET_STAT_ITEM} ${CSS_CLASSES.WIDGET_STAT_SMALL}">
                        <label>Shares</label>
                        <span class="value" style="color: ${shareColor}; font-size: 1.25rem; font-weight: 800;">
                            ${formatCurrency(stats.shareValue)} <span style="font-size: 0.72rem; font-weight: 700; color: rgba(255,255,255,0.55); margin-left: 2px;">(${sharePct.toFixed(1)}%)</span>
                        </span>
                    </div>
                    <div class="${CSS_CLASSES.WIDGET_STAT_ITEM} ${CSS_CLASSES.WIDGET_STAT_SMALL}" style="align-items: flex-end; text-align: right;">
                        <label>Other Assets</label>
                        <span class="value" style="color: ${otherColor}; font-size: 1.25rem; font-weight: 800;">
                            ${formatCurrency(stats.otherValue)} <span style="font-size: 0.72rem; font-weight: 700; color: rgba(255,255,255,0.55); margin-left: 2px;">(${otherPct.toFixed(1)}%)</span>
                        </span>
                    </div>
                </div>
                ${stats.shareValue > 0 ? `
                    <div class="${CSS_CLASSES.WIDGET_DAY_CHANGE} ${dayClass}" style="margin-top: 12px; padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.05); display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-size: 0.75rem; opacity: 0.6; text-transform: uppercase; font-weight: 700;">Market Move</span>
                        <div style="display: flex; gap: 8px; align-items: center;">
                             <span style="font-weight: 800; font-size: 0.95rem;">${daySign}${formatCurrency(Math.abs(stats.dayChange))}</span>
                             <span style="font-weight: 700; font-size: 0.85rem; opacity: 0.8;">(${daySign}${stats.dayPct.toFixed(2)}%)</span>
                        </div>
                    </div>
                ` : ''}
            </div>
        `;
    }

    /**
     * Dashboard Snapshot — personalized selection from dashboard data.
     * Users pick which items to show via widgetDashboardItems preference.
     * Formats intelligently: no $ for indexes, decimals for currencies.
     */
    _renderDashboardSnapshot() {
        const dashboardData = AppState.data.dashboard || [];
        const livePrices = AppState.livePrices || new Map();

        const allCodes = dashboardData
            .map(d => (d.ASXCode || d.code || '').toUpperCase())
            .filter(Boolean);

        let selectedCodes = AppState.preferences?.widgetDashboardItems;
        if (!selectedCodes || !Array.isArray(selectedCodes) || selectedCodes.length === 0) {
            selectedCodes = allCodes.slice(0, 6);
        }

        const displayItems = selectedCodes
            .map(c => c.toUpperCase())
            .filter(c => {
                if (c === 'COMMODITIES') return true;
                const ld = livePrices.get(c);
                if (ld && (ld.live || ld.price)) return true;
                const dbItem = dashboardData.find(d => (d.ASXCode || d.code || '').toUpperCase() === c);
                return dbItem && (dbItem.live || dbItem.LivePrice);
            });

        if (!displayItems.length) return `<div class="${CSS_CLASSES.WIDGET_EMPTY}">No live snapshot data</div>`;

        return displayItems.map(code => {
            const liveData = livePrices.get(code) || {};
            const dbItem = dashboardData.find(d => (d.ASXCode || d.code || '').toUpperCase() === code) || {};
            const price = parseFloat(liveData.live || liveData.price || dbItem.live || dbItem.LivePrice || 0);

            const rawPct = liveData.pctChange ?? liveData.dayChangePercent ?? liveData.changePct ?? liveData.pct ?? dbItem.pctChange ?? dbItem.PctChange;
            const rawChange = liveData.change ?? liveData.valueChange ?? dbItem.valueChange ?? dbItem.Change;
            const pct = rawPct !== undefined && !isNaN(parseFloat(rawPct)) ? parseFloat(rawPct) : (rawChange !== undefined && !isNaN(parseFloat(rawChange)) ? parseFloat(rawChange) : 0);
            const changeVal = rawChange !== undefined && !isNaN(parseFloat(rawChange)) ? parseFloat(rawChange) : 0;

            const isCommodityBypass = code === 'COMMODITIES';
            const isPositive = (pct !== 0 ? pct : changeVal) >= 0;
            const colorClass = isCommodityBypass
                ? CSS_CLASSES.TEXT_NEUTRAL
                : (isPositive ? CSS_CLASSES.TEXT_UP : CSS_CLASSES.TEXT_DOWN);
            const pctSign = isPositive ? '+' : '';
            const priceStr = isCommodityBypass ? '--' : this._formatDashboardPrice(code, price);
            const pctStr = isCommodityBypass ? '--' : `${pct < 0 ? '' : pctSign}${pct.toFixed(2)}%`;
            const displayName = DASHBOARD_NAMES[code] || code;

            const clickHandlerStr = isCommodityBypass
                ? `window.open('https://www.marketindex.com.au/commodities', '_blank', 'noopener,noreferrer')`
                : `document.dispatchEvent(new CustomEvent('${EVENTS.ASX_CODE_CLICK}', { detail: { code: '${code}' } }))`;

            const clockStyle = isCommodityBypass
                ? `display: none !important;`
                : `width: 14px; height: 14px; flex-shrink: 0;`;

            return `
                <div class="${CSS_CLASSES.WIDGET_ROW}" style="display: flex; justify-content: space-between; align-items: center; padding: 10px 18px; cursor: pointer;" 
                     onclick="${clickHandlerStr}">
                    <div style="display: flex; align-items: center; flex: 1; text-align: left; gap: 8px;">
                        <div class="analog-clock-hook" data-code="${code}" style="${clockStyle}"></div>
                        <span class="code" style="font-weight: 800; font-size: 1.05rem; color: #fff;">${displayName}</span>
                    </div>
                    <div style="flex: 2; display: flex; justify-content: flex-end; align-items: center; gap: 8px;">
                        <span class="value" style="font-weight: 700; font-size: 1.1rem; color: #fff;">${priceStr}</span>
                        <span class="change ${colorClass}" style="font-weight: 700; font-size: 0.9rem; min-width: 65px; text-align: right;">${pctStr}</span>
                    </div>
                </div>
            `;
        }).join('');
    }

    _renderMarketMovers() {
        if (!notificationStore) return `<div class="${CSS_CLASSES.WIDGET_EMPTY}">Data unavailable</div>`;
        const alerts = notificationStore.getGlobalAlerts(true);
        if (!alerts || !alerts.movers) return `<div class="${CSS_CLASSES.WIDGET_EMPTY}">No movers found</div>`;

        const allMovers = [...(alerts.movers.up || []), ...(alerts.movers.down || [])];
        const enriched = allMovers.map(m => {
            const live = AppState.livePrices?.get(m.code);
            return live ? { ...m, live: live.live || m.live, pctChange: live.pctChange || m.pctChange || 0 } : m;
        });

        const seen = new Set();
        const unique = enriched.filter(m => !seen.has(m.code) && seen.add(m.code));
        unique.sort((a, b) => Math.abs(b.pctChange) - Math.abs(a.pctChange));
        const top6 = unique.slice(0, 6);

        if (top6.length === 0) return '<div class="widget-empty">No movers found</div>';

        return top6.map(m => {
            const isUp = m.pctChange >= 0;
            const colorClass = isUp ? CSS_CLASSES.TEXT_UP : CSS_CLASSES.TEXT_DOWN;
            return `
                <div class="widget-row" style="display: flex; justify-content: space-between; align-items: center; padding: 10px 18px; cursor: pointer;"
                     onclick="document.dispatchEvent(new CustomEvent('${EVENTS.ASX_CODE_CLICK}', { detail: { code: '${m.code}' } }))">
                    <span class="code" style="font-weight: 800; font-size: 0.85rem; color: #fff; flex: 1; text-align: left;">${m.code}</span>
                    <div style="flex: 2; display: flex; justify-content: flex-end; align-items: center; gap: 8px;">
                        <span class="price" style="font-weight: 700; font-size: 0.85rem; color: #fff;">${formatCurrency(m.live)}</span>
                        <span class="change ${colorClass}" style="font-weight: 700; font-size: 0.8rem; min-width: 55px; text-align: right;">${isUp ? '+' : ''}${m.pctChange.toFixed(2)}%</span>
                    </div>
                </div>
            `;
        }).join('');
    }

    _renderNotifications() {
        try {
            const local = notificationStore?.getLocalAlerts?.() || { pinned: [], fresh: [] };
            const allAlerts = [...(local.pinned || []), ...(local.fresh || [])];
            const filteredAlerts = allAlerts.filter(a => {
                const intent = (a.intent || '').toLowerCase();
                const code = (a.code || '').toUpperCase();
                return intent !== 'mover' && intent !== 'up' && intent !== 'down' && intent !== 'brief' && !code.includes('MORNING');
            });

            const targets = filteredAlerts.filter(a => (a.intent || '').toLowerCase() === 'target');
            const others = filteredAlerts.filter(a => (a.intent || '').toLowerCase() !== 'target').slice(0, 4);
            const alerts = [...targets, ...others];

            if (!alerts.length) return `<div class="${CSS_CLASSES.WIDGET_EMPTY}">No active alerts</div>`;

            return alerts.map(a => {
                const message = this._formatAlertMessage(a);
                const pct = Number(a.pct || a.pctChange || a.dayChangePercent || 0);
                const signClass = pct >= 0 ? CSS_CLASSES.TEXT_UP : CSS_CLASSES.TEXT_DOWN;
                const code = a.code || '???';
                return `
                    <div class="widget-notification-item" style="padding: 10px 18px; cursor: pointer;" onclick="if('${code}' !== '???') document.dispatchEvent(new CustomEvent('${EVENTS.ASX_CODE_CLICK}', { detail: { code: '${code}' } }))">
                        <span class="code ${signClass}" style="font-weight: 800; margin-right: 10px;">${code}</span>
                        <span class="message" style="font-size: 0.85rem; color: rgba(255,255,255,0.7);">${message}</span>
                    </div>
                `;
            }).join('');
        } catch (e) {
            return `<div class="${CSS_CLASSES.WIDGET_EMPTY}">Alerts unavailable</div>`;
        }
    }

    /**
     * Active Target Alerts — lists stocks with user-defined target thresholds,
     * current price, target price, and real-time percentage distance to target.
     * Highlights targets that have been triggered (HIT).
     */
    _renderActiveTargets() {
        const shares = AppState.data.shares || [];
        const livePrices = AppState.livePrices || new Map();
        const targetMap = new Map();

        shares.forEach(s => {
            if (AppState.hiddenAssets && AppState.hiddenAssets.has(String(s.id))) return;
            const code = (s.shareName || s.code || '').trim().toUpperCase();
            if (!code) return;
            const targetPrice = parseFloat(s.targetPrice ?? s.target_price ?? 0);
            if (!targetPrice || targetPrice <= 0 || isNaN(targetPrice)) return;

            const targetDirection = (s.targetDirection || 'below').toLowerCase();
            const buySell = (s.buySell || (targetDirection === 'above' ? 'sell' : 'buy')).toLowerCase();
            const key = `${code}-${targetDirection}`;

            if (!targetMap.has(key)) {
                targetMap.set(key, {
                    id: s.id,
                    code,
                    targetPrice,
                    targetDirection,
                    buySell
                });
            }
        });

        const targetList = Array.from(targetMap.values());

        if (!targetList.length) {
            return `
                <div class="${CSS_CLASSES.WIDGET_EMPTY}" style="padding: 16px 18px; text-align: center; color: rgba(255, 255, 255, 0.45); font-size: 0.82rem;">
                    <i class="fas fa-crosshairs" style="display: block; font-size: 1.25rem; margin-bottom: 6px; opacity: 0.35;"></i>
                    No target alerts configured
                </div>
            `;
        }

        // Cross-reference live data and calculate distance + hit state
        const enriched = targetList.map(item => {
            const liveData = livePrices.get(item.code) || {};
            const currentPrice = parseFloat(liveData.live || liveData.price || 0);

            let distPct = null;
            let isHit = false;

            if (currentPrice > 0) {
                // Objective distance calculation: ((livePrice - targetPrice) / targetPrice) * 100
                // Above target = positive (+), below target = negative (-). No sign flipping based on order type.
                distPct = ((currentPrice - item.targetPrice) / item.targetPrice) * 100;

                // Hit logic: BUY triggers when price falls to or below limit; SELL triggers when price rises to or above limit.
                const isBuy = item.buySell === 'buy';
                isHit = isBuy
                    ? currentPrice <= (item.targetPrice + 0.0001)
                    : currentPrice >= (item.targetPrice - 0.0001);
            }

            return {
                ...item,
                currentPrice,
                distPct,
                isHit
            };
        });

        // Priority sort: HIT targets first, then closest distance ascending
        enriched.sort((a, b) => {
            if (a.isHit && !b.isHit) return -1;
            if (!a.isHit && b.isHit) return 1;

            const distA = a.distPct !== null ? Math.abs(a.distPct) : 999999;
            const distB = b.distPct !== null ? Math.abs(b.distPct) : 999999;
            return distA - distB;
        });

        return enriched.map(item => {
            const isBuy = item.buySell === 'buy';
            const dirIcon = isBuy ? UI_ICONS.CARET_DOWN : UI_ICONS.CARET_UP;
            const dirColor = isBuy ? 'var(--color-negative)' : 'var(--color-positive)';
            const strategyLabel = isBuy ? 'Buy' : 'Sell';
            const priceStr = item.currentPrice > 0 ? formatCurrency(item.currentPrice) : '--';

            let distBadgeHtml;
            const distSign = item.distPct !== null && item.distPct >= 0 ? '+' : '';
            const formattedPct = item.distPct !== null ? `${distSign}${item.distPct.toFixed(2)}%` : '--';
            const distColorClass = item.distPct !== null
                ? (item.distPct >= 0 ? CSS_CLASSES.TEXT_UP : CSS_CLASSES.TEXT_DOWN)
                : '';

            if (item.isHit) {
                distBadgeHtml = `
                    <div style="display: flex; align-items: center; justify-content: flex-end; gap: 6px;">
                        <span class="${CSS_CLASSES.WIDGET_TARGET_HIT}">
                            <i class="fas fa-check" style="font-size: 0.6rem;"></i> HIT
                        </span>
                        <span class="${distColorClass}" style="font-weight: 600; font-size: 0.80rem; min-width: 50px; text-align: right;">
                            (${formattedPct})
                        </span>
                    </div>
                `;
            } else if (item.distPct !== null) {
                distBadgeHtml = `
                    <span class="${distColorClass}" style="font-weight: 600; font-size: 0.82rem; min-width: 55px; text-align: right;">
                        ${formattedPct}
                    </span>
                `;
            } else {
                distBadgeHtml = `<span style="font-size: 0.8rem; color: rgba(255,255,255,0.3); text-align: right;">--</span>`;
            }

            return `
                <div class="${CSS_CLASSES.WIDGET_TARGET_ROW}"
                     onclick="document.dispatchEvent(new CustomEvent('${EVENTS.ASX_CODE_CLICK}', { detail: { code: '${item.code}' } }))">
                    <div style="display: flex; flex-direction: column; gap: 2px; flex: 1; text-align: left;">
                        <div style="display: flex; align-items: center; gap: 6px;">
                            <span class="code" style="font-weight: 800; font-size: 0.88rem; color: #fff;">${item.code}</span>
                            <span class="${CSS_CLASSES.WIDGET_TARGET_BADGE}">
                                <i class="fas ${dirIcon}" style="color: ${dirColor};"></i>${strategyLabel}
                            </span>
                        </div>
                        <span style="font-size: 0.74rem; color: rgba(255,255,255,0.5);">
                            Target: <strong style="color: rgba(255,255,255,0.85); font-weight: 700;">${formatCurrency(item.targetPrice)}</strong>
                        </span>
                    </div>
                    <div style="flex: 1; display: flex; flex-direction: column; align-items: flex-end; gap: 2px;">
                        <span class="value" style="font-weight: 700; font-size: 0.88rem; color: #fff;">${priceStr}</span>
                        ${distBadgeHtml}
                    </div>
                </div>
            `;
        }).join('');
    }

    _formatAlertMessage(a) {
        const intent = (a.intent || '').toLowerCase();
        const pct = (a.pct || a.pctChange || a.dayChangePercent || 0);
        const sign = pct >= 0 ? '+' : '';
        const pctStr = `${sign}${Number(pct).toFixed(2)}%`;
        if (intent === 'target') return `Hit target ${formatCurrency(a.target)}`;
        if (intent === 'hilo') return `52wk ${a.type === 'high' ? 'High' : 'Low'} (${pctStr})`;
        return `Moved ${pctStr}`;
    }

    _renderMarketSnapshot() {
        if (!AppState.livePrices) return `<div class="${CSS_CLASSES.WIDGET_EMPTY}">Market data unavailable</div>`;
        const xjo = AppState.livePrices.get('^AXJO') || AppState.livePrices.get('XJO');
        if (!xjo || typeof xjo.live === 'undefined') return `<div class="${CSS_CLASSES.WIDGET_EMPTY}">Market data unavailable</div>`;

        const pct = Number(xjo.pctChange || 0);
        const changeClass = pct >= 0 ? CSS_CLASSES.TEXT_UP : CSS_CLASSES.TEXT_DOWN;
        const sign = pct >= 0 ? '+' : '';
        const url = DASHBOARD_LINKS['^AXJO'] || LinkHelper.getFinanceUrl('^AXJO');

        return `
            <div class="${CSS_CLASSES.WIDGET_ROW}" style="display: flex; justify-content: space-between; align-items: center; padding: 12px 18px; cursor: pointer;" onclick="window.open('${url}', '_blank', 'noopener,noreferrer')">
                <span style="font-weight: 800; font-size: 0.85rem; color: #fff; flex: 1; text-align: left;">ASX 200</span>
                <div style="flex: 2; display: flex; justify-content: flex-end; align-items: center; gap: 8px;">
                    <span style="font-weight: 700; font-size: 0.85rem; color: #fff;">${Number(xjo.live || 0).toLocaleString('en-AU', { maximumFractionDigits: 1 })}</span>
                    <span class="${changeClass}" style="font-weight: 700; font-size: 0.8rem; min-width: 55px; text-align: right;">${sign}${pct.toFixed(2)}%</span>
                </div>
            </div>
        `;
    }

    _renderTopMovers() {
        const local = notificationStore?.getLocalAlerts?.() || { pinned: [], fresh: [] };
        const allAlerts = [...(local.pinned || []), ...(local.fresh || [])];
        let movers = allAlerts.filter(a => {
            const intent = (a.intent || '').toLowerCase();
            return intent === 'mover' || intent === 'up' || intent === 'down';
        });

        if (!movers.length) return `<div class="${CSS_CLASSES.WIDGET_EMPTY}">No significant movers</div>`;

        const sorted = movers.sort((a, b) => {
            const pctA = Math.abs(Number(a.pct || a.pctChange || a.dayChangePercent || 0));
            const pctB = Math.abs(Number(b.pct || b.pctChange || b.dayChangePercent || 0));
            return pctB - pctA;
        }).slice(0, 5);

        return sorted.map(h => {
            const code = h.code || '???';
            let price = h.price || 0;
            let pct = Number(h.pct || h.pctChange || h.dayChangePercent || 0);

            if (AppState.livePrices?.has(code)) {
                const live = AppState.livePrices.get(code);
                price = Number(live.live || live.price || price);
                pct = Number(live.dayChangePercent ?? live.pctChange ?? live.pct ?? pct);
            }

            const pctClass = pct >= 0 ? CSS_CLASSES.TEXT_UP : CSS_CLASSES.TEXT_DOWN;
            return `
                <div class="widget-row" style="display: flex; justify-content: space-between; align-items: center; padding: 10px 18px; cursor: pointer;"
                     onclick="document.dispatchEvent(new CustomEvent('${EVENTS.ASX_CODE_CLICK}', { detail: { code: '${code}' } }))">
                    <span class="code" style="font-weight: 800; font-size: 0.85rem; color: #fff; flex: 1; text-align: left;">${code}</span>
                    <div style="flex: 2; display: flex; justify-content: flex-end; align-items: center; gap: 8px;">
                        <span class="value" style="font-weight: 700; font-size: 0.85rem; color: #fff;">${formatCurrency(price)}</span>
                        <span class="change ${pctClass}" style="font-weight: 700; font-size: 0.8rem; min-width: 55px; text-align: right;">${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%</span>
                    </div>
                </div>
            `;
        }).join('');
    }

    _renderTopHoldings() {
        const holdings = this._getPortfolioHoldings()
            .filter(h => h.value > 0)
            .sort((a, b) => b.value - a.value)
            .slice(0, 5);

        if (!holdings.length) return `<div class="${CSS_CLASSES.WIDGET_EMPTY}">No portfolio holdings</div>`;
        return holdings.map(h => {
            const pctClass = h.pctChange >= 0 ? CSS_CLASSES.TEXT_UP : CSS_CLASSES.TEXT_DOWN;
            return `
                <div class="widget-row" style="display: flex; justify-content: space-between; align-items: center; padding: 10px 18px; cursor: pointer;"
                     onclick="document.dispatchEvent(new CustomEvent('${EVENTS.ASX_CODE_CLICK}', { detail: { code: '${h.code}' } }))">
                    <span class="code" style="font-weight: 800; font-size: 0.85rem; color: #fff; flex: 1; text-align: left;">${h.code}</span>
                    <div style="flex: 2; display: flex; justify-content: flex-end; align-items: center; gap: 8px;">
                        <span class="value" style="font-weight: 700; font-size: 0.85rem; color: #fff;">${formatCurrency(h.value)}</span>
                        <span class="change ${pctClass}" style="font-weight: 700; font-size: 0.8rem; min-width: 55px; text-align: right;">${h.pctChange >= 0 ? '+' : ''}${h.pctChange.toFixed(2)}%</span>
                    </div>
                </div>
            `;
        }).join('');
    }

    _renderCashBreakdown() {
        const cashItems = this._getCashItems();
        if (!cashItems.length) return `<div class="${CSS_CLASSES.WIDGET_EMPTY}">No cash assets</div>`;

        const totalCash = cashItems.reduce((acc, c) => acc + convertAssetToAud(c), 0);
        return `
            <div class="${CSS_CLASSES.WIDGET_ROW}" style="padding: 10px 18px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-weight: 800; font-size: 0.85rem; color: #fff; flex: 1; text-align: left;">Total Cash & Assets</span>
                    <span style="font-weight: 700; font-size: 0.9rem; color: var(--color-accent); flex: 1; text-align: right;">${formatCurrency(totalCash)}</span>
                </div>
            </div>
            ${cashItems.slice(0, 5).map(c => `
                <div class="${CSS_CLASSES.WIDGET_ROW}" style="display: flex; justify-content: space-between; align-items: center; padding: 10px 18px; cursor: pointer;" 
                     onclick="document.dispatchEvent(new CustomEvent('${EVENTS.REQUEST_QUICK_NAV}', { detail: { watchlistId: '${CASH_WATCHLIST_ID}' } }))">
                    <span class="label" style="font-size: 0.8rem; color: rgba(255,255,255,0.6); flex: 1; text-align: left;">${c.name || c.category}</span>
                    <span class="value" style="font-weight: 600; font-size: 0.85rem; color: #fff; flex: 1; text-align: right;">${formatCurrency(convertAssetToAud(c))}</span>
                </div>
            `).join('')}
        `;
    }

    _renderWatchlistSummary() {
        const watchlists = AppState.data.watchlists || [];
        const allShares = AppState.data.shares || [];
        const userWatchlists = watchlists.filter(w => {
            const name = (w.name || '').toLowerCase();
            return name !== 'all shares' && name !== 'portfolio' && name !== 'cash & assets' && name !== 'dashboard';
        });

        if (!userWatchlists.length) return `<div class="${CSS_CLASSES.WIDGET_EMPTY}">No watchlists found</div>`;

        return userWatchlists.slice(0, 5).map(w => {
            const count = allShares.filter(s => {
                if (Array.isArray(s.watchlistIds)) return s.watchlistIds.includes(w.id);
                return s.watchlistId === w.id;
            }).length;

            return `
                <div class="widget-row" style="display: flex; justify-content: space-between; align-items: center; padding: 10px 18px; cursor: pointer;"
                     onclick="document.dispatchEvent(new CustomEvent('${EVENTS.REQUEST_QUICK_NAV}', { detail: { watchlistId: '${w.id}' } }))">
                    <span class="code" style="font-weight: 800; font-size: 0.85rem; color: #fff; flex: 1; text-align: left;">${w.name}</span>
                    <span class="value" style="font-weight: 700; font-size: 0.8rem; color: rgba(255,255,255,0.5); flex: 1; text-align: right;">${count} Stock${count !== 1 ? 's' : ''}</span>
                    <span style="margin-left: 10px; text-align: right;"><i class="fas fa-chevron-right" style="font-size: 0.7rem; opacity: 0.3;"></i></span>
                </div>
            `;
        }).join('');
    }

    /**
     * initializes analog clocks for all rows.
     */
    _initClocks() {
        // Cleanup old clocks
        if (this.rowClocks) {
            this.rowClocks.forEach(c => c.destroy());
        }
        this.rowClocks = [];

        import('./AnalogClock.js').then(({ AnalogClock }) => {
            const clockHooks = this.container.querySelectorAll('.analog-clock-hook');
            clockHooks.forEach(el => {
                const code = el.dataset.code;
                if (!code) return;
                const isOpen = this._isMarketOpen(code);
                const clock = new AnalogClock(el, isOpen);
                clock.init();
                this.rowClocks.push(clock);
            });
        });
    }

    /**
     * Approximates market status for dashboard symbols.
     * @private
     */
    _isMarketOpen(code) {
        const now = new Date();
        const utcDay = now.getUTCDay();
        const utcHours = now.getUTCHours();
        const utcMins = now.getUTCMinutes();
        const utcTotal = utcHours * 60 + utcMins;

        const sydneyParts = new Intl.DateTimeFormat('en-GB', {
            timeZone: 'Australia/Sydney',
            hour: 'numeric', minute: 'numeric', weekday: 'short', hour12: false
        }).formatToParts(now);
        const getPart = (type) => sydneyParts.find(p => p.type === type).value;
        const sydHour = parseInt(getPart('hour'));
        const sydMin = parseInt(getPart('minute'));
        const sydTotal = sydHour * 60 + sydMin;
        const sydDay = getPart('weekday');
        const isSydWeekend = (sydDay === 'Sat' || sydDay === 'Sun');

        // New York time for US markets
        const nyParts = new Intl.DateTimeFormat('en-GB', {
            timeZone: 'America/New_York',
            hour: 'numeric', minute: 'numeric', weekday: 'short', hour12: false
        }).formatToParts(now);
        const getNyPart = (type) => nyParts.find(p => p.type === type).value;
        const nyHour = parseInt(getNyPart('hour'));
        const nyMin = parseInt(getNyPart('minute'));
        const nyTotal = nyHour * 60 + nyMin;
        const nyDay = getNyPart('weekday');
        const isNyWeekend = (nyDay === 'Sat' || nyDay === 'Sun');

        // Market Logic
        if (code.includes('BTC') || code.includes('ETH')) return true;
        const isASX = code.includes('.AX') || ['^AXJO', '^AXKO', '^AORD', 'XJO', 'XKO', 'XAO', 'YAP=F'].includes(code);
        if (isASX) {
            return MarketSchedule.isASXTrading(now);
        }
        if (code.includes('FTSE') || code.includes('STOXX') || code.includes('EU50')) {
            if (utcDay === 0 || utcDay === 6) return false;
            return utcTotal >= (8 * 60) && utcTotal < (16 * 60 + 30);
        }
        if (code.includes('HSI') || code.includes('N225')) {
            if (utcDay === 0 || utcDay === 6) return false;
            return utcTotal >= (0 * 60 + 30) && utcTotal < (8 * 60);
        }
        // US INDICES (NY 09:30-16:00 EST/EDT) - Resolves DST Bug
        if (['INX', '.DJI', '.IXIC', '^GSPC', '^DJI', '^IXIC', '^VIX'].includes(code)) {
            if (isNyWeekend) return false;
            return nyTotal >= (9 * 60 + 30) && nyTotal < (16 * 60);
        }
        const FOREX_CODES = ['AUDUSD', 'AUDTHB', 'AUDGBP', 'AUDEUR', 'AUDJPY', 'AUDNZD', 'USDTHB'];
        const isForex = code.includes('=X') || FOREX_CODES.includes(code);
        if (isForex) {
            if (isNyWeekend) {
                if (nyDay === 'Sat') return false;
                if (nyDay === 'Sun' && nyTotal < (17 * 60)) return false;
                if (nyDay === 'Fri' && nyTotal > (17 * 60)) return false;
            }
            return true;
        }
        const COMMODITY_CODES = ['GCW00', 'SIW00', 'BZW00', 'NICKEL'];
        const isFutures = code.includes('=F') || code.includes('-F') || COMMODITY_CODES.includes(code);
        if (isFutures) {
            if (nyDay === 'Sat') return false;
            if (nyDay === 'Sun' && nyTotal < (18 * 60)) return false;
            if (nyDay === 'Fri' && nyTotal > (17 * 60)) return false;
            // Daily maintenance break (NY 17:00-18:00)
            if (nyTotal >= (17 * 60) && nyTotal < (18 * 60)) return false;
            return true;
        }
        if (isSydWeekend) return false;
        return sydTotal >= (10 * 60) && sydTotal < (16 * 60);
    }

    /**
     * Binds a long-hold trigger to an element to open the widget panel.
     * Replaces the old Market Pulse behavior on specific elements.
     * @param {HTMLElement} element 
     */
    static bindTrigger(element) {
        if (!element) return;

        let pressTimer;
        let hasTriggered = false;
        const LONG_PRESS_DURATION = 600; // Consistent with other app long-presses

        const startHandler = (e) => {
            hasTriggered = false;
            if (e.target.closest('button') || e.target.closest('a')) return;

            pressTimer = setTimeout(() => {
                hasTriggered = true;
                if (navigator.vibrate) navigator.vibrate(50);

                // Trigger the widget panel
                document.dispatchEvent(new CustomEvent(EVENTS.WIDGET_TOGGLE));
            }, LONG_PRESS_DURATION);
        };

        const cancelHandler = () => {
            if (pressTimer) {
                clearTimeout(pressTimer);
                pressTimer = null;
            }
        };

        const clickBlocker = (e) => {
            if (hasTriggered) {
                e.preventDefault();
                e.stopImmediatePropagation();
                hasTriggered = false;
                return false;
            }
        };

        // UI Feedback & Prevents browser default menus
        element.style.userSelect = 'none';
        element.style.webkitUserSelect = 'none';
        element.style.webkitTouchCallout = 'none';
        element.style.touchAction = 'manipulation';

        element.addEventListener('mousedown', startHandler);
        element.addEventListener('touchstart', startHandler, { passive: true });
        element.addEventListener('mouseup', cancelHandler);
        element.addEventListener('mouseleave', cancelHandler);
        element.addEventListener('touchend', cancelHandler);
        element.addEventListener('touchmove', cancelHandler);
        element.addEventListener('click', clickBlocker, true);
    }
}

export const widgetPanel = new WidgetPanel();
