/**
 * AppController.js
 * Main Application Orchestrator.
 * Coordinates Services, State, and UI.
 */

import { AuthService } from '../auth/AuthService.js';
import { DataService, userStore } from '../data/DataService.js';
import { AppService } from '../data/AppService.js';
import { ViewRenderer } from '../ui/ViewRenderer.js';
import { AppState } from '../state/AppState.js';
import { HeaderLayout } from '../ui/HeaderLayout.js';
import { processShares, getSingleShareData, getASXCodesStatus } from '../data/DataProcessor.js';
import { WatchlistUI } from '../ui/WatchlistUI.js';
import { ShareFormUI } from '../ui/ShareFormUI.js';
import { SearchDiscoveryUI } from '../ui/SearchDiscoveryUI.js'; // Added
import { NotificationUI } from '../ui/NotificationUI.js';
import { NotificationStore } from '../state/NotificationStore.js';

import { SnapshotUI } from '../ui/SnapshotUI.js'; // Added
import { LinkHelper } from '../utils/LinkHelper.js';
import { SettingsUI } from '../ui/SettingsUI.js';
import { FavoriteLinksUI } from '../ui/FavoriteLinksUI.js';
import { QuickNavUI } from '../ui/QuickNavUI.js'; // Added
import { notificationStore } from '../state/NotificationStore.js';
import { DashboardViewRenderer } from '../ui/DashboardViewRenderer.js';
import { ModalController } from './ModalController.js';
import ResearchLinksUI from '../ui/ResearchLinksUI.js';
import { CashController } from './CashController.js';
import { SecurityController } from './SecurityController.js';
import { SecurityUI } from '../ui/SecurityUI.js';
import { GeneralSettingsUI } from '../ui/GeneralSettingsUI.js';
import CalculatorUI from '../ui/CalculatorUI.js';
import CurrencyModalUI from '../ui/CurrencyModalUI.js';
import { convertAssetToAud } from '../utils/CurrencyHelper.js';
import { PortfolioChartUI } from '../ui/PortfolioChartUI.js';
import { AnalogClock } from '../ui/AnalogClock.js';
import { AiSummaryUI } from '../ui/AiSummaryUI.js';
import { ScrollManager } from '../ui/ScrollManager.js';
import { IDS, CSS_CLASSES, EVENTS, WATCHLIST_ICON_POOL, ALL_SHARES_ID, CASH_WATCHLIST_ID, DASHBOARD_WATCHLIST_ID, PORTFOLIO_ID, SIMULATIONS_WATCHLIST_ID, UI_ICONS, USER_MESSAGES, STORAGE_KEYS, WATCHLIST_MODES, SORT_OPTIONS, WATCHLIST_NAMES, DASHBOARD_SYMBOLS, DASHBOARD_LINKS, SUMMARY_TYPES, BRIEFING_BLACKLIST } from '../utils/AppConstants.js';
import { ToastManager } from '../ui/ToastManager.js';
import { navManager } from '../utils/NavigationManager.js';
import { PullToRefresh } from '../ui/PullToRefresh.js';
import { StateAuditor } from '../state/StateAuditor.js';
import { StateHealthPanel } from '../state/StateHealthPanel.js';
import { runHealthCheck, startRaceRegressionMonitor } from '../state/AppHealthTest.js';
import { marketIndexController } from '../ui/MarketIndexController.js';
import { MarketSchedule, ASX_SESSION } from '../utils/MarketSchedule.js';
import { ChartDataSanitizer } from '../utils/ChartDataSanitizer.js';
// renderSortSelect removed

export class AppController {

    constructor() {
        AppController.instance = this;
        AppState.controller = this; // Register global controller for UI modules
        // Services
        this.dataService = new DataService();
        this.userStore = userStore;
        this.appService = new AppService();
        this.viewRenderer = new ViewRenderer();

        // Timers
        this._fetchDebounceTimer = null;
        this._retryTimer = null;

        // Start with loading state until Auth confirms status
        this._setSignInLoadingState(true);

        this.dashboardRenderer = new DashboardViewRenderer();

        // Controllers
        this.modalController = new ModalController(this.updateDataAndRender.bind(this));
        this.cashController = new CashController(this.modalController);
        this.securityController = new SecurityController();

        // Register controller for UI access
        AppState.securityController = this.securityController;
        this.notificationStore = notificationStore;

        // UI Managers
        this.headerLayout = null;
        this.watchlistUI = null;
        this.quickNavUI = new QuickNavUI(); // Initialize QuickNavUI

        // Carousel Stability
        this._carouselGuard = false;

        // State Tracking
        this._isUnlockedThisSession = false;
        this._lockModalActive = false;
        this._lastBackgroundTime = 0; // PWA Resume Tracking
        this._initialWatchlistRestored = false; // v1137: Track first-run restoration
        this._initialRenderComplete = false; // v1137: Track first-run render completion
        this._initialized = false;
        this._localPrefsTimestamp = 0; // Track local preferences modification timestamp
        this._sortConfigDebounceTimer = null; // Debounce timer for sortConfig writes
        this._lastSortConfigWriteTime = 0;    // Last write timestamp for sortConfig to avoid dual-write collision
        this._lastSyncedPrefsSignature = null; // Signature of last cloud-persisted preferences to avoid redundant writes

        // Binds
        this.init = this.init.bind(this);

        // BOOTSTRAP
        // this.init(); // Removed: Deferred to main.js (DOMContentLoaded) to ensure DOM is ready
    }

    async init() {
        if (this._initialized) return;
        this._initialized = true;
        // v1146: FAIL-SAFE: If auth doesn't respond within 5s, force-enable the login button.
        // This prevents the "Initializing..." loop if Firebase fails or hangs on certain networks/devices.
        setTimeout(() => {
            if (this._initialized && !document.body.classList.contains(CSS_CLASSES.LOGGED_IN)) {
                const btn = document.getElementById(IDS.SPLASH_SIGN_IN_BTN);
                if (btn && btn.disabled) {
                    console.warn('[AppController] Auth timed out or failed to initialize. Force-enabling Login button fallback.');
                    this._setSignInLoadingState(false);
                }
            }
        }, 5000);

        // STATE AUDITOR: Enable diagnostic monitoring (non-invasive)
        StateAuditor.enable();
        startRaceRegressionMonitor(); // v1135: Monitor race regressions on fixed keys


        // StateHealthPanel.init(); // Disabled per user request (v1144) to keep UI clean.

        // AUTO HEALTH CHECK: Run 8s after boot (allows data to load)
        setTimeout(() => {
            runHealthCheck();
        }, 8000);


        // Initialize Modules
        AiSummaryUI.init();
        ScrollManager.init();

        // Initialize Pull to Refresh (PWA support) - REBOOT MODE
        const ptr = new PullToRefresh({
            onRefresh: async () => {
                // Short delay to allow the "refreshing" animation to be seen
                await new Promise(resolve => setTimeout(resolve, 800));
                window.location.reload();
            }
        });
        ptr.init();

        // 0. Initialize Stores (Non-UI)

        // CRITICAL DEPLOYMENT FIX: Force Unregister Service Worker to fix stale cache issues (User reported stuck on old version)
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.getRegistrations().then(function (registrations) {
                for (let registration of registrations) {
                    registration.unregister();
                }
            });
        }

        // Initialize Navigation Manager (Back Button Support)
        navManager.init();

        // v1153: Handle Deep Links (Announcements, etc.)
        this._handleDeepLinks();

        // 1. Event Bindings (Global)
        this._bindGlobalEvents();
        this._setupDelegatedEvents(); // Binds Delete, Watchlist Actions, etc.

        // --- NETWORK MONITORING (Live Response) ---
        window.addEventListener('online', () => {
            if (this.headerLayout) {
                const isReady = this._userDataLoaded && AppState.isDataReady;
                this.headerLayout.updateConnectionStatus(AppState.user !== null, isReady ? AppState.health.status : 'loading');
            }
            ToastManager.info('Connection restored. Updating market prices...');

            // Re-fetch prices on reconnection to ensure fresh data
            this._refreshAllPrices(AppState.data.shares || [], true).catch(err => {
                console.error('[AppController] Failed to refresh prices on reconnect:', err);
            });

            // Sync user preferences on reconnect
            if (AppState.user) {
                this.dataService.syncUserSettings(AppState.user.uid).catch(err => {
                    console.error('[AppController] Failed to sync user settings on reconnect:', err);
                });
            }
        });

        window.addEventListener('offline', () => {
            if (this.headerLayout) {
                this.headerLayout.updateConnectionStatus(AppState.user !== null, 'offline');
            }
            ToastManager.warn('Connection lost. Running in offline mode.');
        });

        // Notification System Bindings (Unified)
        NotificationUI.init(); // Initialize Floating Bell

        // --- REACTIVE DATA ARCHITECTURE (v1137+) ---
        // Decouples Firestore updates from the Controller's init flow
        StateAuditor.on('DATA_UPDATED', async (userData) => {
            if (!userData) return;

            // Sync to AppState (Local Cache)
            AppState.data = userData;
            this._userDataLoaded = true;
            AppState.isDataReady = true;

            // Update Connection Indicator now that Firestore data is resolved into local memory
            if (this.headerLayout && AppState.user) {
                const targetHealth = (AppState.lastGlobalFetch > 0 && (AppState.health?.consecutiveFailures || 0) === 0)
                    ? 'healthy'
                    : (AppState.health?.status || 'healthy');
                this.headerLayout.updateConnectionStatus(true, targetHealth);
            }

            // ONBOARDING GATE: Handles Race Condition between Data and Prefs
            if (await this._checkAndTriggerOnboarding()) return;

            // UI Refresh / Restoration
            if (this.watchlistUI) {
                this.watchlistUI.renderWatchlistDropdown();
                this.watchlistUI.updateHeaderTitle();
            }

            // === GLOBAL PRICE SEEDING ===
            // Fire initial fetch immediately as soon as auth/state is ready without artificial delay
            (async () => {
                await this._refreshAllPrices(AppState.data.shares || [], true);
                this._checkSnapshotNecessity();
            })();

            // === WATCHLIST RESTORATION (First Run Only) ===
            if (!this._initialWatchlistRestored) {
                this._initialWatchlistRestored = true; // v1140: Mark immediately to prevent race
                const savedId = AppState.preferences.lastWatchlistId || 'portfolio';
                this.handleSwitchWatchlist(savedId, true);

                // v1143: Run Data Health Check on first load to detect and repair Ghost items
                setTimeout(() => {
                    this.appService.performDataHealthCheck();
                }, 2000); // 2s delay to allow other boot systems to settle
            }

            // Trigger UI Refresh if not locked
            if (!AppState.isLocked && this.watchlistUI && AppState.watchlist.id) {
                this.updateDataAndRender(false);
            }
        });

        // REACTIVE REFRESH: Centralize UI updates when prices arrive
        StateAuditor.on('PRICES_UPDATED', () => {
            AppState.health.status = 'healthy';
            AppState.health.consecutiveFailures = 0;
            document.body.classList.remove('is-stale');
            if (this.headerLayout && AppState.user) {
                this.headerLayout.updateConnectionStatus(true, 'healthy');
            }
            this.checkAppHealth(); // Evaluate freshness to clear stale styling immediately
            // Live sync finished: it is now safe for the quiet sparkline refresher to run.
            if (this.dataService) this.dataService.armSparklineRefresher();
            if (!AppState.isLocked && this.watchlistUI && AppState.watchlist.id) {
                this.updateDataAndRender(false);
            }
        });

        // --- REACTIVE AUTH ARCHITECTURE (v1137+) ---
        StateAuditor.on('AUTH_CHANGE', async ({ user, wasLoggedIn, isSameUser }) => {
            const logoutBtn = document.getElementById(IDS.LOGOUT_BTN);
            const loginBtn = document.getElementById(IDS.AUTH_BTN);

            if (user) {
                // UI State Update for Login
                if (logoutBtn) logoutBtn.classList.remove(CSS_CLASSES.HIDDEN);
                if (loginBtn) loginBtn.classList.add(CSS_CLASSES.HIDDEN);
                document.body.classList.add(CSS_CLASSES.LOGGED_IN);

                // Provisioning / Reset (New User/Session)
                if (!isSameUser) {
                    this._setSignInLoadingState(true, 'Signing In...');
                    this.appService.provisionUser(user.uid);
                    this._initialized = false;
                    this._userDataLoaded = false;
                    AppState.isDataReady = false;
                    this._cloudPrefsLoaded = false;
                    this._localPrefsTimestamp = 0; // Reset local prefs timestamp for new user/session
                    this._lastSyncedPrefsSignature = null;
                    this._syncingPreferences = false; // Re-entrancy guard for Cloud Sync
                    this._isUnlockedThisSession = false;
                }

                // Security Challenge
                // v1138: Removed redundant call - _applyCloudPreferences will trigger this once prefs arrive.
                // this.handleSecurityLock();

                // Start Notification Stream
                notificationStore.init(user.uid);


                // Update Connection Indicator: Keep loading until Firestore data resolves
                if (this.headerLayout) {
                    const currentHealth = (this._userDataLoaded && AppState.isDataReady) ? AppState.health.status : 'loading';
                    this.headerLayout.updateConnectionStatus(true, currentHealth);
                }
            } else {
                // UI State Update for Logout
                this._userDataLoaded = false;
                AppState.isDataReady = false;
                if (logoutBtn) logoutBtn.classList.add(CSS_CLASSES.HIDDEN);
                if (loginBtn) loginBtn.classList.remove(CSS_CLASSES.HIDDEN);
                document.body.classList.remove(CSS_CLASSES.LOGGED_IN);

                if (this.headerLayout) {
                    this.headerLayout.updateConnectionStatus(false, 'offline');
                }

                // v1145: CRITICAL: Enable the sign-in button once we confirm user is logged out.
                // This resolves the "Initializing..." loop on splash screen.
                this._setSignInLoadingState(false);
            }
        });

        // Trigger Health Monitor & Adaptive Polling Engine
        this.startHealthMonitor();
        this.startAdaptivePolling();

        // Initialize Global CSS Variables from Prefs (USER REQUEST - Standardized)
        const accentHex = AppState.preferences.accentColor || '#a49393';
        const accentOpacity = AppState.preferences.accentOpacity || '1';
        const r = parseInt(accentHex.slice(1, 3), 16);
        const g = parseInt(accentHex.slice(3, 5), 16);
        const b = parseInt(accentHex.slice(5, 7), 16);
        document.documentElement.style.setProperty('--color-accent', `rgba(${r}, ${g}, ${b}, ${accentOpacity})`);
        document.documentElement.style.setProperty('--color-accent-rgb', `${r}, ${g}, ${b}`);
        document.documentElement.style.setProperty('--accent-opacity', accentOpacity);

        // Standardized Gradient & Tint (Directive 025 Alignment)
        const strength = AppState.preferences.gradientStrength ?? 0.25;
        const tint = strength === 0.125 ? '22%' : '0%';
        document.documentElement.style.setProperty('--gradient-strength', strength);
        document.documentElement.style.setProperty('--gradient-tint', tint);

        // Apply Card Chart Opacity
        const cardChartOpacity = AppState.preferences.cardChartOpacity ?? 1.0;
        document.documentElement.style.setProperty('--card-chart-opacity', cardChartOpacity);



        // Update Badge Listener (Single)
        document.addEventListener(EVENTS.NOTIFICATION_UPDATE, (e) => {
            let { totalCount, customCount } = e.detail;

            // Handle forced updates from Settings or other areas that don't provide counts
            if ((totalCount === undefined || customCount === undefined) && notificationStore) {
                const counts = notificationStore.getBadgeCounts();
                totalCount = counts.total;
                customCount = counts.custom;
            }

            // 1. Update Header (Sidebar Badge)
            if (this.headerLayout) {
                this.headerLayout.updateNotificationBadge(totalCount, customCount);
            }
            // Note: NotificationUI handles its own (Floating Bell) badge update via internal listener.
        });
        // General App Settings (Formerly Security/Data) - REINSTATED
        // General App Settings (Unified Hub)
        document.addEventListener(EVENTS.OPEN_GENERAL_SETTINGS, () => {
            GeneralSettingsUI.showModal(this);
        });

        document.addEventListener('open-calculator', () => {
            try {
                CalculatorUI.showModal();
            } catch (err) {
                console.error('[AppController] Error opening CalculatorUI:', err);
            }
        });

        document.addEventListener(EVENTS.OPEN_CURRENCY || 'open-currency', () => {
            try {
                CurrencyModalUI.showModal();
            } catch (err) {
                console.error('[AppController] Error opening CurrencyModalUI:', err);
            }
        });



        document.addEventListener('open-visual-settings', () => {
            GeneralSettingsUI.showAppearanceModal();
        });

        // Sidebar Control
        document.addEventListener('close-sidebar', () => {
            if (this.headerLayout) this.headerLayout.closeSidebar();
        });



        // Quick Nav Listener
        document.addEventListener(EVENTS.REQUEST_QUICK_NAV, (e) => {
            this._handleQuickNav(e.detail);
        });

        // 3. LIVE READ-ONLY CHECK (On Resume/Re-Focus)
        // If we have data but no user, remind them they are in Read-Only mode
        // 3. LIVE READ-ONLY & VISIBILITY RESUME (On Resume/Re-Focus)
        // GUARD: Wait 3 seconds before complaining about auth.
        // Android sleeping disconnects WS, needs time to handshake.
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') {
                // Re-evaluate health and market session immediately
                this.checkAppHealth();

                if (AppState.data.shares.length > 0) {
                    setTimeout(() => {
                        // Double check: Still no user after 3s grace?
                        if (!AppState.user) {
                            if (this.headerLayout) this.headerLayout.updateConnectionStatus(false, 'offline');
                        } else {
                            // Recovered! Ensure we show connected if data ready, or loading if pending
                            const isReady = this._userDataLoaded && AppState.isDataReady;
                            if (this.headerLayout) this.headerLayout.updateConnectionStatus(true, isReady ? AppState.health.status : 'loading');
                            // Optional: Silent refresh to ensure token is fresh
                            AuthService.refreshSession();
                        }
                    }, 3000);
                }

                // If user returned and market is actively trading, refresh if data is older than 60s
                if (AppState.user && !AppState._isFetching) {
                    const isTrading = MarketSchedule.isASXTrading();
                    const age = Date.now() - (AppState.lastGlobalFetch || 0);
                    if (isTrading && age > 60 * 1000) {
                        this._refreshAllPrices(AppState.data.shares || [], false, true);
                    }
                }

                // Reschedule adaptive polling cycle
                this._scheduleNextPoll();
            }
        });

        document.addEventListener(EVENTS.OPEN_SETTINGS, () => {
            SettingsUI.showModal(AppState.user?.uid);
        });



        document.addEventListener(EVENTS.OPEN_PORTFOLIO_CHART, () => {
            try {
                PortfolioChartUI.show();
            } catch (err) {
                console.error('[AppController] Error opening PortfolioChartUI:', err);
            }
        });

        // CUSTOM NAVIGATION EVENTS (Briefing / External)
        document.addEventListener(EVENTS.OPEN_PORTFOLIO_VIEW, () => {
            // Check if we are in Dashboard view or Watchlist view?
            // Force switch to 'portfolio' watchlist
            if (this.watchlistUI) {
                this.handleSwitchWatchlist('portfolio');
            }
            // Ensure sidebar/header reflects this (handled by state change)
        });

        // OPEN_NOTIFICATIONS listener removed (Handled by NotificationUI.js with debounce)

        document.addEventListener(EVENTS.OPEN_MARKET_PULSE, () => {
            try {
                SnapshotUI.show();
            } catch (err) {
                console.error('[AppController] Error opening SnapshotUI:', err);
            }
        });

        // Mute Toggle Listener
        document.addEventListener(EVENTS.TOGGLE_SHARE_MUTE, async (e) => {
            if (!AppState.user) return;
            let { id, code } = e.detail;

            // GHOST RESURRECTION: If ID is null OR is a temp ID, treat as needing sync before setting prefs
            const isTempId = id && String(id).startsWith('temp_');
            if ((!id || isTempId) && code) {
                // GUARD: Prevent double-tap resurrection
                if (this._resurrectionGuard && this._resurrectionGuard.has(code)) {
                    return;
                }

                // Init Guard
                if (!this._resurrectionGuard) this._resurrectionGuard = new Set();
                this._resurrectionGuard.add(code);

                try {
                    // LAST-SECOND CHECK: Maybe the ID just arrived in a snapshot or update?
                    const codeUpper = code.toUpperCase();
                    const existingReal = AppState.data.shares.find(s => (s.shareName || s.code || '').toUpperCase() === codeUpper && s.id && !String(s.id).startsWith('temp_'));

                    // Also check the Guarded ID Registry
                    const guardedId = AppState.data.optimisticIds ? AppState.data.optimisticIds.get(codeUpper) : null;

                    if (existingReal || guardedId) {
                        id = existingReal ? existingReal.id : guardedId;
                    } else {
                        // 1. Resolve Best Local Reference
                        const candidates = AppState.data.shares.filter(s => (s.shareName || s.code || '').toUpperCase() === codeUpper);
                        const localShare = candidates.sort((a, b) => (b.id ? 1 : 0) - (a.id ? 1 : 0))[0];
                        const watchlistId = localShare ? (localShare.watchlistId || 'portfolio') : 'portfolio';

                        // 2. Create/Link (Resurrect)
                        id = await this.appService.addStock(code, watchlistId, 0, new Date().toISOString());

                        if (id) {
                            // SUCCESS: Update localized memory
                            if (localShare) localShare.id = id;
                            candidates.forEach(s => { if (!s.id) s.id = id; });

                            // POPULATE GUARD: Ensure this ID survives snapshot refreshes
                            // POPULATE GUARD: Ensure this ID survives snapshot refreshes
                            if (AppState.data.optimisticIds) {
                                AppState.data.optimisticIds.set(codeUpper, id);
                            }

                            this.updateDataAndRender(false);
                        }
                    }
                } catch (err) {
                    console.error('AppController: Resurrection failed during Mute:', err);
                    ToastManager.error('Could not sync share settings. Please refresh.');
                    this._resurrectionGuard.delete(code);
                    return;
                } finally {
                    this._resurrectionGuard.delete(code);
                }
            }

            // Source of Truth: Prioritize Event Detail (from DOM Render) over potentially stale AppState
            let currentMuted = false;
            if (e.detail.muted !== undefined) {
                currentMuted = e.detail.muted === true || e.detail.muted === 'true';
            } else {
                const share = AppState.data.shares.find(s => s.id === id);
                currentMuted = share ? !!share.muted : false;
            }

            const shareToUpdate = AppState.data.shares.find(s => s.id === id);

            if (shareToUpdate || id) {
                const newStatus = !currentMuted;

                // OPTIMISTIC UPDATE: Update local state IMMEDIATELY
                if (shareToUpdate) {
                    shareToUpdate.muted = newStatus;
                    if (this.notificationStore) this.notificationStore.recalculateBadges();
                    this.updateDataAndRender(false);
                }

                // Fire and Forget
                try {
                    await this.appService.updateShareRecord(id, { muted: newStatus });
                } catch (err) {
                    console.error('Mute Toggle Failed:', err);
                    if (shareToUpdate) {
                        shareToUpdate.muted = !newStatus;
                        this.updateDataAndRender(false);
                    }
                    ToastManager.error('Failed to update mute status.');
                    return;
                }
                // 3. User Feedback
                const statusText = newStatus ? 'Muted' : 'Unmuted';
                ToastManager.info(`${shareToUpdate ? (shareToUpdate.code || 'Share') : 'Share'} is now ${statusText}.`);

                if (this.notificationStore) {
                    this.notificationStore.recalculateBadges();
                }
            }
        });

        // Dividend Override Listener
        document.addEventListener(EVENTS.DIV_OVERRIDE_CLICK, async (e) => {
            const { ticker, current } = e.detail;
            const user = AppState.user;
            if (!user) {
                ToastManager.error(USER_MESSAGES.AUTH_REQUIRED);
                return;
            }

            const input = prompt(`Manual Franking Override for ${ticker}\nEnter percentage (0-100):`,
                current !== null ? Math.round(current * 100) : "100");

            if (input === null) return;

            const pct = parseFloat(input);
            if (isNaN(pct) || pct < 0 || pct > 100) {
                ToastManager.error("Please enter a valid percentage between 0 and 100.");
                return;
            }

            const frankingValue = pct / 100;
            await this.appService.saveDividendOverride(ticker, { franking: frankingValue });

            // 2. IMMEDIATE UI REFRESH (for the open modal/card)
            // We find the open dividend card by its standard ID pattern
            const cardId = `divHeroCard_${ticker}`;
            const container = document.getElementById(cardId);
            if (container && this.viewRenderer) {
                // Find current data context
                const allShares = AppState.data.shares || [];
                const stock = allShares.find(s => (s.shareName || s.code || '').toUpperCase() === ticker.toUpperCase());
                const priceData = AppState.livePrices?.get(ticker.toUpperCase());
                const price = priceData ? priceData.live : 0;

                if (stock) {
                    // Re-trigger the async hydration to update the specific card element
                    this.viewRenderer._hydrateDividendCard(container, stock, price);
                }
            }

            // 3. Trigger re-analysis and re-render for the watchlist
            this.updateDataAndRender(false);
        });


        // 2. RECONNECTION SAFETY NET
        // If UserStore detects a write failure (permission-denied), it fires this event.
        // We prompt the user to "One-Tap Reconnect" using the Smart Login hint.
        document.addEventListener('auth-reconnect-needed', () => {

            // Only show if not already showing
            if (document.getElementById('reconnect-toast')) return;

            ToastManager.show(
                'Session expired. Tap to Reconnect & Save.',
                'error',
                'Reconnect',
                async () => {
                    try {
                        const user = await AuthService.signIn();
                        if (user) {
                            ToastManager.show('Connected! Retrying save...', 'success');
                            // The failed write in UserStore isn't automatically retried here, 
                            // but the NEXT write (or user clicking save again) will work.
                            // Ideally, we'd queue the pending write, but minimizing complexity first.
                            document.dispatchEvent(new CustomEvent(EVENTS.FIREBASE_DATA_LOADED));
                        }
                    } catch (e) {
                        console.error('Reconnection failed:', e);
                        ToastManager.show('Connection failed. Please reload.', 'error');
                    }
                }
            );
        });

        // 2. Initialize Watchlist UI
        this.watchlistUI = new WatchlistUI({
            onWatchlistChange: (watchlistId) => this.handleSwitchWatchlist(watchlistId),
            onRenameWatchlist: async (id, name) => {
                const systemIds = [ALL_SHARES_ID, PORTFOLIO_ID, CASH_WATCHLIST_ID, DASHBOARD_WATCHLIST_ID, SIMULATIONS_WATCHLIST_ID, 'portfolio'];
                if (systemIds.includes(id)) {
                    AppState.saveCustomWatchlistName(id, name);
                    return;
                }
                await this.appService.renameWatchlist(id, name);
            },
        });
        this.watchlistUI.init();

        // 2a. Initialize Cash Controller
        this.cashController.init();

        // Listen for Open Notifications Request
        // (Handled above in consolidated block)

        // 3. Initialize Header Layout
        this.headerLayout = new HeaderLayout({
            onViewChange: (mode) => this.changeViewMode(mode),
            onViewToggle: () => this._handleViewToggle(),
            onSort: () => this._handleSortClick(),
            onCarouselPrev: () => this._handleCarousel(-1),
            onCarouselNext: () => this._handleCarousel(1),
            onOpenCalculator: (mode) => this.calculatorUI.open(mode)
        });
        this.headerLayout.init();
        // Force update initial icon state from persisted pref
        this.headerLayout.updateViewToggleIcon(AppState.viewMode);

        // Sort Toggle Listener (Chevron in Title Bar)
        document.addEventListener(EVENTS.TOGGLE_SORT_DIRECTION, () => {
            this._handleSortToggle();
        });

        // 3b. Initialize Calculator UI
        this.calculatorUI = new CalculatorUI();

        // 3c. Initialize QuickNav UI
        this.quickNavUI.init();

        // Make headerLayout available to other parts if needed via singleton pattern or internal referencing
        // Logic in main.js used 'headerLayout.closeSidebar' in callbacks. 
        // We can expose a method on AppController for this.

        // 3d. Initialize Core Feature UIs
        ResearchLinksUI.init();
        FavoriteLinksUI.init();

        // 4. Auth Observation
        AuthService.observeState((user) => this.handleAuthStateChange(user));


        // 5. Default Dark Theme Enforced
        document.body.classList.add(CSS_CLASSES.DARK_THEME);

        // 6. Setup Cloud Sync Hook (Outbound)
        // BOOT LOCK: Prevent outbound sync until cloud prefs have been received once.
        // This prevents empty localStorage from overwriting valid cloud data.
        // 6. Setup Cloud Sync Hook (Outbound)
        // BOOT LOCK: Prevent outbound sync until cloud prefs have been received once.
        // This prevents empty localStorage from overwriting valid cloud data.
        this._cloudPrefsLoaded = false;
        this._userDataLoaded = false; // Race condition guard


        AppState.onPersistenceUpdate = (prefs) => {
            this._syncPreferencesToCloud(prefs);
        };

        // 7. Watchlist Restoration is handled in handleAuthStateChange
        //    (after data is loaded from Firebase)

        // 8. Setup Delegated Events (Legacy DOM logic)
        this._setupDelegatedEvents();

        // 9. Visibility/Lifecycle Handlers (Security)
        this._setupLifecycleHandlers();

        // 8. Expose Globals - REMOVED (Sanitized)
        // Global pollution has been replaced with Event Delegation in _setupDelegatedEvents()
    }

    /**
     * Debounced wrapper for outbound preference synchronization.
     * Prevents rapid UI changes (like toggling multiple checkboxes) from 
     * causing "local echo" race conditions in Firestore.
     * @param {Object} prefs Simple object containing preference keys to sync
     */
    _syncPreferencesToCloud(prefs) {
        if (!this._cloudPrefsLoaded) {
            // Still check security if enabled on another device
            if (prefs.security && (prefs.security.isPinEnabled || prefs.security.isBiometricEnabled)) {
                this.handleSecurityLock();
            }
            return;
        }

        if (!AppState.user) {
            return;
        }

        // Set the in-memory timestamp immediately on local edit
        this._localPrefsTimestamp = Date.now();

        // Clear existing timer
        if (this._syncTimeout) {
            clearTimeout(this._syncTimeout);
        }

        // Schedule sync
        this._syncTimeout = setTimeout(async () => {
            try {
                // REFRESH DATA (Directive 025):
                // To prevent "Stale Snapshot Race Conditions", we explicitly read fresh state 
                // for critical fields that might have been hydrated during the debounce window.
                const freshPrefs = {
                    ...prefs,
                    modified: this._localPrefsTimestamp,
                    hiddenAssets: [...AppState.hiddenAssets], // Fresh Read
                    sortConfigMap: AppState.sortConfigMap,     // Fresh Read
                    carouselSelections: [...AppState.carouselSelections],
                    hiddenWatchlists: [...AppState.hiddenWatchlists],
                    watchlistOrder: AppState.preferences.watchlistOrder,
                    dashboardOrder: AppState.preferences.dashboardOrder, // Fresh Read
                    dashboardHidden: AppState.preferences.dashboardHidden, // Fresh Read
                    userCategories: AppState.preferences.userCategories || [],
                    gradientStrength: AppState.preferences.gradientStrength, // Fresh Read (USER REQUEST)
                    containerBorders: AppState.preferences.containerBorders, // Fresh Read (USER REQUEST)
                    badgeScope: AppState.preferences.badgeScope, // Fresh Read
                    showBadges: AppState.preferences.showBadges,  // Fresh Read
                    customWatchlistNames: AppState.preferences.customWatchlistNames || {}, // Fresh Read
                    accentColor: AppState.preferences.accentColor, // Fresh Read
                    accentOpacity: AppState.preferences.accentOpacity, // Fresh Read
                    cardChartOpacity: AppState.preferences.cardChartOpacity, // Fresh Read
                    researchLinks: AppState.preferences.researchLinks || [], // Fresh Read
                    favoriteLinks: AppState.preferences.favoriteLinks || [],  // Fresh Read
                    viewMode: AppState.viewMode, // Fresh Read
                    widgetConfig: AppState.preferences.widgetConfig || null, // Fresh Read (Fix Persistence)
                    widgetDashboardItems: AppState.preferences.widgetDashboardItems || null, // Fresh Read (Fix Persistence)
                    scannerRules: AppState.preferences.scannerRules || {}, // Fresh Read (Fix Notification Persistence)
                    scanner: AppState.preferences.scanner || {}, // Fresh Read (Fix Notification Persistence)
                    excludePortfolio: AppState.preferences.excludePortfolio ?? true // Fresh Read (Fix Notification Persistence)
                };

                if (freshPrefs.userCategories) {
                }
                // if (freshPrefs.hiddenAssets) {
                // }
                // Skip sync if payload data has not meaningfully changed
                const { modified: _, ...comparablePrefs } = freshPrefs;
                const currentPrefsSignature = JSON.stringify(comparablePrefs);
                if (this._lastSyncedPrefsSignature === currentPrefsSignature) {
                    return; // Unchanged data: skip redundant Firestore write & Apps Script call
                }

                await this.appService.saveUserPreferences(freshPrefs);
                this._lastSyncedPrefsSignature = currentPrefsSignature;

                if (AppState.user) {
                    await this.dataService.syncUserSettings(AppState.user.uid);
                }
            } catch (err) {
                console.warn('Sync failed:', err);
            } finally {
                this._syncTimeout = null;
            }
        }, 3500); // 3.5s debounce (lengthened to protect free quota)
    }

    _handleQuickNav(detail) {
        let targetContext = 'center';
        if (detail && detail.targetContext) {
            targetContext = detail.targetContext;
        }

        let config = null;
        if (detail && detail.watchlistId) {
            config = detail;
        } else {
            if (targetContext === 'left') {
                config = AppState.preferences.quickNavLeft;
            } else if (targetContext === 'right') {
                config = AppState.preferences.quickNavRight;
            } else {
                config = AppState.preferences.quickNav;
            }
        }

        if (!config) {
            this.quickNavUI.show(targetContext);
            return;
        }

        // Gracefully close widget panel if it is open during navigation
        const widgetEl = document.getElementById('widget-panel');
        if (widgetEl && !widgetEl.classList.contains(CSS_CLASSES.WIDGET_HIDDEN)) {
            document.dispatchEvent(new CustomEvent(EVENTS.WIDGET_TOGGLE));
        }

        const { watchlistId, sortField, sortDirection } = config;
        const currentWatchlistId = AppState.watchlist.id || 'portfolio';

        // Are we already there?
        const isSameWatchlist = (watchlistId === 'portfolio' && (currentWatchlistId === 'portfolio' || currentWatchlistId === null)) ||
            (watchlistId === currentWatchlistId);

        // Check sort match
        const currentSort = AppState.sortConfig;
        const isSameSort = currentSort.field === sortField && currentSort.direction === sortDirection;

        // Determine if this config is a user preference for editing
        const isUserPreference = (config === AppState.preferences.quickNavLeft ||
            config === AppState.preferences.quickNavRight ||
            config === AppState.preferences.quickNav);

        if (isSameWatchlist && isSameSort && isUserPreference) {
            this.quickNavUI.show(targetContext);
        } else {
            // Execute Navigation
            AppState._skipSortRestore = true;
            try {
                this.handleSwitchWatchlist(watchlistId);
            } finally {
                AppState._skipSortRestore = false;
            }

            // Execute Sort
            this._applySort({ field: sortField, direction: sortDirection });

            // Optional: Toast feedback? 
            // ToastManager.show(`Quick Nav: ${watchlistId}`, 'success');
        }
    }


    /* ==========================================================================
       HELPER METHODS
       ========================================================================== */

    /**
     * Checks if new user onboarding is required and executes it.
     * Handles race conditions between Data and Prefs loading.
     * @returns {Promise<boolean>} True if onboarding was triggered
     */
    async _checkAndTriggerOnboarding() {
        // Gates: Must have Data AND Prefs loaded
        if (!this._userDataLoaded || !this._cloudPrefsLoaded) return false;

        // Gates: Must be authenticated and not already triggered
        if (!AppState.user || this._onboardingTriggered) return false;

        // Check 1: Cloud Pref 'onboarded' flag (Source of Truth)
        if (AppState.preferences.onboarded) return false;

        // Check 2: Data Emptiness (Double Check)
        // If shares OR watchlists exist, we assume seasoned user (or partial state)
        if (AppState.data.shares?.length > 0 || (AppState.data.watchlists?.length > 0)) {
            return false;
        }

        this._onboardingTriggered = true;

        try {
            await this.appService.createDefaultOnboardingData(AppState.user.uid);

            // FORCE SWITCH: Align local state with the cloud preference we just wrote ('ALL')
            // This prevents race conditions where local 'portfolio' state overwrites cloud 'ALL'.
            this.handleSwitchWatchlist('ALL');
            return true;
        } catch (e) {
            console.error('[AppController] Onboarding failed:', e);
            return false;
        }
    }

    /**
     * Seeds the Live Price cache with ALL user shares.
     * Ensures Search and other views have data even if not visiting a specific watchlist.
     * Uses Promise-deduplication to prevent concurrent overlapping requests to Google Apps Script.
     * @param {Array} shares - List of user shares
     * @param {boolean} force - If true, bypasses the 5-minute freshness guard
     * @param {boolean} silent - If true, suppresses slow connection toast notifications (for background syncs)
     */
    async _refreshAllPrices(shares, force = false, silent = true) {
        // 1. IN-FLIGHT PROMISE SHARING (Deduplication)
        // If a fetch is currently in progress, join and await the active pending promise!
        if (this._activeFetchPromise) {
            return this._activeFetchPromise;
        }

        // 2. FRESHNESS GUARD: Adaptive threshold with safety buffer below polling intervals
        // Buffer absorbs network latency and timer drift so scheduled polls are never blocked.
        const now = Date.now();
        const isTrading = MarketSchedule.isASXTrading();
        const asxSession = MarketSchedule.getASXStatus().session;
        const minInterval = isTrading 
            ? 3 * 60 * 1000 // 3m during active trading (1m buffer below 4m poll; well below 5m staleness)
            : (asxSession === ASX_SESSION.PRE_OPEN ? 4 * 60 * 1000 : 12 * 60 * 1000); // 4m pre-open, 12m closed

        if (!force && AppState.lastGlobalFetch && (now - AppState.lastGlobalFetch < minInterval)) {
            return;
        }

        let codesToFetch = [...new Set((shares || []).map(s => s.shareName))].filter(Boolean);

        // Include Dashboard Symbols ALWAYS
        DASHBOARD_SYMBOLS.forEach(code => {
            const upCode = code.toUpperCase();
            if (!codesToFetch.includes(upCode)) codesToFetch.push(upCode);
        });

        if (codesToFetch.length === 0) return;

        AppState._isFetching = true;
        this._lastFetchAttemptTime = Date.now();

        // Create the promise and store it in this._activeFetchPromise
        this._activeFetchPromise = (async () => {
            try {
                const result = await this.dataService.fetchLivePrices(codesToFetch, silent);
                const freshPrices = result?.prices;
                const freshDashboard = result?.dashboard;

                if (result?.ok && freshPrices && freshPrices.size > 0) {
                    // Non-destructive merge: Never overwrite a valid cached price with 0/NaN
                    const mergedPrices = new Map(AppState.livePrices);
                    freshPrices.forEach((freshVal, code) => {
                        const existing = mergedPrices.get(code);
                        const isFreshLiveValid = Number.isFinite(freshVal?.live) && freshVal.live > 0;
                        const isFreshPrevValid = Number.isFinite(freshVal?.prevClose) && freshVal.prevClose > 0;

                        if (existing && !isFreshLiveValid && !isFreshPrevValid) {
                            // Fresh quote is completely invalid/zeroed; retain valid existing price
                            mergedPrices.set(code, {
                                ...freshVal,
                                live: existing.live || existing.prevClose || 0,
                                prevClose: existing.prevClose || existing.live || 0,
                                lastUpdate: Date.now()
                            });
                        } else if (existing && !isFreshLiveValid && isFreshPrevValid) {
                            // Fresh has prevClose (e.g. out of hours); use prevClose as live baseline
                            mergedPrices.set(code, {
                                ...freshVal,
                                live: freshVal.prevClose,
                                lastUpdate: Date.now()
                            });
                        } else {
                            mergedPrices.set(code, freshVal);
                        }
                    });

                    AppState.livePrices = mergedPrices;
                    AppState.saveLivePricesToCache();
                    AppState.lastGlobalFetch = Date.now();
                    AppState.health.consecutiveFailures = 0;
                    AppState.health.status = 'healthy';
                    AppState.health.sessionStartTime = Date.now();
                    document.body.classList.remove('is-stale');
                    if (this._retryTimer) {
                        clearTimeout(this._retryTimer);
                        this._retryTimer = null;
                    }

                    // Release in-flight fetch lock immediately before notifying indicator and state listeners
                    AppState._isFetching = false;
                    this._activeFetchPromise = null;

                    if (this.headerLayout) {
                        this.headerLayout.updateConnectionStatus(true, 'healthy');
                    }

                    if (freshDashboard && Array.isArray(freshDashboard)) {
                        AppState.data.dashboard = freshDashboard;
                    }
                    // BROADCAST: Notify all subscribed components that prices have been refreshed.
                    StateAuditor.emit('PRICES_UPDATED', {
                        count: freshPrices.size,
                        totalCached: AppState.livePrices.size,
                        hasDashboard: !!(freshDashboard && freshDashboard.length > 0),
                        timestamp: AppState.lastGlobalFetch,
                        serverTimestamp: result?.serverTimestamp || null,
                        isManual: !silent
                    });
                } else {
                    // Fetch failed (result.ok is false or empty)
                    AppState.health.consecutiveFailures = (AppState.health.consecutiveFailures || 0) + 1;
                    if (AppState.health.consecutiveFailures >= 3) {
                        AppState.health.status = 'stale';
                        document.body.classList.add('is-stale');
                        if (this.headerLayout) {
                            this.headerLayout.updateConnectionStatus(true, 'stale');
                        }
                    } else {
                        console.warn(`[AppController] Fetch attempt failed quietly (strike ${AppState.health.consecutiveFailures}/3).`);
                        this._scheduleFastRetry(12000);
                    }
                }
            } catch (err) {
                console.warn('[AppController] Global Price Fetch error:', err);
                AppState.health.consecutiveFailures = (AppState.health.consecutiveFailures || 0) + 1;
                if (AppState.health.consecutiveFailures >= 3) {
                    AppState.health.status = 'stale';
                    document.body.classList.add('is-stale');
                    if (this.headerLayout) {
                        this.headerLayout.updateConnectionStatus(true, 'stale');
                    }
                } else {
                    console.warn(`[AppController] Price fetch error strike ${AppState.health.consecutiveFailures}/3. Failing quietly.`);
                    this._scheduleFastRetry(12000);
                }
            } finally {
                AppState._isFetching = false;
                this._activeFetchPromise = null;
            }
        })();

        return this._activeFetchPromise;
    }

    /* ================= Logic Handlers ================= */

    async handleAuthStateChange(user) {
        const wasLoggedIn = !!AppState.user;
        const isSameUser = (user && AppState.user && user.uid === AppState.user.uid);

        AppState.user = user;

        // v1137: BROADCAST: Let reactive listeners handle the heavy lifting
        StateAuditor.emit('AUTH_CHANGE', { user, wasLoggedIn, isSameUser });

        if (user) {
            // CRITICAL: Only Unsub/Resub if user CHANGED.
            if (!isSameUser || !AppState.unsubscribeStore) {
                if (AppState.unsubscribeStore) AppState.unsubscribeStore();
                if (AppState.unsubscribePrefs) AppState.unsubscribePrefs();

                // Reset Data Load (Race Guard)
                this._userDataLoaded = false;
                AppState.isDataReady = false;

                // === DATA SUBSCRIPTION ===
                AppState.unsubscribeStore = this.appService.subscribeToUserData(user.uid);

                // === CLOUD PREFERENCES SYNC (INBOUND) ===
                AppState.unsubscribePrefs = this.appService.subscribeToUserPreferences(user.uid, (prefs, metadata) => {
                    this._applyCloudPreferences(prefs, metadata);
                });
            }
        } else {
            // LOGOUT: Cleanup subscriptions
            if (this._retryTimer) clearTimeout(this._retryTimer);
            this._retryTimer = null;
            if (AppState.unsubscribeStore) AppState.unsubscribeStore();
            if (AppState.unsubscribePrefs) AppState.unsubscribePrefs();
            AppState.unsubscribeStore = null;
            AppState.unsubscribePrefs = null;
            AppState.isDataReady = false;
            this._userDataLoaded = false;
            this._cloudPrefsLoaded = false;
            this._localPrefsTimestamp = 0; // Reset local prefs timestamp on logout
            this._lastSyncedPrefsSignature = null;
        }
    }

    _applyCloudPreferences(prefs, metadata) {
        if (this._syncingPreferences) return; // RE-ENTRANCY GUARD (Directive 024)

        // Clear pending timeout since prefs arrived
        if (this._prefsTimeoutId) {
            clearTimeout(this._prefsTimeoutId);
            this._prefsTimeoutId = null;
        }

        if (!prefs) {
            // No prefs in cloud - complete initial render with defaults
            this._cloudPrefsLoaded = true; // Mark as loaded even if empty
            if (!this._initialRenderComplete) {
                this._initialRenderComplete = true;
                // Check lock based on local/default state before hiding splash
                this.handleSecurityLock();
            }
            return;
        }

        // SYNC GUARD (Directive 024): 
        // If the snapshot has pending writes (local echo).
        if (metadata && metadata.hasPendingWrites) {
            return;
        }

        // 3. CACHE HYDRATION (v1187):
        // If Firestore persistence is enabled, the first snapshot comes from cache.
        // We MUST allow this to hydrate AppState so that handleSecurityLock() can proceed.
        // We only block fromCache snapshots IF we already have fresher cloud data loaded.
        if (metadata && metadata.fromCache && this._cloudPrefsLoaded) {
            return;
        }

        // TIMESTAMP VALIDATION:
        // Accept and render immediately if the incoming cloud data has a newer timestamp.
        // Older or matching updates (e.g. echo of local actions) are safely ignored.
        const incomingTimestamp = prefs.modified || 0;
        if (this._cloudPrefsLoaded && incomingTimestamp <= this._localPrefsTimestamp) {
            return;
        }
        this._localPrefsTimestamp = Math.max(this._localPrefsTimestamp, incomingTimestamp);

        this._syncingPreferences = true; // LOCK
        try {
            // Mark as loaded before processing specific updates so handleSecurityLock works
            this._cloudPrefsLoaded = true;

            // Broadcast cloud prefs to decoupled stores
            document.dispatchEvent(new CustomEvent(EVENTS.CLOUD_PREFERENCES_LOADED, { detail: prefs }));

            let needsRender = false;

            // 0. Sync Security Prefs (CRITICAL: Prioritize this)
            if (prefs.security) {
                // Defensive: Merge and apply only if changed
                AppState.saveSecurityPreferences(prefs.security);
                this.handleSecurityLock();
            }

            // 00. Check Onboarding (Race Fix)
            this._checkAndTriggerOnboarding();

            // 0a. Sync Gradient Preference (Fixes Tinting Bug)
            if (prefs.gradientStrength !== undefined && prefs.gradientStrength !== null) {
                const strength = parseFloat(prefs.gradientStrength);
                if (!isNaN(strength) && AppState.preferences.gradientStrength !== strength) {
                    AppState.preferences.gradientStrength = strength;
                    localStorage.setItem(STORAGE_KEYS.GRADIENT_STRENGTH, strength);

                    const tint = strength === 0.125 ? '22%' : '0%';
                    document.documentElement.style.setProperty('--gradient-strength', strength);
                    document.documentElement.style.setProperty('--gradient-tint', tint);
                    needsRender = true;
                }
            }

            // 0a.1 Sync Accent Color & Opacity
            if (prefs.accentColor !== undefined || prefs.accentOpacity !== undefined) {
                const color = prefs.accentColor || AppState.preferences.accentColor || '#a49393';
                const opacity = prefs.accentOpacity || AppState.preferences.accentOpacity || '1';

                if (AppState.preferences.accentColor !== color || AppState.preferences.accentOpacity !== opacity) {
                    AppState.preferences.accentColor = color;
                    AppState.preferences.accentOpacity = opacity;
                    localStorage.setItem(STORAGE_KEYS.ACCENT_COLOR, color);
                    localStorage.setItem(STORAGE_KEYS.ACCENT_OPACITY, opacity);

                    const r = parseInt(color.slice(1, 3), 16);
                    const g = parseInt(color.slice(3, 5), 16);
                    const b = parseInt(color.slice(5, 7), 16);
                    document.documentElement.style.setProperty('--color-accent', `rgba(${r}, ${g}, ${b}, ${opacity})`);
                    document.documentElement.style.setProperty('--color-accent-rgb', `${r}, ${g}, ${b}`);
                    document.documentElement.style.setProperty('--accent-opacity', opacity);
                    needsRender = true;
                }
            }

            // 0a.2 Sync Card Chart Opacity
            if (prefs.cardChartOpacity !== undefined && prefs.cardChartOpacity !== null) {
                const val = parseFloat(prefs.cardChartOpacity);
                if (!isNaN(val) && AppState.preferences.cardChartOpacity !== val) {
                    AppState.preferences.cardChartOpacity = val;
                    localStorage.setItem(STORAGE_KEYS.CARD_CHART_OPACITY, val);
                    document.documentElement.style.setProperty('--card-chart-opacity', val);
                    needsRender = true;
                }
            }

            // 0a.3 Sync Container Borders
            if (prefs.containerBorders) {
                AppState.preferences.containerBorders = { ...AppState.preferences.containerBorders, ...prefs.containerBorders };
                localStorage.setItem(STORAGE_KEYS.BORDER_PREFS, JSON.stringify(AppState.preferences.containerBorders));
                needsRender = true;
            }



            // 0b. Sync Pinned Alerts
            if (prefs.pinnedAlerts !== undefined) {
                AppState.preferences.pinnedAlerts = Array.isArray(prefs.pinnedAlerts) ? prefs.pinnedAlerts : [];
            }

            // 0b. Sync Notification Prefs
            if (prefs.showBadges !== undefined && AppState.preferences.showBadges !== (prefs.showBadges !== false)) {
                AppState.preferences.showBadges = prefs.showBadges !== false;
                localStorage.setItem(STORAGE_KEYS.SHOW_BADGES, AppState.preferences.showBadges);
                needsRender = true;
            }
            if (prefs.quickNav !== undefined) {
                AppState.preferences.quickNav = prefs.quickNav;
                localStorage.setItem(STORAGE_KEYS.QUICK_NAV, JSON.stringify(prefs.quickNav));
                // No render needed, it's Just-In-Time
            }
            if (prefs.quickNavLeft !== undefined) {
                AppState.preferences.quickNavLeft = prefs.quickNavLeft;
                localStorage.setItem('ASX_NEXT_quickNav_left', JSON.stringify(prefs.quickNavLeft));
            }
            if (prefs.quickNavRight !== undefined) {
                AppState.preferences.quickNavRight = prefs.quickNavRight;
                localStorage.setItem('ASX_NEXT_quickNav_right', JSON.stringify(prefs.quickNavRight));
            }
            if (prefs.badgeScope !== undefined && AppState.preferences.badgeScope !== (prefs.badgeScope || 'all')) {
                AppState.preferences.badgeScope = prefs.badgeScope || 'all';
                localStorage.setItem(STORAGE_KEYS.BADGE_SCOPE, AppState.preferences.badgeScope);
                needsRender = true;

                // Ensure badge updates immediately if scope changed via cloud sync
                if (typeof notificationStore !== 'undefined' && notificationStore._notifyCountChange) {
                    notificationStore._notifyCountChange();
                }
            }
            if (prefs.alertEmailRecipients !== undefined) {
                AppState.preferences.alertEmailRecipients = prefs.alertEmailRecipients || '';
                localStorage.setItem(STORAGE_KEYS.EMAIL_RECIPIENTS, AppState.preferences.alertEmailRecipients);
            }
            if (prefs.excludePortfolio !== undefined) {
                AppState.preferences.excludePortfolio = prefs.excludePortfolio;
                localStorage.setItem(STORAGE_KEYS.EXCLUDE_PORTFOLIO, prefs.excludePortfolio);
            }
            if (prefs.scannerRules !== undefined) {
                AppState.preferences.scannerRules = { ...AppState.preferences.scannerRules, ...prefs.scannerRules };
                localStorage.setItem(STORAGE_KEYS.SCANNER_RULES_CACHE, JSON.stringify(AppState.preferences.scannerRules));
            }
            if (prefs.scanner !== undefined) {
                AppState.preferences.scanner = { ...AppState.preferences.scanner, ...prefs.scanner };
                if (prefs.scanner.activeFilters !== undefined) {
                    localStorage.setItem(STORAGE_KEYS.ACTIVE_FILTERS, JSON.stringify(prefs.scanner.activeFilters));
                }
            }
            if (prefs.dailyEmail !== undefined && prefs.dailyEmail !== null) {
                // ROBUSTNESS: Handle string 'true' from legacy/external updates
                const val = prefs.dailyEmail;
                const isTrue = (val === true || val === 'true');
                if (AppState.preferences.dailyEmail !== isTrue) {
                    AppState.preferences.dailyEmail = isTrue;
                    localStorage.setItem(STORAGE_KEYS.DAILY_EMAIL, isTrue);
                    needsRender = true;
                }
            }

            if (prefs.colorSeed !== undefined && prefs.colorSeed !== null) {
                const newSeed = parseInt(prefs.colorSeed);
                if (!isNaN(newSeed) && newSeed !== AppState.preferences.colorSeed) {
                    AppState.preferences.colorSeed = newSeed;
                    localStorage.setItem('ASX_NEXT_colorSeed', newSeed);
                    needsRender = true;
                }
            }

            // 0z. PRE-SYNC Map structures needed by switch logic (v1143 Race Fix)
            let _sortConfigMapSynced = false;
            if (prefs.sortConfigMap && JSON.stringify(prefs.sortConfigMap) !== JSON.stringify(AppState.sortConfigMap)) {
                AppState.sortConfigMap = { ...AppState.sortConfigMap, ...prefs.sortConfigMap };
                localStorage.setItem(STORAGE_KEYS.SORT, JSON.stringify(prefs.sortConfigMap));
                _sortConfigMapSynced = true;
            }

            if (prefs.globalSort && JSON.stringify(prefs.globalSort) !== JSON.stringify(AppState.preferences.globalSort)) {
                AppState.saveGlobalSort(prefs.globalSort, true);
                if (JSON.stringify(AppState.sortConfig) !== JSON.stringify(prefs.globalSort)) {
                    AppState.sortConfig = { ...prefs.globalSort };
                    needsRender = true;
                }
            } else if (prefs.sortConfigMap && !AppState.preferences.globalSort) {
                // If map was updated and we don't have a global override, ensure current sort matches the map
                const currentKey = AppState.watchlist.id || 'portfolio';
                if (prefs.sortConfigMap[currentKey]) {
                    const newSort = prefs.sortConfigMap[currentKey];
                    if (JSON.stringify(AppState.sortConfig) !== JSON.stringify(newSort)) {
                        AppState.sortConfig = { ...newSort };
                        needsRender = true;
                    }
                }
            }

            // Sync View Mode BEFORE watchlist switch
            if (prefs.viewMode && AppState.viewMode !== prefs.viewMode) {
                AppState.viewMode = prefs.viewMode;
                localStorage.setItem(STORAGE_KEYS.VIEW_MODE, prefs.viewMode);
                needsRender = true;
            }

            // Sync Hidden Assets BEFORE watchlist switch
            if (prefs.hiddenAssets && Array.isArray(prefs.hiddenAssets)) {
                const newList = prefs.hiddenAssets.map(String);
                const currentList = [...AppState.hiddenAssets].map(String);
                if (JSON.stringify(newList) !== JSON.stringify(currentList)) {
                    AppState.hiddenAssets = new Set(newList);
                    localStorage.setItem(STORAGE_KEYS.HIDDEN_ASSETS, JSON.stringify(newList));
                    needsRender = true;
                }
            }

            // 1. Sync Watchlist ID (if different and valid)
            if (prefs.lastWatchlistId && prefs.lastWatchlistId !== AppState.watchlist.id) {
                if (AppState.watchlist.id === 'portfolio' && prefs.lastWatchlistId !== 'portfolio') {
                    this._initialRenderComplete = true;
                    // v1138: Pass skipPersist=true to avoid loopback
                    this.handleSwitchWatchlist(prefs.lastWatchlistId, false, true);
                    needsRender = false;
                }
            }

            // 4. Sync Carousel Selections
            if (prefs.carouselSelections && Array.isArray(prefs.carouselSelections)) {
                const newList = prefs.carouselSelections.map(String);
                const currentList = [...AppState.carouselSelections].map(String);
                if (JSON.stringify(newList) !== JSON.stringify(currentList)) {
                    AppState.carouselSelections = new Set(newList);
                    localStorage.setItem(STORAGE_KEYS.CAROUSEL_SELECTIONS, JSON.stringify(newList));
                    needsRender = true;
                }
            }

            // 5. Sync Watchlist Order
            if (prefs.watchlistOrder && JSON.stringify(prefs.watchlistOrder) !== JSON.stringify(AppState.preferences.watchlistOrder)) {
                AppState.preferences.watchlistOrder = prefs.watchlistOrder;
                localStorage.setItem(STORAGE_KEYS.WATCHLIST_ORDER, JSON.stringify(prefs.watchlistOrder));
                needsRender = true;
            }

            // 5.1 Sync Favorite Links
            if (prefs.favoriteLinks && Array.isArray(prefs.favoriteLinks)) {
                const cloudLinks = prefs.favoriteLinks || [];

                // Overwrite strategy: Trust the Cloud
                AppState.preferences.favoriteLinks = cloudLinks;
                localStorage.setItem(STORAGE_KEYS.FAVORITE_LINKS, JSON.stringify(cloudLinks));

                // LIVE UPDATE: If modal is open, refresh it
                if (!document.getElementById(IDS.MODAL_FAVORITE_LINKS).classList.contains(CSS_CLASSES.HIDDEN)) {
                    const event = new CustomEvent(EVENTS.FAVORITE_LINKS_UPDATED);
                    document.dispatchEvent(event);
                }
            }

            // 5.2 Sync Research Links
            if (prefs.researchLinks && Array.isArray(prefs.researchLinks)) {
                const cloudLinks = prefs.researchLinks || [];

                // Overwrite strategy: Trust the Cloud
                AppState.preferences.researchLinks = cloudLinks;
                localStorage.setItem(STORAGE_KEYS.RESEARCH_LINKS, JSON.stringify(cloudLinks));

                // LIVE UPDATE: Trigger refresh
                document.dispatchEvent(new CustomEvent(EVENTS.RESEARCH_LINKS_UPDATED));
            }

            // 6. Sync Watchlist Mode
            if (prefs.watchlistMode) {
                AppState.preferences.watchlistMode = prefs.watchlistMode;
                localStorage.setItem(STORAGE_KEYS.WATCHLIST_PICKER_MODE, prefs.watchlistMode);
                needsRender = true;
            }

            // 7. Sync Hidden Watchlists
            if (prefs.hiddenWatchlists && Array.isArray(prefs.hiddenWatchlists)) {
                AppState.hiddenWatchlists = new Set(prefs.hiddenWatchlists.map(String));
                localStorage.setItem(STORAGE_KEYS.HIDDEN_WATCHLISTS, JSON.stringify(prefs.hiddenWatchlists));
                needsRender = true;
            }

            /* Redundant sortConfigMap sync removed - handled earlier in 0z */
            if (prefs.sortConfigMap && !_sortConfigMapSynced) {
                // Secondary check in case Step 2 was partially skipped
                const cloudJSON = JSON.stringify(prefs.sortConfigMap);
                if (cloudJSON !== JSON.stringify(AppState.sortConfigMap)) {
                    AppState.sortConfigMap = prefs.sortConfigMap;
                    localStorage.setItem(STORAGE_KEYS.SORT, cloudJSON);
                }
            }


            // 7.2 Sync Dashboard Order & Hidden
            if (prefs.dashboardOrder) {
                AppState.preferences.dashboardOrder = prefs.dashboardOrder;
                localStorage.setItem(STORAGE_KEYS.DASHBOARD_ORDER, JSON.stringify(prefs.dashboardOrder));
                needsRender = true;
            }

            if (prefs.dashboardHidden) {
                AppState.preferences.dashboardHidden = prefs.dashboardHidden;
                localStorage.setItem(STORAGE_KEYS.DASHBOARD_HIDDEN, JSON.stringify(prefs.dashboardHidden));
                needsRender = true;
            }

            // 7b. Sync Onboarded Flag
            if (prefs.onboarded !== undefined) {
                AppState.preferences.onboarded = !!prefs.onboarded;
            }

            // 7b. SANITIZE
            this._sanitizeActiveWatchlist();

            // 8. Sync Hidden Sort Options
            if (prefs.hiddenSortOptions) {
                const restored = {};
                for (const key in prefs.hiddenSortOptions) {
                    restored[key] = new Set((prefs.hiddenSortOptions[key] || []).map(String));
                }
                AppState.hiddenSortOptions = restored;
                localStorage.setItem(STORAGE_KEYS.HIDDEN_SORT_OPTIONS, JSON.stringify(prefs.hiddenSortOptions));
                needsRender = true;
            }

            // 8.1 Sync Custom Watchlist Names
            if (prefs.customWatchlistNames) {
                AppState.preferences.customWatchlistNames = prefs.customWatchlistNames;
                localStorage.setItem(STORAGE_KEYS.CUSTOM_WATCHLIST_NAMES, JSON.stringify(prefs.customWatchlistNames));
                // Force Title Update immediately if current watchlist is affected
                const currentId = AppState.watchlist.id;
                if (currentId && prefs.customWatchlistNames[currentId]) {
                    AppState.watchlist.name = prefs.customWatchlistNames[currentId];
                    needsRender = true;
                }
            }

            // 9. Sync User Categories (Trust Cloud)
            if (prefs.userCategories && Array.isArray(prefs.userCategories)) {
                const remoteCats = prefs.userCategories;
                remoteCats.forEach(c => {
                    if (c && c.id === 'shares' && (c.color?.toLowerCase() === '#808000' || c.color?.toLowerCase() === '#a49393')) {
                        c.color = '#00D2FF';
                    }
                });

                // Overwrite strategy: Trust the Cloud
                if (JSON.stringify(remoteCats) !== JSON.stringify(AppState.preferences.userCategories)) {
                    AppState.preferences.userCategories = remoteCats;
                    localStorage.setItem(STORAGE_KEYS.USER_CATEGORIES, JSON.stringify(remoteCats));

                    // Apply new themes to current data immediately
                    AppState.cascadeCategoryColors();

                    needsRender = true;
                }
            }

            /* View Mode sync moved to early block */

            // 11. Sync View Configs (Per-Watchlist)
            if (prefs.viewConfigs) {
                AppState.preferences.viewConfigs = prefs.viewConfigs;
                localStorage.setItem(STORAGE_KEYS.VIEW_CONFIGS, JSON.stringify(prefs.viewConfigs));
                // No immediate render needed, key lookup handles it on switch
            }

            // 12. Sync Widget Configuration (Fix Persistence)
            if (prefs.widgetConfig && JSON.stringify(prefs.widgetConfig) !== JSON.stringify(AppState.preferences.widgetConfig)) {
                AppState.preferences.widgetConfig = prefs.widgetConfig;
                localStorage.setItem(STORAGE_KEYS.WIDGET_CONFIG, JSON.stringify(prefs.widgetConfig));
                needsRender = true;
            }

            // 13. Sync Widget Dashboard Items (Fix Persistence)
            if (prefs.widgetDashboardItems && JSON.stringify(prefs.widgetDashboardItems) !== JSON.stringify(AppState.preferences.widgetDashboardItems)) {
                AppState.preferences.widgetDashboardItems = prefs.widgetDashboardItems;
                localStorage.setItem(STORAGE_KEYS.WIDGET_DASHBOARD_ITEMS, JSON.stringify(prefs.widgetDashboardItems));
                needsRender = true;
            }

            if (needsRender) {
                this.updateDataAndRender(false);
            }

            // SAFETY: If we didn't switch watchlists (which hides splash), but we are done loading
            if (!this._initialRenderComplete) {
                this._initialRenderComplete = true;
                // RACE FIX: Only call handleSecurityLock if not already unlocked
                // (avoids redundant isLocked = false write that triggers race detection)
                if (!this._isUnlockedThisSession) {
                    this.handleSecurityLock(); // Final check
                }
            }

            // UNLOCK OUTBOUND SYNC: Cloud prefs have been applied, allow future syncs.
            if (!this._cloudPrefsLoaded) {
                this._cloudPrefsLoaded = true;
            }
        } finally {
            this._syncingPreferences = false; // UNLOCK
        }
    }
    /**
     * Handles the security lock/unlock flow.
     */
    async handleSecurityLock() {
        // 1. SESSION GUARD: If already unlocked this session, stay unlocked.
        if (this._isUnlockedThisSession) {
            if (AppState.isLocked !== false) AppState.isLocked = false;
            return;
        }

        // 2. CONCURRENCY GUARD: If modal is already showing, don't trigger again.
        if (this._lockModalActive) {
            return;
        }

        const prefs = AppState.preferences.security;
        // SECURITY GATE: 
        // If we haven't loaded Cloud Prefs yet, we MUST wait (Default Secure).
        if (!this._cloudPrefsLoaded && AppState.user) {
            if (AppState.isLocked !== true) AppState.isLocked = true; // Force Lock visual until we know for sure
            return;
        }

        // Now we have prefs. Check if we should lock.
        if (!this.securityController.shouldLock()) {
            // NOT LOCKED
            if (AppState.isLocked !== false) AppState.isLocked = false;
            this._isUnlockedThisSession = true; // Mark as passed
            this._lockModalActive = false;
            document.dispatchEvent(new CustomEvent(EVENTS.FIREBASE_DATA_LOADED));
            return;
        }

        // MUST LOCK
        if (AppState.isLocked !== true) AppState.isLocked = true;
        this._lockModalActive = true;

        await SecurityUI.renderUnlockModal({
            onUnlock: (pin) => {
                const isValid = this.securityController.verifyPin(pin);
                if (isValid) {
                    if (AppState.isLocked !== false) AppState.isLocked = false;
                    this._isUnlockedThisSession = true;
                    this._lockModalActive = false; // Resolved
                    document.dispatchEvent(new CustomEvent(EVENTS.FIREBASE_DATA_LOADED));
                    this.updateDataAndRender(false);
                }
                return isValid;
            },
            onBiometric: async () => {
                const success = await this.securityController.authenticateBiometric();
                if (success) {
                    if (AppState.isLocked !== false) AppState.isLocked = false;
                    this._isUnlockedThisSession = true;
                    this._lockModalActive = false; // Resolved
                    document.dispatchEvent(new CustomEvent(EVENTS.FIREBASE_DATA_LOADED));
                    // Force remove modal if biometric succeeds
                    document.getElementById(IDS.SECURITY_UNLOCK_MODAL)?.remove();
                    this.updateDataAndRender();
                }
                return success;
            }
        });
    }

    _setupLifecycleHandlers() {
        // App Visibility Change (Lock on Resume + Auto-Refresh)
        document.addEventListener('visibilitychange', () => {
            const now = Date.now();

            if (document.visibilityState === 'hidden') {
                this._lastBackgroundTime = now;
            } else if (document.visibilityState === 'visible') {
                // V71: Always refresh session on resume to prevent stale writes
                if (AppState.user) {
                    AuthService.refreshSession().catch(err => console.warn('Resume auth refresh failed', err));
                }

                // 1. Security Lock Check
                if (AppState.user && AppState.preferences.security.requireLockOnResume) {
                    this.handleSecurityLock();
                }

                // UNCONDITIONAL RESUME FRESHNESS CHECK:
                // Do not gate behind this._lastBackgroundTime because mobile power locks
                // often suspend execution without firing 'hidden'.
                const quoteAge = Date.now() - (AppState.lastGlobalFetch || 0);
                const isOlderThan5Min = !AppState.lastGlobalFetch || quoteAge > (5 * 60 * 1000);

                // Immediate schedule alignment on resume: update header immediately so
                // leftover market text from prior session does not linger while network fetches
                if (this.headerLayout && AppState.user) {
                    this.headerLayout.updateConnectionStatus(true, isOlderThan5Min ? 'loading' : AppState.health.status);
                }

                if (isOlderThan5Min) {
                    document.body.classList.add('is-stale');
                }

                // Trigger immediate wake refresh with force=true, silent=true
                this._refreshAllPrices(AppState.data.shares || [], true, true).catch(err => {
                    console.warn('[AppController] Optimistic wake fetch failed quietly:', err);
                });

                // Re-arm adaptive polling loop to guarantee timer is active
                this.startAdaptivePolling();

                // Reset Timer
                this._lastBackgroundTime = 0;
            }
        });
    }

    /**
     * HEALTH MONITOR: Detects stale sessions and potential logic rot.
     */
    startHealthMonitor() {
        if (this._healthMonitorInterval) clearInterval(this._healthMonitorInterval);

        this._lastHealthTick = Date.now();
        this.checkAppHealth(); // Evaluate immediately upon boot

        // Run check every 15 seconds as an active watchdog
        this._healthMonitorInterval = setInterval(() => {
            this.checkAppHealth();
        }, 15000);
    }

    /**
     * ADAPTIVE POLLING ENGINE: Aligns background quote fetching with the official ASX schedule.
     * - Open / Auction (10:00-16:10 Sydney): Every 5 minutes (silent background polling)
     * - Pre-Open (07:00-10:00 Sydney): Every 5 minutes
     * - Closed / Overnight / Weekends: Every 15 minutes (or on-demand)
     */
    startAdaptivePolling() {
        if (this._adaptivePollTimer) clearTimeout(this._adaptivePollTimer);
        this._scheduleNextPoll();
    }

    /**
     * Calculates next poll interval and schedules background fetch.
     * @private
     */
    _scheduleNextPoll() {
        if (this._adaptivePollTimer) clearTimeout(this._adaptivePollTimer);

        const status = MarketSchedule.getASXStatus();
        let intervalMs = 15 * 60 * 1000; // Default closed: 15 mins

        if (status.session === ASX_SESSION.OPEN || status.session === ASX_SESSION.AUCTION) {
            intervalMs = 4 * 60 * 1000; // 4 mins active trading (aligned with staleness threshold)
        } else if (status.session === ASX_SESSION.PRE_OPEN) {
            intervalMs = 5 * 60 * 1000; // 5 mins pre-open
        }

        this._adaptivePollTimer = setTimeout(async () => {
            // Only poll if tab is visible, user is logged in, and not currently fetching
            if (document.visibilityState === 'visible' && AppState.user && !AppState._isFetching) {
                try {
                    await this._refreshAllPrices(AppState.data.shares || [], false, true);
                } catch (err) {
                    console.warn('[AppController] Adaptive poll background sync failed:', err);
                }
            }
            // Re-evaluate schedule dynamically for next cycle
            this._scheduleNextPoll();
        }, intervalMs);
    }

    /**
     * Rapid Retry Schedule (10-15s backoff) for strikes 1 and 2.
     * Prevents locking the user out for a full 5-minute polling interval during boot/wake network blips.
     * @private
     */
    _scheduleFastRetry(delayMs = 12000) {
        if (this._retryTimer) {
            clearTimeout(this._retryTimer);
            this._retryTimer = null;
        }

        const failures = AppState.health?.consecutiveFailures || 0;
        if (failures > 0 && failures < 3 && AppState.user) {
            console.log(`[AppController] Scheduling fast retry in ${delayMs / 1000}s (strike ${failures}/3)...`);
            this._retryTimer = setTimeout(async () => {
                this._retryTimer = null;
                // Double check failures < 3 and user still authenticated
                if (AppState.user && (AppState.health?.consecutiveFailures || 0) > 0 && (AppState.health?.consecutiveFailures || 0) < 3) {
                    try {
                        console.log(`[AppController] Executing fast retry attempt (strike ${(AppState.health?.consecutiveFailures || 0) + 1}/3)...`);
                        await this._refreshAllPrices(AppState.data.shares || [], true, true);
                    } catch (err) {
                        console.warn('[AppController] Fast retry execution failed:', err);
                    }
                }
            }, delayMs);
        }
    }

    /**
     * Checks multiple factors to determine if the running app instance is fresh.
     * Respects the 3-strike failure threshold for price freshness alerting.
     */
    checkAppHealth() {
        const now = Date.now();
        const health = AppState.health;
        let newStatus = 'healthy';

        // 1. ELAPSED QUOTE FRESHNESS (Market Hours: 5-minute strict cap, protected by 4m adaptive poll)
        const isTrading = MarketSchedule.isASXTrading();
        const quoteAge = now - (AppState.lastGlobalFetch || 0);
        const FIVE_MINUTES = 5 * 60 * 1000;
        if (isTrading && AppState.lastGlobalFetch > 0 && quoteAge > FIVE_MINUTES) {
            newStatus = 'stale';
        }

        // 2. AGE CHECK: Evaluated strictly against lastGlobalFetch (eliminates 12-hour sessionStartTime trap)
        const TWENTY_FOUR_HOURS = 24 * 60 * 60 * 1000;
        if (AppState.lastGlobalFetch > 0 && (now - AppState.lastGlobalFetch > TWENTY_FOUR_HOURS)) {
            newStatus = 'stale';
        }

        // 3. 3-STRIKE FAILURE CHECK (Failure-Threshold Alerting)
        if ((health.consecutiveFailures || 0) >= 3) {
            newStatus = 'stale';
        }

        // Update Global State
        if (health.status !== newStatus) {
            health.status = newStatus;

            // Only update UI if we are connected (disconnected state handles its own UI)
            if (AppState.user && this.headerLayout) {
                this.headerLayout.updateConnectionStatus(true, newStatus);
            }

            if (newStatus === 'stale') {
                document.body.classList.add('is-stale');
            } else {
                document.body.classList.remove('is-stale');
            }
        } else if (newStatus === 'stale') {
            document.body.classList.add('is-stale');

            // Auto-recovery retry loop with exponential backoff:
            // ONLY fires when consecutiveFailures > 0 (prevents runaway retries on idle/session age)
            const failures = health.consecutiveFailures || 0;
            if (failures > 0 && !AppState._isFetching && AppState.user) {
                const backoffDelay = Math.min(60000 * Math.pow(2, Math.max(0, failures - 3)), 5 * 60 * 1000);
                const timeSinceLastAttempt = Date.now() - (this._lastFetchAttemptTime || 0);
                if (timeSinceLastAttempt >= backoffDelay) {
                    this._refreshAllPrices(AppState.data.shares || [], true, true).catch(e => console.warn('Background retry failed:', e));
                }
            }
        } else {
            // If healthy and verified, ensure screen is at 100% full brightness
            if (AppState.lastGlobalFetch > 0 && (health.consecutiveFailures || 0) === 0) {
                document.body.classList.remove('is-stale');
            }
        }
    }


    async updateDataAndRender(fetchFresh = false, isManual = false) {
        // Trigger Loading State on Connection Dot if explicit fetch requested AND it's manual
        if (fetchFresh && isManual && this.headerLayout) {
            this.headerLayout.updateConnectionStatus(AppState.user !== null, 'loading');
        }


        if (AppState.isLocked) {


            return;


        }

        // Increment Data Update Tally for Health Monitoring
        AppState.health.dataUpdateTally++;





        const header = document.getElementById('appHeader');


        const sidebar = document.getElementById('sidebar');

        // --- GLOBAL HEADER & SIDEBAR STYLING (Universal) ---
        // 1. Sidebar: Always Coffee Gradient
        if (sidebar) {
            sidebar.style.background = 'linear-gradient(135deg, rgba(164, 147, 147, 0.4) 0%, rgba(20, 20, 20, 1) 100%)';
        }

        // NOTE: Gradient Logic has been consolidated into WatchlistUI.js (updateHeaderTitle)
        // This block is disabled to prevent conflicting overwrites (AppController enforced Green-Left vs User Req Red-Left).

        // const dynamicGradient = `linear-gradient(to right, rgba(0, 180, 0, 0.6) 0%, rgba(20, 20, 20, 1) ${gainProp}%, rgba(180, 0, 0, 0.6) 100%)`;
        // header.style.background = dynamicGradient;





        // === DYNAMIC CASH ASSET UPDATE ===
        // Check if any cash assets are linked to Portfolio Value
        const cashAssets = AppState.data.cash || [];
        const linkedAssets = cashAssets.filter(a => a.isPortfolioLinked);

        if (linkedAssets.length > 0) {
            // Calculate Portfolio Value on-the-fly
            // We use the full share list and PORTFOLIO_ID context
            const { summaryMetrics } = processShares(
                AppState.data.shares || [],
                PORTFOLIO_ID,
                AppState.livePrices,
                AppState.sortConfig,
                AppState.hiddenAssets
            );

            const currentPortfolioValue = summaryMetrics ? summaryMetrics.totalValue : 0;
            if (currentPortfolioValue > 0) {
                AppState.setLastCleanPortfolioValue(currentPortfolioValue);
            }

            linkedAssets.forEach(asset => {
                // Only update memory (Display Only) - Prevents DB write thrashing
                if (asset.balance !== currentPortfolioValue) {
                    asset.balance = currentPortfolioValue;
                }
            });
        }

        if (AppState.watchlist.id === DASHBOARD_WATCHLIST_ID) {









            const dashboardData = AppState.data.dashboard || [];


            this.dashboardRenderer.render(dashboardData);





            // Force Title Bar Update (Header gradient already applied in section above)
            if (this.watchlistUI) this.watchlistUI.updateHeaderTitle(null);





            if (fetchFresh) {


                this._refreshAllPrices([]);


            }


            return;


        }











        if (AppState.watchlist.type === 'cash') {
            const cashData = AppState.data.cash || [];
            this.viewRenderer.container.innerHTML = '';
            this.cashController.refreshView(cashData);
            return;
        }

        const allShares = AppState.data.shares || [];
        const filteredShares = this.appService.getWatchlistData(allShares, AppState.watchlist.id);

        if (filteredShares.length === 0) {
            this.viewRenderer.render([]);
            this.viewRenderer.renderASXCodeDropdownV2([]);
            return;
        }

        this.viewRenderer.updateSortButtonUI(AppState.watchlist.id, AppState.sortConfig);

        const { mergedData, summaryMetrics } = processShares(
            allShares,
            AppState.watchlist.id,
            AppState.livePrices,
            AppState.sortConfig,
            AppState.hiddenAssets
        );

        // HYBRID RENDERING APPROACH
        // If this is a silent update (fetchFresh=false), try patching first to avoid animations/flickering.
        // Include viewMode, watchlistId, borders, and key visual attributes in the structureKey to ensure any edits trigger a full render immediately.
        const structureKey = JSON.stringify({
            codes: mergedData.map(d => d.code),
            viewMode: AppState.viewMode,
            watchlistId: AppState.watchlist?.id,
            borders: AppState.preferences.containerBorders,
            gradientStrength: AppState.preferences.gradientStrength,
            cardChartOpacity: AppState.preferences.cardChartOpacity,
            visuals: mergedData.map(d => `${d.code}:${d.targetPrice || 0}:${d.starRating || 0}:${d.comments?.length || 0}:${d.simulatedActive ? 1 : 0}`)
        });
        const prevStructureKey = this.viewRenderer._lastRenderedStructureKey;

        if (!fetchFresh && structureKey === prevStructureKey) {
            // Structure hasn't changed. Attempt a targeted DOM patch.
            const patchSuccess = this.viewRenderer.patchPricesInDOM(mergedData, summaryMetrics);
            if (!patchSuccess) {
                // Failsafe: Full render if DOM nodes are missing or patching failed
                this.viewRenderer.render(mergedData, summaryMetrics);
                this.viewRenderer._lastRenderedStructureKey = structureKey;
            }
        } else {
            // Structural change (Sort/Delete/Add) or explicit fetch requested -> Full Wipe and Rebuild
            this.viewRenderer.render(mergedData, summaryMetrics);
            this.viewRenderer._lastRenderedStructureKey = structureKey;
        }

        // Ensure Header Title / Gradient updates with new data
        if (this.watchlistUI) {
            this.watchlistUI.updateHeaderTitle(summaryMetrics);
        }

        if (AppState.watchlist.type !== 'cash') {
            const activeCodes = mergedData
                .filter(s => !s.isHidden)
                .map(s => s.code)
                .sort((a, b) => a.localeCompare(b));

            if (AppState.livePrices instanceof Map && AppState.livePrices.size > 0) {
                const statuses = getASXCodesStatus(activeCodes, AppState.livePrices);
                this.viewRenderer.renderASXCodeDropdownV2(statuses);
            } else {
                this.viewRenderer.renderASXCodeDropdownV2(activeCodes.map(c => ({ code: c, status: 'neutral' })));
            }
        }

        if (fetchFresh) {
            return this._refreshAllPrices(AppState.data.shares || [], true, !isManual);
        }
    }

    changeViewMode(mode) {
        AppState.viewMode = mode; // Update transient state immediately
        // Persist to the specific watchlist
        const currentId = AppState.watchlist?.id || 'portfolio';
        // Handle CASH special case if ID is inconsistent (though handleSwitchWatchlist normalizes it)
        const effectiveId = (AppState.watchlist?.type === 'cash') ? 'CASH' : currentId;

        AppState.saveViewModeForWatchlist(effectiveId, mode);

        // Force full re-render on next updateDataAndRender by invalidating cache key
        if (this.viewRenderer) {
            this.viewRenderer._lastRenderedStructureKey = null;
        }

        this.updateDataAndRender(false);
    }

    async handleSwitchWatchlist(watchlistId, isBoot = false, skipPersist = false) {
        // QUICK EXIT: If same watchlist and not boot, ignore.
        if (!isBoot && watchlistId === AppState.watchlist.id) return;

        // === STEP 1: Update Watchlist Identity ===
        const customNames = AppState.preferences.customWatchlistNames || {};

        if (watchlistId === CASH_WATCHLIST_ID) {
            if (AppState.watchlist.type !== 'cash') AppState.watchlist.type = 'cash';
            if (AppState.watchlist.id !== CASH_WATCHLIST_ID) AppState.watchlist.id = CASH_WATCHLIST_ID;
            const newName = customNames[CASH_WATCHLIST_ID] || 'Cash & Assets';
            if (AppState.watchlist.name !== newName) AppState.watchlist.name = newName;
            if (AppState.isPortfolioVisible !== false) AppState.isPortfolioVisible = false;
        } else {
            if (AppState.watchlist.type !== 'stock') AppState.watchlist.type = 'stock';
            const targetId = (watchlistId === ALL_SHARES_ID) ? ALL_SHARES_ID : watchlistId;
            if (AppState.watchlist.id !== targetId) AppState.watchlist.id = targetId;

            if (watchlistId === 'portfolio' || watchlistId === null) {
                if (AppState.watchlist.id !== 'portfolio') AppState.watchlist.id = 'portfolio';
                const newName = customNames['portfolio'] || 'Portfolio';
                if (AppState.watchlist.name !== newName) AppState.watchlist.name = newName;
                if (AppState.isPortfolioVisible !== true) AppState.isPortfolioVisible = true;
            } else if (watchlistId === DASHBOARD_WATCHLIST_ID) {
                if (AppState.watchlist.id !== DASHBOARD_WATCHLIST_ID) AppState.watchlist.id = DASHBOARD_WATCHLIST_ID;
                const newName = customNames[DASHBOARD_WATCHLIST_ID] || 'Dashboard';
                if (AppState.watchlist.name !== newName) AppState.watchlist.name = newName;
                if (AppState.isPortfolioVisible !== false) AppState.isPortfolioVisible = false;
            } else if (watchlistId === SIMULATIONS_WATCHLIST_ID) {
                if (AppState.watchlist.id !== SIMULATIONS_WATCHLIST_ID) AppState.watchlist.id = SIMULATIONS_WATCHLIST_ID;
                const newName = customNames[SIMULATIONS_WATCHLIST_ID] || 'Simulations';
                if (AppState.watchlist.name !== newName) AppState.watchlist.name = newName;
                if (AppState.isPortfolioVisible !== false) AppState.isPortfolioVisible = false;
            } else if (watchlistId === ALL_SHARES_ID) {
                const newName = customNames[ALL_SHARES_ID] || 'All Shares';
                if (AppState.watchlist.name !== newName) AppState.watchlist.name = newName;
                if (AppState.isPortfolioVisible !== false) AppState.isPortfolioVisible = false;
            } else {
                const w = (AppState.data.watchlists || []).find(w => w.id === watchlistId);
                const newName = w ? w.name : (customNames[watchlistId] || 'Watchlist');
                if (AppState.watchlist.name !== newName) AppState.watchlist.name = newName;
                if (AppState.isPortfolioVisible !== false) AppState.isPortfolioVisible = false;
            }
        }

        // === STEP 2: RESTORE SORT CONFIG (BEFORE RENDER) ===
        if (AppState._skipSortRestore) {
            // Skip sort restoration to prevent double-write race condition
        } else if (AppState.preferences.globalSort) {
            // GLOBAL OVERRIDE with FALLBACK LOGIC
            const currentGlobal = AppState.preferences.globalSort;

            // Determine current view type for validation
            let viewType = 'STOCK';
            if (AppState.watchlist.type === 'cash') viewType = 'CASH';
            else if (AppState.watchlist.id === 'portfolio' || AppState.watchlist.id === SIMULATIONS_WATCHLIST_ID) viewType = 'PORTFOLIO';

            // Check if current global sort is valid for this view
            const validOptions = SORT_OPTIONS[viewType] || SORT_OPTIONS.STOCK;
            const isValid = validOptions.some(opt => opt.field === currentGlobal.field);

            if (isValid) {
                this._updateSortConfig(currentGlobal, watchlistId, isBoot);
            } else {
                // Fallback Logic
                if (viewType === 'CASH') {
                    const fallback = { field: 'name', direction: 'asc' };
                    this._updateSortConfig(fallback, watchlistId, isBoot);
                } else {
                    const fallback = { field: 'code', direction: 'asc' };
                    this._updateSortConfig(fallback, watchlistId, isBoot);
                }
            }
        } else {
            // Critical: Read stored config FIRST, then validate
            const storedSort = AppState.getSortConfigForWatchlist(watchlistId);

            // DYNAMIC VALIDATION: Derive valid fields from AppConstants.SORT_OPTIONS
            // This ensures we never miss a field (like targetPrice, comments, etc.)
            const allOptions = [
                ...(SORT_OPTIONS.STOCK || []),
                ...(SORT_OPTIONS.PORTFOLIO || []),
                ...(SORT_OPTIONS.CASH || [])
            ];
            // Create Set for O(1) lookup
            const validFields = new Set(allOptions.map(opt => opt.field));

            if (storedSort && validFields.has(storedSort.field)) {
                this._updateSortConfig(storedSort, watchlistId, isBoot);
            } else {
                // Fallback to safe defaults
                const fallback = (AppState.watchlist.type === 'cash')
                    ? { field: 'category', direction: 'asc' }
                    : { field: 'code', direction: 'asc' };

                this._updateSortConfig(fallback, watchlistId, isBoot);
                AppState.saveSortConfigForWatchlist(watchlistId);
            }
        }

        // === STEP 2.5: SANITIZE HIDDEN SORT ===
        // Note: Sanitization is now automatically run inside _updateSortConfig to handle debounced flows.


        // === STEP 2.6: RESTORE VIEW MODE (NEW) ===
        // Look up preferred view for this watchlist ID or default to 'TABLE'
        const effectiveId = (watchlistId === CASH_WATCHLIST_ID) ? 'CASH' :
            (watchlistId === 'portfolio' || watchlistId === null) ? 'portfolio' :
                watchlistId;

        const savedView = AppState.getViewModeForWatchlist(effectiveId);
        if (AppState.viewMode !== savedView) {
            AppState.viewMode = savedView;
        }

        // Update the Header Icon
        if (this.headerLayout) {
            this.headerLayout.updateViewToggleIcon(savedView);
        } else {
            // Fallback for extreme race conditions (e.g. boot)
            requestAnimationFrame(() => {
                if (this.headerLayout) this.headerLayout.updateViewToggleIcon(savedView);
            });
        }

        // === STEP 3: Update UI Elements ===
        const sidebarAddBtn = document.getElementById('add-share-sidebar-btn');
        if (sidebarAddBtn) {
            if (AppState.watchlist.type === 'cash') {
                sidebarAddBtn.innerHTML = '<i class="fas fa-plus-circle"></i> Add Cash & Asset';
            } else {
                sidebarAddBtn.innerHTML = '<i class="fas fa-plus-circle"></i> Add Share';
            }
        }

        // === STEP 3.1: HANDLE EDIT WATCHLIST GHOSTING ===
        // SYSTEM VIEW GHOSTING REMOVED: All portfolios (including system defaults) are now editable/renameable.

        this.watchlistUI.updateHeaderTitle();
        this.watchlistUI.renderWatchlistDropdown();

        // === STEP 4: UPDATE SORT UI SYNCHRONOUSLY (and safely) ===
        // Critical: Sort indicator must match content.
        // We call it immediately for responsiveness, but ALSO schedule a safety update
        // to handle any HeaderLayout initialization race conditions on boot.
        this.viewRenderer.updateSortButtonUI(AppState.watchlist.id, AppState.sortConfig);

        requestAnimationFrame(() => {
            setTimeout(() => {
                this.viewRenderer.updateSortButtonUI(AppState.watchlist.id, AppState.sortConfig);
            }, 50);
        });

        // === STEP 5: RENDER (Fire-and-Forget, Non-Blocking) ===
        // Decouple Navigation from Data: No network fetch on view change, just use AppState memory.
        this.updateDataAndRender(false).catch(e => console.warn('Render error:', e));

        // === STEP 6: Cleanup & Persist (Background Operations) ===
        if (!isBoot && this.headerLayout) this.headerLayout.closeSidebar();


        // VIEW HYGIENE: Toggle ASX Button Visibility
        const asxToggleBtn = document.getElementById(IDS.ASX_TOGGLE);
        const dashboardTimeBtn = document.getElementById(IDS.DASHBOARD_REORDER_TOGGLE);
        const asxDropdown = document.getElementById(IDS.ASX_CONTAINER);

        if (asxToggleBtn && dashboardTimeBtn) {
            if (watchlistId === DASHBOARD_WATCHLIST_ID || watchlistId === CASH_WATCHLIST_ID) {
                asxToggleBtn.classList.add(CSS_CLASSES.HIDDEN);

                if (watchlistId === DASHBOARD_WATCHLIST_ID) {
                    dashboardTimeBtn.classList.remove(CSS_CLASSES.HIDDEN);
                } else {
                    dashboardTimeBtn.classList.add(CSS_CLASSES.HIDDEN);
                }
            } else {
                asxToggleBtn.classList.remove(CSS_CLASSES.HIDDEN);
                dashboardTimeBtn.classList.add(CSS_CLASSES.HIDDEN);
            }

            // Force close dropdown
            if (asxDropdown) asxDropdown.classList.remove(CSS_CLASSES.EXPANDED);
            asxToggleBtn.setAttribute('aria-pressed', 'false');
        }

        // VIEW HYGIENE: Toggle Header Sort Button Visibility
        const headerSortBtn = document.getElementById(IDS.SORT_PICKER_BTN);
        if (headerSortBtn) {
            if (watchlistId === DASHBOARD_WATCHLIST_ID) {
                headerSortBtn.classList.add(CSS_CLASSES.HIDDEN);
            } else {
                headerSortBtn.classList.remove(CSS_CLASSES.HIDDEN);
            }
        }

        // Persist watchlist state (Fire-and-Forget)
        if (!skipPersist) AppState.saveWatchlistState();
    }

    /**
     * Cycles through available watchlists in a sequence.
     * @param {number} direction - 1 for forward, -1 for backward
     */

    _handleCarousel(direction) {
        // 1. Build the full sequence of watchlists
        const systemWatchlists = [
            { id: ALL_SHARES_ID, name: 'All Shares' },
            { id: 'portfolio', name: 'Portfolio' },
            { id: DASHBOARD_WATCHLIST_ID, name: 'Dashboard' },
            { id: CASH_WATCHLIST_ID, name: 'Cash & Assets' }
        ];

        const hasSimulated = (AppState.data.shares || []).some(s => s.isSimulated === true || s.simulatedActive === true);
        if (hasSimulated) {
            systemWatchlists.push({
                id: SIMULATIONS_WATCHLIST_ID,
                name: WATCHLIST_NAMES.SIMULATIONS || 'Simulations'
            });
        }

        const userWatchlists = AppState.data.watchlists || [];
        let fullList = [...systemWatchlists, ...userWatchlists];

        // 2. Respect saved order if available
        const savedOrder = AppState.preferences.watchlistOrder;
        if (savedOrder && Array.isArray(savedOrder)) {
            fullList.sort((a, b) => {
                const idxA = savedOrder.indexOf(a.id);
                const idxB = savedOrder.indexOf(b.id);
                if (idxA === -1 && idxB === -1) return 0;
                if (idxA === -1) return 1;
                if (idxB === -1) return -1;
                return idxA - idxB;
            });
        }

        // 3. Filter by Carousel Selections (New)
        const selections = AppState.carouselSelections;

        // Apply Carousel Selections Filter
        if (selections && selections.size > 0) {
            fullList = fullList.filter(item => selections.has(item.id));
        }

        // Apply Hidden Watchlists Filter (Strict)
        if (AppState.hiddenWatchlists && AppState.hiddenWatchlists.size > 0) {
            fullList = fullList.filter(item => !AppState.hiddenWatchlists.has(item.id));
        }

        if (fullList.length === 0) return;

        // 4. Find current index
        const currentId = AppState.watchlist.id || PORTFOLIO_ID;
        let currentIndex = fullList.findIndex(item => item.id === currentId);

        // If current watchlist is not in the filtered cycle, reset to start of cycle
        if (currentIndex === -1) currentIndex = 0;

        // 5. Calculate next index
        let nextIndex = (currentIndex + direction + fullList.length) % fullList.length;
        const nextWatchlist = fullList[nextIndex];

        // 6. Rapid Navigation Guard
        if (this._carouselGuard) return;
        this._carouselGuard = true;

        // 7. Trigger switch
        this.handleSwitchWatchlist(nextWatchlist.id);

        // Reset guard after 300ms to allow next navigation
        setTimeout(() => {
            this._carouselGuard = false;
        }, 300);
    }

    /* ================= Internal Helpers ================= */

    _handleViewToggle() {
        const modes = ['table', 'compact', 'snapshot'];
        const currentMode = (AppState.viewMode || 'table').toLowerCase();
        let currentIdx = modes.indexOf(currentMode);
        if (currentIdx === -1) currentIdx = 0;

        const nextIdx = (currentIdx + 1) % modes.length;
        const nextMode = modes[nextIdx];

        this.changeViewMode(nextMode);
        this.headerLayout.updateViewToggleIcon(nextMode);
    }

    /**
     * Toggles the current sort direction (Triggered by Title Bar chevron)
     * Replicates the logic of the directional toggle button in the modal.
     */
    _handleSortToggle() {
        const currentSort = AppState.sortConfig;
        if (!currentSort) return;

        const newDirection = currentSort.direction === 'asc' ? 'desc' : 'asc';
        const newSort = { ...currentSort, direction: newDirection };

        // 1. Handle Global Sort Persistence
        const isGlobalActive = !!AppState.preferences.globalSort;
        if (isGlobalActive) {
            const currentGlobal = AppState.preferences.globalSort;
            if (currentGlobal.field === newSort.field) {
                AppState.saveGlobalSort(newSort, true); // Persist updated direction
                if (this.watchlistUI) this.watchlistUI.updateHeaderTitle();
            }
        }

        // 2. Update State & Local Persistence
        AppState.sortConfig = newSort;
        AppState.saveSortConfigForWatchlist(AppState.watchlist.id);

        // 3. Refresh Data
        if (AppState.watchlist.type === 'cash') {
            this.cashController.refreshView();
        } else {
            this.updateDataAndRender(false);
        }

        // 4. Update UI Button
        const contextId = AppState.watchlist.type === 'cash' ? 'CASH' : AppState.watchlist.id;
        this.viewRenderer.updateSortButtonUI(contextId, newSort);
    }

    _handleSortClick() {
        const wId = AppState.watchlist.id;
        const wType = AppState.watchlist.type;
        let contextId = wId;
        if (wType === 'cash') contextId = 'CASH';

        // 1. Define Callbacks first to capture references
        /**
         * @param {Object} newSort - { field, direction }
         * @param {string} source - 'LIST' (user tapped row) | 'TOGGLE' (user tapped directional toggle)
         */
        const onSelect = (newSort, source = 'LIST') => {
            // === GLOBAL SORT HANDLING ===
            const isGlobalActive = !!AppState.preferences.globalSort;

            if (isGlobalActive) {
                if (source === 'LIST') {
                    // TERMINATION RULE: Tapping any list item (even current one) Disable Global Sort
                    AppState.saveGlobalSort(null);
                    if (this.watchlistUI) this.watchlistUI.updateHeaderTitle();
                } else if (source === 'TOGGLE') {
                    // PERSISTENCE RULE: Tapping Toggle preserves Global Sort (Just updates direction)
                    // Validation: Ensure we are toggling the ACTIVE global sort field
                    const currentGlobal = AppState.preferences.globalSort;
                    if (currentGlobal.field === newSort.field) {
                        if (this.watchlistUI) this.watchlistUI.updateHeaderTitle();
                    } else {
                        // Edge case: Toggle on a field that isn't global? (Shouldn't happen in UI)
                        AppState.saveGlobalSort(null);
                        if (this.watchlistUI) this.watchlistUI.updateHeaderTitle();
                    }
                }
            }

            // Update UI to reflect new sort
            this._applySort(newSort);
        };

        const onHide = () => {
            this._sanitizeActiveSort();
            this.updateDataAndRender(false);
        };

        const onGlobalCancel = () => {
            if (AppState.preferences.globalSort) {
                AppState.saveGlobalSort(null);
                if (this.watchlistUI) this.watchlistUI.updateHeaderTitle();
                // We don't need to re-render data immediately, just the title bar.
            }
        };

        const onGlobalToggle = (toggleSort) => {
            const currentGlobal = AppState.preferences.globalSort;
            const isSame = currentGlobal && currentGlobal.field === toggleSort.field && currentGlobal.direction === toggleSort.direction;

            if (isSame) {
                // Toggle OFF
                AppState.saveGlobalSort(null);
            } else {
                // Toggle ON
                AppState.saveGlobalSort(toggleSort);
                AppState.sortConfig = { ...toggleSort };
            }

            // Refresh Data & UI
            if (AppState.watchlist.type === 'cash') {
                this.cashController.refreshView();
            } else {
                this.updateDataAndRender(false);
            }

            // Refresh Title Bar (Apply/Remove Coffee + Globe)
            if (this.watchlistUI) this.watchlistUI.updateHeaderTitle();

            // IMMEDIATE HEADER BUTTON UPDATE (Fix Latency)
            this.viewRenderer.updateSortButtonUI(contextId, AppState.sortConfig);

            // Re-render Modal IMMEDIATE (using captured callbacks)
            this.viewRenderer.renderSortPickerModal(
                contextId,
                AppState.sortConfig,
                onSelect,
                onHide,
                onGlobalToggle,
                onGlobalCancel
            );
        };

        // 2. Initial Render
        this.viewRenderer.renderSortPickerModal(
            contextId,
            AppState.sortConfig,
            onSelect,
            onHide,
            onGlobalToggle,
            onGlobalCancel
        );
    }



    _bindGlobalEvents() {
        if (this._globalEventsBound) return;
        this._globalEventsBound = true;

        const signInBtn = document.getElementById(IDS.SPLASH_SIGN_IN_BTN);
        if (signInBtn) {
            signInBtn.addEventListener('click', async () => {
                try {
                    // Phase 1: Immediate Click Feedback
                    signInBtn.disabled = true;
                    signInBtn.style.pointerEvents = 'none';
                    signInBtn.classList.add(CSS_CLASSES.DISABLED);

                    const shimmerSpan = signInBtn.querySelector(`.${CSS_CLASSES.TEXT_SHIMMER}`);
                    if (shimmerSpan) {
                        shimmerSpan.innerHTML = `<i class="fab fa-google"></i> Opening...`;
                    }

                    await AuthService.signIn();

                    // Phase 2: Post-Selection (Selected account)
                    if (shimmerSpan) {
                        shimmerSpan.innerHTML = `<i class="fab fa-google"></i> ${USER_MESSAGES.SIGNING_IN}`;
                    }
                } catch (error) {
                    console.error('Sign in failed:', error);
                    ToastManager.error(`${USER_MESSAGES.SIGN_IN_FAILED} ${error.message}`);

                    // Reset on error
                    signInBtn.disabled = false;
                    signInBtn.style.pointerEvents = 'auto';
                    signInBtn.classList.remove(CSS_CLASSES.DISABLED);
                    const shimmerSpan = signInBtn.querySelector(`.${CSS_CLASSES.TEXT_SHIMMER}`);
                    if (shimmerSpan) {
                        shimmerSpan.innerHTML = `<i class="fab fa-google"></i> Sign in with Google`;
                    }
                }
            });
        }

        const logoutBtn = document.getElementById(IDS.LOGOUT_BTN);
        if (logoutBtn) {
            logoutBtn.addEventListener('click', async () => {
                try {
                    await AuthService.signOut();
                } catch (error) {
                    console.error('Sign out failed:', error);
                }
            });
        }

        // --- STYLING PERSISTENCE (USER REQUEST) ---
        // Listens for border or intensity changes to trigger immediate UI re-render
        document.addEventListener(EVENTS.REFRESH_WATCHLIST, () => {
            this.updateDataAndRender(false); // Render current state without fetching
        });

        // GLOBAL INTERCEPTOR: CommSec Deep Links (Firebase Dynamic Link)
        // This ensures that ANY CommSec link clicked in the app (Research, Shortcuts, etc.) 
        // is automatically converted to the deep link format to open the native app.
        document.body.addEventListener('click', (e) => {
            const link = e.target.closest('a');
            if (!link || !link.href) return;

            // 0. GEMINI (Internal Interaction Handling)
            // Prevent the global interceptor from capturing links handled by bindGeminiInteraction
            if (link.href.includes('gemini.google.com')) return;

            // 1. COMMSEC (Firebase Dynamic Link)
            if (link.href.includes('commsec.com.au') && !link.href.includes('page.link')) {
                e.preventDefault();
                e.stopPropagation();

                // Standard Dynamic Link (Opens App to Home Page)
                // Note: Direct navigation to specific stock codes is not supported via public deep links.
                const encodedTarget = encodeURIComponent(link.href);
                const deepLink = `https://commsecau.page.link/?link=${encodedTarget}&apn=au.com.commsec.android`;
                window.open(deepLink, '_blank', 'noopener,noreferrer');
                return;
            }

            // 2. SELFWEALTH (Android Intent - Deep Link)
            // Package ID confirmed by user: au.com.selfwealth.mobilev2
            // Reinstated per user request. Creates a detailed intent to launch the app.
            if (link.href.toLowerCase().includes('selfwealth.com.au')) {
                e.preventDefault();
                e.stopPropagation();

                // Construct Deep Link Intent
                const cleanUrl = link.href.replace(/^https?:\/\//, '');
                const fallback = encodeURIComponent(link.href);
                const intentUrl = `intent://${cleanUrl}#Intent;scheme=https;package=au.com.selfwealth.mobilev2;S.browser_fallback_url=${fallback};end`;
                window.open(intentUrl, '_blank', 'noopener,noreferrer');
                return;
            }

            // 3. UNIVERSAL: Open all other external links in the "App Browser" (Custom Tab)
            // This ensures Research links, custom links, and registry links stay in-app.
            if (link.href.startsWith('http') && !link.href.includes(window.location.hostname)) {
                e.preventDefault();
                e.stopPropagation();
                LinkHelper.openInAppBrowser(link.href);
            }
        }, true); // Use Capture Phase to win against other listeners
    }

    /**
     * Set the Sign-In button to a loading state.
     * @param {boolean} isLoading 
     * @param {string} [text] Optional text override (e.g. "Signing In...")
     */
    _setSignInLoadingState(isLoading, text = 'Initializing...') {
        const signInBtn = document.getElementById(IDS.SPLASH_SIGN_IN_BTN);
        if (!signInBtn) return;

        const shimmerSpan = signInBtn.querySelector(`.${CSS_CLASSES.TEXT_SHIMMER}`);

        if (isLoading) {
            signInBtn.disabled = true;
            signInBtn.style.pointerEvents = 'none';
            signInBtn.classList.add(CSS_CLASSES.DISABLED);
            if (shimmerSpan) shimmerSpan.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${text}`;
        } else {
            signInBtn.disabled = false;
            signInBtn.style.pointerEvents = 'auto';
            signInBtn.classList.remove(CSS_CLASSES.DISABLED);
            if (shimmerSpan) shimmerSpan.innerHTML = `<i class="fab fa-google"></i> Sign in with Google`;
        }
    }

    /**
     * SANITIZATION PROTOCOL
     * Ensures the app never displays a hidden watchlist.
     * Called after cloud prefs load or whenever hiddenWatchlists changes.
     */
    _sanitizeActiveWatchlist() {
        const currentId = AppState.watchlist.id || 'portfolio';
        const isHidden = AppState.hiddenWatchlists.has(currentId);

        if (isHidden) {
            // Priority Order: Dashboard -> All Shares -> Portfolio (if visible) -> First Custom
            let targetId = DASHBOARD_WATCHLIST_ID;

            // If Dashboard is also hidden (rare/impossible usually), try others
            if (AppState.hiddenWatchlists.has(targetId)) {
                if (!AppState.hiddenWatchlists.has(ALL_SHARES_ID)) targetId = ALL_SHARES_ID;
                else if (!AppState.hiddenWatchlists.has(PORTFOLIO_ID)) targetId = PORTFOLIO_ID;
                else {
                    // Find first visible custom list
                    const customLists = AppState.data.watchlists || [];
                    const firstVisible = customLists.find(w => !AppState.hiddenWatchlists.has(w.id));
                    if (firstVisible) targetId = firstVisible.id;
                    else targetId = ALL_SHARES_ID; // Fallback to All Shares even if "hidden" in UI preference, to avoid blank screen.
                }
            }

            this.handleSwitchWatchlist(targetId, true); // Pass true for isBoot
            this._initialRenderComplete = true; // Ensure splash hides
        }

    }

    /**
     * DEBOUNCED SORT CONFIG WRITER
     * Prevents dual-write state audit race collisions during rapid switch/boot phases.
     *
     * FIX: Always stamp _lastSortConfigWriteTime when entering the immediate path,
     * even when the value is unchanged. This ensures any subsequent call within
     * 55ms is correctly debounced — previously a no-op first call (same value)
     * left the timer at 0, causing the second call to bypass the debounce guard.
     * Re-stamp after _sanitizeActiveSort() to account for its own sortConfig write.
     */
    /**
     * PURE SORT SANITIZATION HELPER
     * Returns a sanitized sort config if the given one is hidden.
     */
    _getSanitizedSort(sortConfig, watchlistId) {
        if (!sortConfig) return sortConfig;
        const type = this._getSortType(watchlistId);
        const hiddenSet = AppState.hiddenSortOptions?.[type];

        if (!hiddenSet || hiddenSet.size === 0) return sortConfig;

        const sortKey = `${sortConfig.field}-${sortConfig.direction}`;
        if (hiddenSet.has(sortKey)) {
            // Fallback Defaults
            let fallback = { field: 'code', direction: 'asc' };
            if (type === 'CASH') fallback = { field: 'category', direction: 'asc' };

            // Validate Fallback isn't also hidden (extreme edge case)
            if (hiddenSet.has(`${fallback.field}-${fallback.direction}`)) {
                // Find first non-hidden option from registry
                const options = SORT_OPTIONS[type] || SORT_OPTIONS.STOCK;
                const firstVisible = options.find(opt => !hiddenSet.has(`${opt.field}-${opt.direction}`));
                if (firstVisible) {
                    fallback = { field: firstVisible.field, direction: firstVisible.direction };
                }
            }
            return fallback;
        }
        return sortConfig;
    }

    /**
     * DEBOUNCED SORT CONFIG WRITER
     * Prevents dual-write state audit race collisions during rapid switch/boot phases.
     *
     * FIX: Sanitize the target configuration before writing to AppState.sortConfig
     * to eliminate double-write race conditions when a hidden option is selected.
     */
    _updateSortConfig(newSort, watchlistId, isBoot = false) {
        const sanitizedSort = this._getSanitizedSort(newSort, watchlistId);

        // DEDUPLICATION GUARD: If new sort matches AppState.sortConfig, return early to prevent double-write race conditions.
        if (AppState.sortConfig &&
            AppState.sortConfig.field === sanitizedSort.field &&
            AppState.sortConfig.direction === sanitizedSort.direction) {
            if (this.viewRenderer) {
                this.viewRenderer.updateSortButtonUI(watchlistId, AppState.sortConfig);
            }
            return;
        }

        this._pendingSortConfig = sanitizedSort;

        if (this._sortConfigDebounceTimer) {
            clearTimeout(this._sortConfigDebounceTimer);
        }

        const now = Date.now();
        const lastWrite = this._lastSortConfigWriteTime || 0;
        const timeDelta = now - lastWrite;

        if (timeDelta < 55) {
            // Rapid write detected — defer to clear the StateAuditor 50ms window.
            this._sortConfigDebounceTimer = setTimeout(() => {
                const target = this._pendingSortConfig;
                if (target && JSON.stringify(AppState.sortConfig) !== JSON.stringify(target)) {
                    this._lastSortConfigWriteTime = Date.now();
                    AppState.sortConfig = { ...target };
                    this._lastSortConfigWriteTime = Date.now();
                    this.viewRenderer.updateSortButtonUI(AppState.watchlist.id, AppState.sortConfig);
                    this.updateDataAndRender(false).catch(e => console.warn('Render error:', e));
                }
                this._sortConfigDebounceTimer = null;
            }, 55 - timeDelta + 5);
        } else {
            // Safe window — write immediately.
            this._lastSortConfigWriteTime = now;
            if (JSON.stringify(AppState.sortConfig) !== JSON.stringify(sanitizedSort)) {
                AppState.sortConfig = { ...sanitizedSort };
            }
            this._lastSortConfigWriteTime = Date.now();
        }
    }

    /**
     * SORT SANITIZATION PROTOCOL
     * Ensures that if the current sort is hidden, we fall back to a visible default.
     */
    _sanitizeActiveSort() {
        const sanitized = this._getSanitizedSort(AppState.sortConfig, AppState.watchlist.id);
        if (JSON.stringify(AppState.sortConfig) !== JSON.stringify(sanitized)) {
            AppState.sortConfig = sanitized;
            AppState.saveSortConfigForWatchlist(AppState.watchlist.id);
        }
    }

    /**
     * PROGRAMMATIC SORT APPLICATION
     * Applies a sort configuration directly without opening the UI picker.
     * @param {Object} sortConfig { field, direction }
     */
    _applySort(sortConfig) {
        if (!sortConfig || !sortConfig.field) return;

        const wType = AppState.watchlist.type;
        const contextId = wType === 'cash' ? 'CASH' : AppState.watchlist.id;

        // Update AppState only if changed
        if (JSON.stringify(AppState.sortConfig) !== JSON.stringify(sortConfig)) {
            AppState.sortConfig = sortConfig;
        }

        // Persist
        AppState.saveSortConfigForWatchlist(AppState.watchlist.id);

        // Render
        if (wType === 'cash') {
            this.cashController.refreshView();
        } else {
            this.updateDataAndRender(false);
        }

        // Update Button UI
        if (this.viewRenderer) {
            this.viewRenderer.updateSortButtonUI(contextId, sortConfig);
        }
    }

    /**
     * Map watchlist ID to sort type (STOCK, PORTFOLIO, CASH)
     * @param {string} watchlistId 
     * @returns {string}
     */
    _getSortType(watchlistId) {
        if (watchlistId === 'CASH') return 'CASH';
        if (watchlistId === 'portfolio') return 'PORTFOLIO';
        return 'STOCK';
    }

    _setupDelegatedEvents() {
        if (this._eventsDelegated) return;
        this._eventsDelegated = true;

        // Global Add Item Delegation (Sidebar & Header)
        document.body.addEventListener('click', (e) => {
            const addBtn = e.target.closest(`#${IDS.SIDEBAR_ADD_BTN}`) || e.target.closest(`#${IDS.HEADER_ADD_BTN}`);
            if (addBtn) {
                if (this.headerLayout) this.headerLayout.closeSidebar();

                // Standard delay reduced to 0ms for instantaneous feeling
                setTimeout(() => {
                    if (AppState.watchlist.id === CASH_WATCHLIST_ID) {
                        this.modalController.handleOpenCashModal(null);
                    } else {
                        this.modalController.openAddShareModal(null);
                    }
                }, 0);
            }
        });

        // Portfolio Visibility Toggle Button Delegation
        document.body.addEventListener('click', (e) => {
            const visBtn = e.target.closest('.portfolio-visibility-btn');
            if (visBtn) {
                e.preventDefault();
                e.stopPropagation();
                const id = visBtn.dataset.id;
                if (id) {
                    document.dispatchEvent(new CustomEvent(EVENTS.SHARE_TOGGLE_VISIBILITY, { detail: { id } }));
                }
            }
        });

        // Cash Asset Selection Delegation
        document.body.addEventListener(EVENTS.CASH_ASSET_SELECTED, (e) => {
            const assetId = e.detail.assetId || (e.detail.asset ? e.detail.asset.id : null);
            if (assetId) {
                this.modalController.handleOpenCashModal(assetId);
            }
        });

        // Initial Sort UI
        if (this.viewRenderer) {
            this.viewRenderer.updateSortButtonUI(AppState.watchlist.id, AppState.sortConfig);
        }

        // Sidebar Auto-Close
        const sidebarContent = document.querySelector('.sidebar-content');
        if (sidebarContent) {
            sidebarContent.addEventListener('click', (e) => {
                if (e.target.closest('button') || e.target.closest('a')) {
                    if (this.headerLayout) this.headerLayout.closeSidebar();
                }
            });
        }

        // Hard Reload Button - Intentional page reload for cache bust (Settings Feature)
        // Hard Reload Button - Intentional page reload for cache bust (Settings Feature)
        document.body.addEventListener('click', async (e) => {
            const reloadBtn = e.target.closest(`#${IDS.RELOAD_BTN}`);
            if (reloadBtn) {
                if (confirm('Reload the app? This will clear caches to ensure you have the latest version. Your data will be safe.')) {

                    // User Feedback
                    ToastManager.show('Cleaning caches and updating...', 'info');

                    try {
                        // 1. Clear Session Storage (Temporary Tab Data)
                        sessionStorage.clear();

                        // 2. Clear Cache Storage API (The heavy lifter for PWA assets)
                        if ('caches' in window) {
                            const cacheKeys = await caches.keys();
                            await Promise.all(cacheKeys.map(key => {
                                return caches.delete(key);
                            }));
                        }

                        // 3. Unregister Service Workers (Prevent stale fetching on next load)
                        if ('serviceWorker' in navigator) {
                            const registrations = await navigator.serviceWorker.getRegistrations();
                            await Promise.all(registrations.map(registration => {
                                return registration.unregister();
                            }));
                        }

                    } catch (err) {
                        console.warn('[AppController] Issue during cache cleanup (continuing to reload):', err);
                    } finally {
                        // 4. Force Reload from Server
                        window.location.reload(true);
                    }
                }
            }
        });

        document.getElementById('btn-general-settings')?.addEventListener('click', () => {
            if (this.headerLayout) this.headerLayout.closeSidebar();
            setTimeout(() => {
                GeneralSettingsUI.showModal(this);
            }, 150);
        });

        // Deprecated: btn-security-settings (Moved to General Settings)
        // Kept comments for reference or removal if cleaner.

        // Calculator UI now handled via HeaderLayout callbacks for integrated sidebar UX






        // Code Pills (ASX Details)
        document.body.addEventListener('click', (e) => {
            // Market Index Link Handling
            const marketIndexBtn = e.target.closest('[data-action="market-index"]');
            if (marketIndexBtn) {
                e.preventDefault();
                e.stopPropagation();
                const code = marketIndexBtn.dataset.code;
                if (code) {
                    const url = `https://www.marketindex.com.au/asx/${code.toLowerCase()}`;
                    LinkHelper.openInAppBrowser(url);
                }
                return;
            }

            // Deep Link Handling (Alerts/Notes) - Global delegation to catch Modals too
            const deepLink = e.target.closest('[data-action="deep-link"]');
            if (deepLink) {
                e.preventDefault();
                e.stopPropagation();
                const id = deepLink.dataset.id;
                const section = deepLink.dataset.section;
                if (id && section) {
                    this.modalController.openAddShareModal(id, section);
                }
                return;
            }

            const pill = e.target.closest('.code-pill') || e.target.closest('.asx-dropdown-pill');
            if (pill && pill.dataset.code) {
                const code = pill.dataset.code;

                // Safety delay for modal transitions (e.g. from a dropdown or modal)
                setTimeout(() => {
                    const stockData = getSingleShareData(code, AppState.data.shares, AppState.livePrices, AppState.data.watchlists);
                    if (stockData) {
                        this.viewRenderer.renderStockDetailsModal(stockData);
                        document.getElementById(IDS.ASX_DROPDOWN_MENU)?.classList.remove(CSS_CLASSES.SHOW);
                    } else {
                        // Fallback: Open Discovery Modal
                        document.dispatchEvent(new CustomEvent(EVENTS.OPEN_RESEARCH_MODAL, { detail: { query: code } }));
                        document.getElementById(IDS.ASX_DROPDOWN_MENU)?.classList.remove(CSS_CLASSES.SHOW);
                    }
                }, 150);
            }
        });

        // Live Refresh Button Delegation
        document.body.addEventListener('click', (e) => {
            const btn = e.target.closest(`#${IDS.LIVE_REFRESH_BTN}`);
            if (btn) {
                e.preventDefault(); // Good practice for buttons
                ToastManager.show('Refreshing Live Prices...', 'refresh');
                // Manual tap: bypass interval throttling (force = true), silent = false
                this._refreshAllPrices(AppState.data.shares || [], true, false).then(() => {
                    this.updateDataAndRender(false);
                }).catch(err => {
                    console.warn('[AppController] Manual price refresh failed:', err);
                });
            }
        });

        // Initial Time Set (Defer to ensure DOM is ready)
        // Handled by HeaderLayout reactive listener and init()

        const container = document.getElementById(IDS.CONTENT_CONTAINER);
        if (!container) return;

        container.addEventListener('click', async (e) => {
            // Add Stock (Quick Add) - MOVED TO DELEGATED HANDLER
            // See _setupDelegatedEvents for the 'click' handler on #add-stock-submit
            if (e.target.closest(`#${IDS.ADD_STOCK_SUBMIT}`)) {
                // Actually, this IS the delegated handler logic spot if we want to keep it here, 
                // BUT my intent was to rely on valid structure. 
                // The previous edit deleted the `container.addEventListener` line.
                // Re-adding the wrapper structure correctly.
                return;
            }

            // Stock Details (Row Click)
            if (e.target.closest('button') || e.target.closest('a') || e.target.closest('input')) return;

            const row = e.target.closest('tr');
            const card = e.target.closest('.share-card');
            const item = row || card;

            if (item && item.dataset.code) {
                const code = item.dataset.code;
                // Eliminated delay for row click transitions
                setTimeout(() => {
                    const stockData = getSingleShareData(code, AppState.data.shares, AppState.livePrices, AppState.data.watchlists);
                    if (stockData) {
                        this.viewRenderer.renderStockDetailsModal(stockData);
                    }
                }, 0);
            }
        });

        container.addEventListener('keypress', (e) => {
            if (e.target.id === IDS.NEW_STOCK_CODE && e.key === 'Enter') {
                document.getElementById(IDS.ADD_STOCK_SUBMIT)?.click();
            }
        });

        // Edit Share Request Listener (Custom Event)
        // Triggered by ViewRenderer dispatching EVENTS.REQUEST_EDIT_SHARE
        document.addEventListener(EVENTS.REQUEST_EDIT_SHARE, (e) => {
            let targetId = e.detail?.id || e.detail?.shareId;
            const targetCode = e.detail?.code;

            // RECOVERY MECHANISM: If ID is missing but Code exists, look it up.
            if (!targetId && targetCode) {
                const found = AppState.data.shares.find(s => (s.shareName || '').toUpperCase() === targetCode.toUpperCase());
                if (found && found.id) {
                    targetId = found.id;
                } else {
                    // Fallback: Open as new share pre-filled
                    this.modalController.openAddShareModal({ shareName: targetCode });
                    return;
                }
            }

            if (targetId) {
                const delay = e.detail.instant ? 0 : 0; // Delay eliminated
                // Safety delay for transition from detail to edit
                setTimeout(() => {
                    // DEEP LINK: Pass specific section if requested (e.g. 'notes', 'target')
                    this.modalController.openAddShareModal(targetId, e.detail.section);
                }, delay);
            } else {
                ToastManager.error('Could not edit share. Missing ID.');
            }
        });

        // Live Refresh of Stock Details (e.g. after Edit)
        document.addEventListener(EVENTS.REQUEST_REFRESH_DETAILS, (e) => {
            const { code } = e.detail || {};
            if (!code) return;

            // Check if Modal is Open
            const modal = document.getElementById(IDS.STOCK_DETAILS_MODAL);
            if (modal && !modal.classList.contains(CSS_CLASSES.HIDDEN)) {
                // Verify it's the right stock (optional check, but good for safety)
                const titleEl = modal.querySelector(`.${CSS_CLASSES.DISPLAY_TITLE}`);
                if (titleEl && titleEl.textContent === code) {
                    // Refetch Data
                    const stockData = getSingleShareData(code, AppState.data.shares, AppState.livePrices, AppState.data.watchlists);
                    if (stockData) {
                        this.viewRenderer.renderStockDetailsModal(stockData);
                    }
                }
            }
        });

        // Open Search Discovery Modal (from sidebar button)
        document.addEventListener(EVENTS.REQUEST_OPEN_DISCOVERY_MODAL, () => {
            // Already includes delay in HeaderLayout, but for redundancy/consistency:
            SearchDiscoveryUI.showModal();
        });

        // Research Links Management Listener
        document.addEventListener('REQUEST_RESEARCH_LINKS_MANAGE', (e) => {
            // Delay to ensure the detail modal's historical context is clear
            setTimeout(() => {
                try {
                    ResearchLinksUI.show(e.detail?.code);
                } catch (err) {
                    console.error('[AppController] Error opening ResearchLinksUI:', err);
                }
            }, 150);
        });

        // Handle Add Share Pre-fill (from Discovery Modal -> Add Share Modal handoff)
        document.addEventListener(EVENTS.REQUEST_ADD_SHARE_PREFILL, (e) => {
            // GLOBAL DISMISSAL SAFETY: Forcefully remove any discovery modal immediately
            const discoveryModals = document.querySelectorAll(`[id="${IDS.DISCOVERY_MODAL}"]`);
            discoveryModals.forEach(m => {
                m.style.display = 'none'; // Visual safety
                m.style.pointerEvents = 'none'; // Interaction safety
                if (m._close) {
                    m._close();
                } else {
                    m.remove();
                }
            });

            const { stock } = e.detail || {};
            if (stock?.code) {
                // DUPLICATE CHECK: Search -> Add Flow
                const existingShare = AppState.data.shares.find(s => s.shareName === stock.code || s.shareName === stock.code.toUpperCase());

                if (existingShare) {
                    // Check if it's a Ghost Share (missing ID)
                    if (existingShare.id) {
                        this.modalController.openAddShareModal(existingShare.id);
                    } else {
                        // GHOST SHARE RECOVERY
                        // Pass the shareName to trigger Pre-fill/Recovery path in ModalController
                        this.modalController.openAddShareModal({
                            shareName: existingShare.shareName,
                            title: existingShare.name || stock.name || ''
                        });
                    }
                } else {
                    // Safety delay for transition from search to add
                    // Use a shorter delay here as the Discovery Modal dismissal is already in progress
                    setTimeout(() => {
                        this.modalController.openAddShareModal({ shareName: stock.code, title: stock.name });
                    }, 100);
                }
            }
        });

        // Visibility Toggle (Eye Icon)
        document.addEventListener(EVENTS.SHARE_TOGGLE_VISIBILITY, (e) => {
            const { id } = e.detail || {};
            if (id) {
                AppState.toggleHiddenAsset(id);
                const isHidden = AppState.hiddenAssets.has(id);

                // Fetch Name
                const share = (AppState.data.shares || []).find(s => s.id === id);
                const name = share ? (share.shareName || share.code) : 'Share';

                // Toast Feedback
                ToastManager.success(isHidden ? `${name} hidden.` : `${name} visible.`);

                this.updateDataAndRender(false);

                // ARCHITECTURAL FIX: Persist immediately to cloud
                this.appService.saveUserPreferences({ hiddenAssets: [...AppState.hiddenAssets] })
                    .catch(e => console.warn('Failed to sync hidden assets:', e));
            }
        });

        // === WATCHLIST CRUD EVENT LISTENERS ===
        // These events are dispatched by HeaderLayout.js modals

        // CREATE WATCHLIST
        document.addEventListener(EVENTS.REQUEST_NEW_WATCHLIST, async (e) => {
            const { name, excludeFromAll } = e.detail || {};
            if (!name || !AppState.user) {
                return;
            }

            try {
                const newId = await this.appService.addWatchlist(name, excludeFromAll);
                if (newId) {
                    // Switch to new watchlist - User initiated
                    this.handleSwitchWatchlist(newId, false);
                    ToastManager.success(`Watchlist "${name}" created.`);
                }
            } catch (err) {
                console.error('Failed to create watchlist:', err);
                ToastManager.error('Failed to create watchlist: ' + err.message);
            }
        });

        // UPDATE (RENAME/CONFIGURE) WATCHLIST
        document.addEventListener(EVENTS.REQUEST_UPDATE_WATCHLIST, async (e) => {
            const { id, newName, excludeFromAll } = e.detail || {};
            if (!id || !newName || !AppState.user) {
                return;
            }

            // Handle system vs custom watchlist renaming
            const systemIds = [ALL_SHARES_ID, PORTFOLIO_ID, CASH_WATCHLIST_ID, DASHBOARD_WATCHLIST_ID, SIMULATIONS_WATCHLIST_ID, 'portfolio'];
            const isSystem = systemIds.includes(id);

            try {
                if (isSystem) {
                    AppState.saveCustomWatchlistName(id, newName);
                } else {
                    await this.appService.updateWatchlistSettings(id, newName, excludeFromAll);
                }
                // Refresh UI
                this.watchlistUI.updateHeaderTitle();
                this.watchlistUI.renderWatchlistDropdown();
                ToastManager.success(`Watchlist updated.`);
            } catch (err) {
                console.error('Failed to update watchlist:', err);
                ToastManager.error('Failed to update watchlist: ' + err.message);
            }
        });

        // DELETE WATCHLIST (with orphan share warning)
        document.addEventListener(EVENTS.REQUEST_DELETE_WATCHLIST, async (e) => {
            const { id } = e.detail || {};
            if (!id || !AppState.user) {
                console.warn('DELETE: Missing id or user not logged in');
                return;
            }

            // Prevent deleting system views
            if (id === 'portfolio' || id === 'ALL' || id === 'CASH') {
                alert('Cannot delete system views.');
                return;
            }

            // Get watchlist info
            const watchlist = (AppState.data.watchlists || []).find(w => w.id === id);
            if (!watchlist) {
                console.warn('DELETE: Watchlist not found:', id);
                return;
            }

            // 1. Find all shares currently assigned to this watchlist (by ID)
            const allShares = AppState.data.shares || [];

            // Filter shares that belong to this watchlist (Robust check for array or string)
            const sharesInWatchlist = allShares.filter(s => {
                if (Array.isArray(s.watchlistIds)) return s.watchlistIds.includes(id);
                return s.watchlistId === id;
            });

            // 2. Identify Orphans (Shares that are ONLY in this watchlist) vs Safe Shares
            const orphans = [];
            const safeShares = [];

            for (const share of sharesInWatchlist) {
                // Check membership count
                // New Architecture: Check watchlistIds array length
                // Legacy Fallback: If no array, assume it's the only one (Orphan) unless we find duplicates (Old Method - deprecated but safe to ignore if migrated)

                let isOrphan = true;
                if (Array.isArray(share.watchlistIds)) {
                    // 2b. ROBUST ORPHAN DETECTION (Fixes "Ghost Share" Bug)
                    // A share is ONLY "Safe" if it exists in another VALID, ACTIVE watchlist.

                    // Build Valid ID Set (Active User Lists + System Lists)
                    const validWatchlistIds = new Set((AppState.data.watchlists || []).map(w => w.id));
                    validWatchlistIds.add('portfolio');
                    validWatchlistIds.add('ALL');
                    validWatchlistIds.add('CASH');
                    validWatchlistIds.add('DASHBOARD');

                    // Filter active memberships: 
                    // 1. Must NOT be the current list (id)
                    // 2. Must be a VALID known watchlist (validWatchlistIds)
                    const activeMemberships = share.watchlistIds.filter(wid =>
                        wid !== id &&
                        validWatchlistIds.has(wid)
                    );

                    if (activeMemberships.length > 0) {
                        isOrphan = false; // It has a home!
                    } else {
                        isOrphan = true; // No valid home elsewhere -> Orphan
                    }
                } else {
                    // Legacy: Check if exists elsewhere by name (Double Up logic)
                    const existsElsewhere = allShares.some(s =>
                        s.shareName === share.shareName &&
                        s.id !== share.id &&
                        s.watchlistId !== id
                    );
                    if (existsElsewhere) isOrphan = false;
                }

                if (isOrphan) {
                    orphans.push(share);
                } else {
                    safeShares.push(share);
                }
            }

            // Build confirmation message
            let message = `You are about to delete watchlist "${watchlist.name}".\n\n`;
            if (orphans.length > 0) {
                message += `The following shares will be PERMANENTLY DELETED (they are not in any other list):\n`;
                message += orphans.map(s => `- ${s.shareName}`).join('\n');
                message += `\n\n`;
            }

            if (safeShares.length > 0) {
                message += `The following shares will remain in their other watchlists:\n`;
                message += safeShares.map(s => `- ${s.shareName}`).join('\n');
                message += `\n\n`;
            }

            message += `Are you sure you want to proceed?`;

            if (!confirm(message)) return;

            try {
                // 3. Delete Orphans (Permanent Delete)
                if (orphans.length > 0) {
                    for (const share of orphans) {
                        await this.appService.deleteShareRecord(id, share.id);
                    }
                }

                // 4. Unlink Safe Shares (Remove ID from Array)
                if (safeShares.length > 0) {
                    for (const share of safeShares) {
                        // Use new "Unlink" method
                        await this.appService.removeShareFromWatchlist(id, share.id);
                    }
                }

                // 5. Delete Watchlist
                await this.appService.deleteWatchlist(id);

                // Refresh is automatic via subscription
                // Enhanced Toast Feedback
                let toastMsg = `Watchlist "${watchlist.name}" deleted.`;
                if (orphans.length > 0) toastMsg += ` ${orphans.length} deleted.`;
                if (safeShares.length > 0) toastMsg += ` ${safeShares.length} unlinked.`;
                ToastManager.success(toastMsg);

            } catch (err) {
                console.error('Delete Watchlist Error:', err);
                ToastManager.error('Failed to delete watchlist: ' + err.message);
            }
        });

        // DELETE SHARE HANDLER (Bulletproof Fix + Ghost Support)
        document.addEventListener(EVENTS.REQUEST_DELETE_SHARE, async (e) => {
            const { shareId, shareCode, watchlistId } = e.detail;

            if (!shareId && !shareCode) {
                return;
            }

            // 1. OPTIMISTIC DELETE (Immediate UI cleanup)
            const initialCount = (AppState.data.shares || []).length;

            // Filter by ID if available, otherwise by Code (Ghost Mode)
            AppState.data.shares = (AppState.data.shares || []).filter(s => {
                if (shareId && s.id === shareId) return false;
                if (!shareId && shareCode && (s.shareName === shareCode || s.code === shareCode)) return false; // Ghost Scrub
                return true;
            });

            const deletedCount = initialCount - AppState.data.shares.length;

            // Force Re-render immediately
            this.updateDataAndRender(false);

            // CLOSE DETAILS MODAL
            const detailsModal = document.getElementById(IDS.STOCK_DETAILS_MODAL);
            if (detailsModal) detailsModal.remove();

            const nameForToast = shareCode || 'Share';

            try {
                // 2. BACKEND SYNC
                if (shareId && shareId !== 'OPTIMISTIC_LOCK' && !shareId.startsWith('temp_')) {
                    // Standard Delete (Document + Scrub)
                    await this.appService.deleteShareRecord(watchlistId, shareId);
                } else if (!shareId && shareCode && watchlistId) {
                    // GHOST DELETE: We have no ID, so we can't delete a document.
                    // But we MUST scrub the reference from the watchlist to stop "Zombie Resurrection".
                    await this.appService.removeStock(shareCode, watchlistId);
                }

                ToastManager.success(`${nameForToast} deleted.`);

            } catch (err) {
                console.warn('[AppController] Backend delete failed (likely Ghost/Already Deleted):', err);
                ToastManager.success(`${nameForToast} removed (Local cleanup).`);
            }
        });

        // -------------------------------------------------------------------------
        // DELETE CASH ASSET HANDLER (Directive 020)
        // -------------------------------------------------------------------------
        document.addEventListener(EVENTS.REQUEST_DELETE_CASH_ASSET, async (e) => {
            const { id } = e.detail;
            if (!id) return;

            // 1. Notify Shield (Removed: Architectural fix handles this now)

            try {
                // 2. Call Service to delete from backend

                // Lookup Name (if possible) - Though data might be stale if service deletes first, 
                // but service is async. We can lookup first.
                // Actually AppState.data.cash is the source.
                const asset = (AppState.data.cash || []).find(a => a.id === id);
                const assetName = asset ? asset.name : 'Asset';

                await this.appService.deleteCashCategory(id);
                // UI will update via UserStore subscription -> updateDataAndRender -> refreshView
                ToastManager.success(`${assetName} deleted.`);
            } catch (err) {
                console.error('Delete Cash Error:', err);
                ToastManager.error('Failed to delete asset.');
            }
        });

        // -------------------------------------------------------------------------
        // CASH ASSET VISIBILITY TOGGLE (Delegate)
        // -------------------------------------------------------------------------
        document.addEventListener(EVENTS.CASH_ASSET_TOGGLE_VISIBILITY, (e) => {
            // Just proxy to controller
            if (this.cashController) {
                this.cashController.handleToggleVisibility(e.detail.assetId);
            }
        });

        // -------------------------------------------------------------------------
        // GENERAL NAVIGATION EVENTS
        // -------------------------------------------------------------------------



        // === SEARCH & RESEARCH EVENTS (TWO-STAGE DISCOVERY) ===

        // 1. General Symbol Search (Used by Add Modal directly too)
        document.addEventListener(EVENTS.REQUEST_SYMBOL_SEARCH, (e) => {
            const { query } = e.detail;
            const results = this.dataService.searchStocks(query, AppState.livePrices);
            document.dispatchEvent(new CustomEvent(EVENTS.UPDATE_SEARCH_RESULTS, { detail: { results } }));
        });

        // 1b. Single Live Price Request (Add/Edit Preview)
        document.addEventListener(EVENTS.REQUEST_LIVE_PRICE, async (e) => {
            const { code } = e.detail;
            if (!code) return;

            // Check cache first - but enforce freshness (60s)
            const cached = AppState.livePrices.get(code);
            const now = Date.now();
            const freshnessThreshold = 60 * 1000; // 1 minute

            if (cached && cached.lastUpdate && (now - cached.lastUpdate < freshnessThreshold)) {
                // Return cached data if fresh enough
                document.dispatchEvent(new CustomEvent(EVENTS.UPDATE_MODAL_PREVIEW, {
                    detail: { data: cached }
                }));
                return;
            }

            // Fetch fresh
            const result = await this.dataService.fetchLivePrices([code]);
            const map = result?.prices;
            if (map && map.has(code)) {
                const data = map.get(code);
                AppState.livePrices.set(code, data);

                document.dispatchEvent(new CustomEvent(EVENTS.UPDATE_MODAL_PREVIEW, {
                    detail: { data }
                }));
            }
        });

        // 2. Open Discovery Modal (Stage 1)
        document.addEventListener(EVENTS.OPEN_RESEARCH_MODAL, (e) => {
            const { query } = e.detail || {};
            SearchDiscoveryUI.showModal(query);
        });

        // 3. Discovery Internal Search
        document.addEventListener(EVENTS.REQUEST_DISCOVERY_SEARCH, (e) => {
            const { query } = e.detail;

            // Retrieve Global Scanner Filters
            const filters = AppState.preferences.scanner?.activeFilters;
            const activeFilters = (!query && Array.isArray(filters) && filters.length > 0) ? filters : null;

            // Pass filters to DataService (Unified Search)
            const results = this.dataService.searchStocks(query, AppState.livePrices, activeFilters);
            document.dispatchEvent(new CustomEvent(EVENTS.UPDATE_DISCOVERY_RESULTS, { detail: { results } }));
        });



        // 4.5 ASX Code Click Detail Route (Unified)
        document.addEventListener(EVENTS.ASX_CODE_CLICK, (e) => {
            const { code } = e.detail;
            if (!code) return;

            // Safety Delay: Eliminated for snappiness
            setTimeout(() => {
                const stockData = getSingleShareData(code, AppState.data.shares, AppState.livePrices, AppState.data.watchlists);
                if (stockData) {
                    this.viewRenderer.renderStockDetailsModal(stockData);
                    // Explicitly handle UI overlaps
                    document.getElementById(IDS.ASX_DROPDOWN_MENU)?.classList.remove(CSS_CLASSES.SHOW);
                } else {
                    // Fix: Redirect Dashboard Snapshot / Market Indices to Yahoo (as requested)
                    const upCode = code.toUpperCase();
                    const isDashboardSymbol = DASHBOARD_SYMBOLS.includes(upCode) ||
                        upCode.startsWith('^') ||
                        upCode.endsWith('=F') ||
                        upCode.endsWith('=X');

                    if (isDashboardSymbol) {
                        const url = DASHBOARD_LINKS[upCode] || LinkHelper.getFinanceUrl(upCode);
                        window.open(url, '_blank', 'noopener,noreferrer');
                    } else {
                        // Fallback: Open Discovery Modal if no local data
                        document.dispatchEvent(new CustomEvent(EVENTS.OPEN_RESEARCH_MODAL, { detail: { query: code } }));
                    }
                }
            }, 0);
        });

        // 5. Summary Detail Modals
        document.addEventListener(EVENTS.REQUEST_SUMMARY_DETAIL, (e) => {
            const { type } = e.detail;
            const allShares = AppState.data.shares || [];

            // Re-process data to get fresh merged stats (using currently cached prices)
            const { mergedData, summaryMetrics } = processShares(
                allShares,
                PORTFOLIO_ID,
                AppState.livePrices,
                { field: 'code', direction: 'asc' }, // Temporary baseline for filtering
                AppState.hiddenAssets
            );

            // Filter out hidden shares for summary details
            const shares = mergedData.filter(s => !s.isHidden);

            let title = '';
            let filteredShares = [];
            let valueField = '';
            let trendClass = '';

            // Sum calculation logic moved inside switch to ensure filteredShares or shares is valid.

            switch (type) {
                case SUMMARY_TYPES.VALUE:
                    title = 'Current Value';
                    filteredShares = [...shares].sort((a, b) => (b.value || 0) - (a.value || 0));
                    valueField = 'value';
                    trendClass = CSS_CLASSES.TREND_NEUTRAL_BG; // Value is neutral
                    break;
                case SUMMARY_TYPES.DAY_CHANGE:
                    title = 'Day Change';
                    const isChangeNegative = (summaryMetrics?.dayChangeValue || 0) < 0;
                    filteredShares = [...shares].sort((a, b) => {
                        const valA = a.dayChangeValue || 0;
                        const valB = b.dayChangeValue || 0;
                        return isChangeNegative ? (valA - valB) : (valB - valA);
                    });
                    valueField = 'dayChangeValue';
                    // Calculate GAINS vs LOSSES to determine mixed gradient (Match Market Pulse style)
                    const dayGains = shares.reduce((acc, s) => {
                        const val = s.dayChangeValue || 0;
                        return val > 0 ? acc + val : acc;
                    }, 0);
                    const dayLosses = Math.abs(shares.reduce((acc, s) => {
                        const val = s.dayChangeValue || 0;
                        return val < 0 ? acc + val : acc;
                    }, 0));
                    // Gains dominant = Green Top-Left, Losses dominant = Red Top-Left
                    trendClass = dayGains >= dayLosses ? CSS_CLASSES.TREND_MIXED_DESC_BG : CSS_CLASSES.TREND_MIXED_ASC_BG;
                    break;
                case SUMMARY_TYPES.WINNERS:
                    title = 'Day Change Winners';
                    filteredShares = shares.filter(s => (s.dayChangeValue || 0) > 0)
                        .sort((a, b) => (b.dayChangeValue || 0) - (a.dayChangeValue || 0));
                    valueField = 'dayChangeValue';
                    trendClass = CSS_CLASSES.TREND_UP_BG;
                    break;
                case SUMMARY_TYPES.LOSERS:
                    title = 'Day Change Losers';
                    // Worst negative to least worse negative: means ASC (e.g. -100, -50, -10)
                    filteredShares = shares.filter(s => (s.dayChangeValue || 0) < 0)
                        .sort((a, b) => (a.dayChangeValue || 0) - (b.dayChangeValue || 0));
                    valueField = 'dayChangeValue';
                    trendClass = CSS_CLASSES.TREND_DOWN_BG;
                    break;
                case SUMMARY_TYPES.CAPITAL_GAIN:
                    title = 'Capital Gain';
                    filteredShares = [...shares].sort((a, b) => (b.capitalGain || 0) - (a.capitalGain || 0));
                    valueField = 'capitalGain';
                    const totalCapGain = shares.reduce((acc, s) => acc + (s.capitalGain || 0), 0);
                    trendClass = totalCapGain >= 0 ? CSS_CLASSES.TREND_UP_BG : CSS_CLASSES.TREND_DOWN_BG;
                    break;
                default:
                    return;
            }
            // Delay eliminated for snappiness
            setTimeout(() => {
                this.viewRenderer.renderSummaryDetailModal(title, filteredShares, valueField, trendClass);
            }, 0);
        });

        // -------------------------------------------------------------------------
        // DATA MANAGEMENT HANDLERS (Download/Delete)
        // -------------------------------------------------------------------------

        // 1. DATA MANAGEMENT EVENT LISTENERS (Business Logic)
        document.addEventListener(EVENTS.REQUEST_DOWNLOAD_DATA || 'request-download-data', () => {
            this._openDownloadModal();
        });

        document.addEventListener(EVENTS.REQUEST_DELETE_DATA || 'request-delete-data', () => {
            this.handleDeleteData();
        });

        // 2. GLOBAL CLICK HANDLER (Interaction Layer)
        document.addEventListener('click', (e) => {
            const target = e.target;
            if (!target) return;


            // Sidebar: Download Data
            const downloadBtn = target.closest(`#${IDS.DOWNLOAD_DATA_BTN || 'btn-download-data'}`);
            if (downloadBtn) {
                if (this.headerLayout && typeof this.headerLayout.closeSidebar === 'function') {
                    this.headerLayout.closeSidebar();
                }
                setTimeout(() => this._openDownloadModal(), 150);
                return;
            }

            // Sidebar: Delete Data
            const deleteBtn = target.closest(`#${IDS.DELETE_DATA_BTN || 'btn-delete-data'}`);
            if (deleteBtn) {
                if (this.headerLayout && typeof this.headerLayout.closeSidebar === 'function') {
                    this.headerLayout.closeSidebar();
                }
                setTimeout(() => {
                    const evt = EVENTS.REQUEST_DELETE_DATA || 'request-delete-data';
                    document.dispatchEvent(new CustomEvent(evt));
                }, 150);
                return;
            }

            // Modal: Download CSV
            if (target.closest(`#${IDS.DOWNLOAD_CSV_BTN}`)) {
                this._closeDownloadModal();
                setTimeout(() => {
                    this.exportData('csv');
                    document.dispatchEvent(new CustomEvent(EVENTS.REQUEST_DOWNLOAD_DATA, { detail: { action: 'close' } }));
                }, 100);
                return;
            }

            // Modal: Download PDF
            if (target.closest(`#${IDS.DOWNLOAD_PDF_BTN}`)) {
                this._closeDownloadModal();
                setTimeout(() => this.exportData('pdf'), 100);
                return;
            }

            // Modal: Close / Overlay
            const modalId = IDS.DOWNLOAD_DATA_MODAL || 'modal-download-data';
            const closeBtn = target.closest('.modal-close-btn') && target.closest(`#${modalId}`);
            const isOverlay = target.classList.contains(CSS_CLASSES.MODAL_OVERLAY) && target.closest(`#${modalId}`);

            if (closeBtn || isOverlay) {
                this._closeDownloadModal();
            }
        });
    }

    /**
     * Closes the data download modal.
     */
    _closeDownloadModal() {
        const modalId = IDS.DOWNLOAD_DATA_MODAL || 'modal-download-data';
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add(CSS_CLASSES.HIDDEN || 'hidden');
            modal.style.display = '';
            modal.style.visibility = '';
            modal.style.opacity = '';
            modal.style.pointerEvents = '';

            // Remove from history stack if closed manually
            if (this._downloadNavActive) {
                this._downloadNavActive = false;
                navManager.popStateSilently();
            }
        } else {
        }
    }

    /**
     * Opens the data download modal.
     */
    _openDownloadModal() {
        const modalId = IDS.DOWNLOAD_DATA_MODAL || 'modal-download-data';
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove(CSS_CLASSES.HIDDEN || 'hidden');
            // Force visibility to overcome any CSS issues
            modal.style.display = 'flex';
            modal.style.visibility = 'visible';
            modal.style.opacity = '1';
            modal.style.pointerEvents = 'auto';

            // Register with NavigationManager
            if (!this._downloadNavActive) {
                this._downloadNavActive = true;
                navManager.pushState(() => {
                    this._downloadNavActive = false;
                    this._closeDownloadModal();
                });
            }
        } else {
        }
    }

    /**
     * Orchestrates data export in specified format.
     * @param {string} format 
     */
    exportData(format) {
        const data = this.appService.prepareExportData();

        if (format === 'csv') {
            this._downloadCSV(data);
        } else if (format === 'pdf') {
            // PDF is handled by print layout
            window.print();
        }
    }

    /**
     * Generates and downloads a CSV file.
     */
    _downloadCSV(data) {
        let csvContent = "data:text/csv;charset=utf-8,";
        csvContent += "Type,Code/Name,Balance/Shares,Price,Value,Category/Date\n";

        // Add Shares
        data.shares.forEach(s => {
            const price = s.currentPrice || s.enteredPrice || 0;
            const value = (s.portfolioShares || 0) * price;
            const dateStr = s.purchaseDate || s.entryDate || '';
            csvContent += `Share,${s.shareName},${s.portfolioShares},${price},${value},${dateStr}\n`;
        });

        // Add Cash
        data.cash.forEach(c => {
            const audVal = convertAssetToAud(c);
            const isThb = (c.currency || '').toUpperCase() === 'THB';
            csvContent += `Cash,${c.name}${isThb ? ' (THB)' : ''},${c.balance},1,${audVal.toFixed(2)},${c.category}\n`;
        });

        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", `asx_data_export_${new Date().toISOString().split('T')[0]}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }


    /**
     * Aggregates and prepares data for the Market Snapshot.
     */
    getSnapshotData() {
        const allItems = new Map();
        const masterList = AppState.data.shares || [];

        masterList.forEach(share => {
            const code = share.code || share.shareName || share.symbol;
            if (!code) return;

            if (!allItems.has(code)) {
                let livePrice = share.currentPrice || share.price || 0;
                let dayChangePct = share.dayChangePercent || share.changePercent || 0;
                let dayChangeVal = share.dayChangePerShare || share.dayChange || share.change || 0;

                if (AppState.livePrices && AppState.livePrices.has(code)) {
                    const liveData = AppState.livePrices.get(code);
                    livePrice = liveData.live || livePrice;
                    dayChangePct = liveData.pctChange || dayChangePct;
                    dayChangeVal = liveData.change || dayChangeVal;
                }

                allItems.set(code, {
                    code: code,
                    price: parseFloat(livePrice) || 0,
                    pctChange: parseFloat(dayChangePct) || 0,
                    valChange: parseFloat(dayChangeVal) || 0,
                    high: parseFloat(share.high || (AppState.livePrices.get(code)?.high) || 0),
                    low: parseFloat(share.low || (AppState.livePrices.get(code)?.low) || 0),
                    name: share.name
                });
            }
        });

        return Array.from(allItems.values());
    }

    /**
     * Handles the hard delete flow with confirmation.
     */
    async handleDeleteData() {
        if (confirm(USER_MESSAGES.CONFIRM_DELETE_ALL)) {
            // Second confirmation for such a destructive action
            if (confirm("FINAL WARNING: All your data will be permanently wiped. Proceed?")) {

                // 1. Immediate UI Feedback (Delegated to ViewRenderer)
                this.viewRenderer.showLoadingOverlay("Resetting Application...", "Please wait while we scrub your data.");

                try {
                    // document.body.classList.add('loading'); // Removed (No CSS support)
                    await this.appService.wipeUserData();

                    // Clear local storage
                    localStorage.clear();

                    // Wait for Auth to settle as NULL before reloading
                    return new Promise(resolve => {
                        const unsub = AuthService.observeState(async (u) => {
                            if (!u) {
                                unsub();
                                // Small delay for storage persistence
                                setTimeout(() => window.location.reload(), 500);
                                resolve();
                            }
                        });
                        // Fallback if observer doesn't fire
                        setTimeout(() => window.location.reload(), 2000);
                        AuthService.signOut();
                    });
                } catch (err) {
                    console.error("Wipe failed:", err);
                    this.viewRenderer.hideLoadingOverlay(); // Delegate cleanup
                    ToastManager.error("Failed to wipe data: " + err.message);
                }
            }
        }
    }

    /**
     * Handles opening the security settings modal.
     */
    handleSecuritySettings() {
        if (this.headerLayout) {
            this.headerLayout.closeSidebar();
        }
        // Standard 150ms delay for history stabilization
        setTimeout(() => {
            SecurityUI.renderSecuritySettings(this.securityController);
        }, 150);
    }

    /**
     * Records a portfolio snapshot if none has been taken recently.
     * Protected by the Ingestion Gatekeeper to prevent out-of-hours or corrupted data from polluting history.
     */
    async _checkSnapshotNecessity() {
        if (!AppState.user || !AppState.user.uid) return;

        // Record snapshot if it's a new day or > 4 hours since last usage record.
        const lastSnap = localStorage.getItem(STORAGE_KEYS.LAST_SNAPSHOT_TIME);
        const now = Date.now();
        const fourHours = 4 * 60 * 60 * 1000;

        if (!lastSnap || (now - parseInt(lastSnap)) > fourHours) {
            // INGESTION GATEKEEPER PRE-COMMIT VALIDATION
            const validation = ChartDataSanitizer.validateSnapshotProposal({
                shares: AppState.data.shares || [],
                cash: AppState.data.cash || [],
                livePrices: AppState.livePrices,
                lastCleanValue: AppState.lastCleanPortfolioValue,
                isMarketOpen: MarketSchedule.isASXTrading(),
                pendingDownshift: AppState.pendingDownshiftReading
            });

            if (!validation.isValid) {
                if (validation.requireConfirmation && validation.pendingReading) {
                    AppState.pendingDownshiftReading = validation.pendingReading;
                    console.warn(`[AppController] Snapshot quarantined: ${validation.reason}`);
                } else {
                    console.warn(`[AppController] Snapshot rejected by Ingestion Gatekeeper: ${validation.reason}`);
                }
                return;
            }

            // Snapshot validated: clear pending reading & maintain clean baseline
            AppState.pendingDownshiftReading = null;
            if (validation.proposedTotal > 0) {
                AppState.setLastCleanPortfolioValue(validation.proposedTotal);
            }

            console.log('[AppController] Ingestion gatekeeper validated. Syncing background portfolio snapshot...');
            try {
                // Triggering async without awaiting to avoid UI blocking
                this.dataService.recordSnapshot().then(res => {
                    if (res && res.ok) {
                        localStorage.setItem(STORAGE_KEYS.LAST_SNAPSHOT_TIME, now.toString());
                        console.log('[AppController] Snapshot recorded successfully.');
                    }
                });
            } catch (e) {
                console.warn('[AppController] Snapshot trigger failed (passive):', e);
            }
        }
    }

    /**
     * Parses the current URL for deep links and triggers the corresponding UI state.
     * v1153: Added support for ?announcementId= to deep-link straight to an announcement.
     */
    _handleDeepLinks() {
        try {
            const params = new URLSearchParams(window.location.search);
            // v1153: Support multiple parameter names used by different email systems / versions
            let targetId = params.get('announcementId') || params.get('alertId') || params.get('id') || params.get('targetId');

            // v1155: Regex Fallback - If no explicit param, scan the full URL for the standard ASX/MarketIndex ID pattern
            // Updated to be more resilient (removed strict word boundaries that might fail in some URL structures)
            if (!targetId) {
                const hrefMatch = window.location.href.match(/[0-9]{0,1}[23456]A[A-Z0-9]{5,}/i);
                if (hrefMatch) {
                    targetId = hrefMatch[0].toUpperCase();
                    console.log(`[AppController] Detected announcement ID via URL pattern: ${targetId}`);
                }
            }

            // v1156: SECONDARY REGEX - If no targetId, check for a generic company profile URL (/asx/CODE)
            let targetSymbol = null;
            if (!targetId) {
                const codeMatch = window.location.href.match(/marketindex\.com\.au\/asx\/([a-z0-9]{3,4})\b/i);
                if (codeMatch) {
                    targetSymbol = codeMatch[1].toUpperCase();
                    console.log(`[AppController] Detected stock code via URL pattern: ${targetSymbol}`);
                }
            }

            if (targetId || targetSymbol) {
                console.log(`[AppController] Deep link detected: targetId=${targetId}, symbol=${targetSymbol}`);

                // Wait for data to be ready before triggering modal
                const triggerDeepLink = async () => {
                    const originalHref = window.location.href;
                    const success = await marketIndexController.openModal(targetId, targetSymbol);

                    if (!success && targetId && originalHref.includes('marketindex.com.au')) {
                        console.warn('[AppController] Deep link targeting failed. Performing auto-redirect fallback to original URL.');
                        // Fallback: If we couldn't find the target in our app to highlight it,
                        // let the user see it on the official website so they aren't "stuck" on our dashboard.
                        window.location.href = originalHref;
                        return;
                    }

                    // Clean up URL to avoid re-triggering on manual refresh
                    const url = new URL(window.location);
                    // Remove all possible trigger params for cleanliness
                    ['announcementId', 'alertId', 'id', 'targetId'].forEach(p => url.searchParams.delete(p));
                    // Update state without refreshing
                    window.history.replaceState({}, '', url);
                };

                // If store is already ready, trigger now, else wait for event
                if (this.notificationStore?.isReady) {
                    triggerDeepLink();
                } else {
                    document.addEventListener(EVENTS.NOTIFICATION_READY, () => {
                        triggerDeepLink();
                    }, { once: true });
                }
            }
        } catch (e) {
            console.error('[AppController] Deep link handling failed:', e);
        }
    }
}

