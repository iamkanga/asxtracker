import { formatCurrency } from '../utils/formatters.js';
import { UI_ICONS, CSS_CLASSES, IDS, KANGAROO_ICON_SRC } from '../utils/AppConstants.js';
import { AppState } from '../state/AppState.js';
import { navManager } from '../utils/NavigationManager.js';
import { ensureChartMilestoneFormatting } from '../utils/ChartDataSanitizer.js';

/**
 * Reusable Chart Component
 * Can be rendered in a Modal or inline.
 */
export class ChartComponent {
    constructor(container, code, name) {
        this.container = container;
        this.code = code;
        this.name = name;
        this.chart = null;
        this.series = null;
        this.lastPriceLine = null; // Track price line to prevent duplicates
        this.currentRange = '1y'; // Default
        this.currentStyle = localStorage.getItem('asx_chart_style') || 'candle'; // Persist choice
        this.cachedData = null; // Store data to allow instant style switching
        this.resizeObserver = null;
        this.rangeBadges = null;
        this.lastRangeData = null;

        this.init();
    }

    init() {
        // 1. Inject Styles if not present
        if (!document.getElementById('chart-component-styles')) {
            const style = document.createElement('style');
            style.id = 'chart-component-styles';
            style.textContent = `
                .${CSS_CLASSES.CHART_WRAPPER} {
                    display: flex;
                    flex-direction: column;
                    width: 100%;
                    height: 100%;
                    background: var(--card-bg);
                    position: relative;
                }
                .${CSS_CLASSES.CHART_CANVAS_CONTAINER} {
                    flex: 1;
                    width: 100%;
                    min-height: 250px; /* Ensure visibility inline */
                    position: relative;
                    background: #111;
                    box-sizing: border-box;
                    margin: 0;
                    padding: 0;
                    overflow: hidden;
                    touch-action: pan-y; /* Allow vertical scroll gesture to bubble up to page */
                }
                .${CSS_CLASSES.CHART_CONTROLS} {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 4px;
                    padding: 6px 8px;
                    background: var(--card-bg);
                    border-top: 1px solid var(--border-color);
                    justify-content: space-between;
                    align-items: center;
                }
                /* Controls Layout */
                .chart-selector-container { order: 1; }
                .chart-timeframe-row { order: 2; }
                .chart-zoom-container { order: 3; }

                /* Timeframe row - always centered */
                .chart-timeframe-row {
                    display: flex;
                    gap: 2px;
                    justify-content: center;
                    align-items: center;
                    flex-wrap: wrap;
                }
                
                /* Landscape: single line with extreme ends */
                @media (orientation: landscape) {
                    .chart-selector-container { min-width: 100px; }
                    .chart-zoom-container { min-width: 40px; text-align: right; }
                    .chart-controls-separator-portrait { display: none; }
                }

                /* Portrait: two row layout */
                @media (orientation: portrait) {
                    .chart-timeframe-row {
                        width: 100% !important;
                        flex-wrap: nowrap !important;
                        justify-content: space-between !important;
                        gap: 0 !important;
                        order: 1 !important; /* Force to top */
                        margin-bottom: 8px;
                    }
                    .chart-selector-container {
                        order: 2 !important;
                        flex: 1;
                        text-align: left;
                    }
                    .chart-zoom-container {
                        order: 3 !important;
                        flex: 1;
                        text-align: right;
                    }
                    .chart-timeframe-row .${CSS_CLASSES.CHART_BTN} {
                        padding: 4px 4px !important;
                        font-size: 0.72rem !important;
                        flex: 1;
                        text-align: center;
                    }
                }
                .${CSS_CLASSES.CHART_BTN} {
                    background: transparent;
                    border: none;
                    color: #ffffff;
                    padding: 4px 6px;
                    border-radius: 4px;
                    font-size: 0.8rem;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                .${CSS_CLASSES.CHART_BTN}:hover {
                    color: var(--text-color);
                }
                .${CSS_CLASSES.CHART_BTN}.active {
                    background: transparent;
                    color: var(--color-accent);
                    font-weight: 800;
                }
                /* Style Dropdown */
                .${CSS_CLASSES.CHART_SELECT} {
                    background: transparent;
                    border: none;
                    color: var(--color-accent);
                    padding: 4px 2px; 
                    font-size: 0.8rem;
                    font-weight: 600;
                    cursor: pointer;
                    outline: none;
                    text-align: center;
                }
                .${CSS_CLASSES.CHART_SELECT}:hover, .${CSS_CLASSES.CHART_SELECT}:focus {
                    color: var(--color-accent);
                }
                /* Period Stats (High/Low) */
                .chart-period-stats {
                    font-size: 0.75rem;
                    color: var(--text-muted);
                    margin-right: auto;
                    white-space: nowrap;
                    opacity: 0.9;
                }
                /* Period Stats Overlay (inside chart) */
                .chart-period-overlay {
                    position: absolute;
                    top: 8px;
                    left: 8px;
                    font-size: 0.75rem;
                    background: rgba(17, 17, 17, 0.85);
                    padding: 8px 12px;
                    border-radius: 6px;
                    z-index: 5;
                    pointer-events: none;
                    white-space: nowrap;
                    border: 1px solid rgba(255,255,255,0.05);
                    box-shadow: 0 4px 12px rgba(0,0,0,0.5);
                }

                .${CSS_CLASSES.CHART_OVERLAY_LOADER} {
                    position: absolute;
                    top: 0; left: 0;
                    width: 100%; height: 100%;
                    background: rgba(0,0,0,0.5);
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    z-index: 10;
                    color: white;
                    display: none;
                }
                .${CSS_CLASSES.CHART_RANGE_BADGE} {
                    position: absolute;
                    left: 8px;
                    z-index: 6;
                    pointer-events: none;
                    user-select: none;
                    font-size: 0.68rem;
                    font-weight: 800;
                    padding: 2px 6px;
                    border-radius: 3px;
                    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.5);
                    line-height: 1.2;
                    white-space: nowrap;
                    display: none;
                }
                .${CSS_CLASSES.CHART_RANGE_BADGE_HIGH} {
                    background: #00E676;
                    color: #000000;
                }
                .${CSS_CLASSES.CHART_RANGE_BADGE_LOW} {
                    background: #FF5252;
                    color: #ffffff;
                }
                /* Fullscreen Zoom Mode - uses inset anchoring, no viewport units */
                .chart-fullscreen {
                    position: fixed !important;
                    inset: 0 !important;
                    width: 100% !important;
                    height: 100% !important;
                    z-index: 9999 !important;
                    background: var(--card-bg) !important;
                    border-radius: 0 !important;
                    margin: 0 !important;
                    max-width: none !important;
                    max-height: none !important;
                    overflow: hidden !important;
                }
                /* Parent modal adjustments when content is fullscreen */
                .chart-modal-fullscreen {
                    align-items: stretch !important;
                    justify-content: stretch !important;
                }
                /* Orientation specific header adjustments */
                @media (orientation: landscape) {
                    .chart-modal-header {
                        padding: 4px 16px !important;
                    }
                }
            `;
            document.head.appendChild(style);
        }

        // 2. Build DOM
        this.container.innerHTML = `
            <div class="${CSS_CLASSES.CHART_WRAPPER}">
                <div class="${CSS_CLASSES.CHART_CANVAS_CONTAINER}" id="chartCanvas_${this.code}">
                    <div class="${CSS_CLASSES.CHART_OVERLAY_LOADER}">
                        <i class="fas fa-spinner fa-spin fa-2x"></i>
                    </div>
                    <div class="chart-period-overlay" id="chartPeriodStats_${this.code}" style="display: flex; flex-direction: column; gap: 6px;">
                        <div class="chart-range-row" style="display: flex; gap: 6px;">
                            <span class="chart-period-low" style="background: rgba(255, 49, 49, 0.15); color: #ffffff; padding: 2px 8px; border-radius: 4px; font-weight: 800; font-size: 0.7rem; border: 1px solid rgba(255, 49, 49, 0.2);">L: --</span>
                            <span class="chart-period-high" style="background: rgba(6, 255, 79, 0.15); color: #ffffff; padding: 2px 8px; border-radius: 4px; font-weight: 800; font-size: 0.7rem; border: 1px solid rgba(6, 255, 79, 0.2);">H: --</span>
                        </div>
                        <span class="chart-period-change" style="color:#a49393; font-weight:900; font-size: 0.9rem; margin-left: 2px;">--</span>
                    </div>
                </div>
                <div class="${CSS_CLASSES.CHART_CONTROLS}">
                    <div class="chart-selector-container">
                        <select class="${CSS_CLASSES.CHART_SELECT}" id="${IDS.CHART_STYLE_SELECT}" title="Chart Style">
                            <option value="candle">Candles</option>
                            <option value="bar">Bars</option>
                            <option value="line">Line</option>
                            <option value="area">Area</option>
                        </select>
                    </div>
                    <div class="chart-timeframe-row">
                        ${this._renderRangeButtons()}
                    </div>
                    <div class="chart-zoom-container">
                        <button id="${IDS.CHART_ROTATOR}" class="${CSS_CLASSES.CHART_BTN}" title="Fullscreen"><i class="fas fa-expand"></i></button>
                    </div>
                </div>
            </div>
        `;

        // 3. Init Library
        this.initChart();

        // 4. Bind Events
        // Range Buttons
        this.container.querySelectorAll('[data-range]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const range = e.target.closest('[data-range]')?.dataset.range || e.target.dataset.range;
                if (range) this.setRange(range);
            });
        });

        // Style Selector
        const select = this.container.querySelector(`#${IDS.CHART_STYLE_SELECT}`);
        select.value = this.currentStyle; // Set initial value
        select.addEventListener('change', (e) => this.setStyle(e.target.value));

        // 5. Initial Load
        this.load(this.currentRange);
    }

    _renderRangeButtons() {
        // Updated Ranges: 1D, 5D, 1M, ..., 10Y, Max
        const ranges = ['1d', '5d', '1m', '3m', '6m', '1y', '3y', '5y', '10y', 'max'];
        return ranges.map(r =>
            `<button class="${CSS_CLASSES.CHART_BTN} ${this.currentRange === r ? 'active' : ''}" data-range="${r}">${r.toUpperCase()}</button>`
        ).join('');
    }

    initChart() {
        const div = this.container.querySelector(`.${CSS_CLASSES.CHART_CANVAS_CONTAINER}`);
        if (typeof LightweightCharts === 'undefined') {
            div.innerHTML = '<div style="color:red; padding:20px;">Chart library not loaded</div>';
            return;
        }

        ensureChartMilestoneFormatting();

        this.chart = LightweightCharts.createChart(div, {
            layout: {
                background: { type: 'solid', color: '#111' },
                textColor: '#ffffff',
            },
            grid: { vertLines: { color: '#333' }, horzLines: { color: '#333' } },
            width: div.clientWidth,
            height: div.clientHeight,
            handleScroll: {
                vertTouchDrag: false, // Allow page scroll on mobile touch-drag
            },
            timeScale: {
                timeVisible: true,
                secondsVisible: false,
                borderColor: '#333',
                rightOffset: 0,
                fixLeftEdge: true,
                fixRightEdge: true,
                minBarSpacing: 0.001,
            },
            rightPriceScale: {
                borderColor: '#333',
                scaleMargins: {
                    top: 0.1,
                    bottom: 0.18, // 18% bottom cushion prevents clipping of LOW line and troughs
                },
            },
            crosshair: {
                vertLine: {
                    color: '#a49393', // Accent Line
                    width: 1,
                    style: 2, // Dotted
                    labelBackgroundColor: '#a49393', // Solid Coffee for Date
                    labelVisible: true,
                },
                horzLine: {
                    color: '#a49393',
                    width: 1,
                    style: 2, // Dotted
                    labelVisible: false, // Prevent crosshair overlay from duplicating scrubPriceLine
                },
            },
        });

        // Initial Series Creation
        this._createSeries(this.currentStyle);

        // Re-align mirrored badges whenever visible range scales or pans
        this.chart.timeScale().subscribeVisibleLogicalRangeChange(() => {
            this._updateRangeBadges();
        });

        // Resize Observer
        this.resizeObserver = new ResizeObserver(entries => {
            if (!entries[0] || !entries[0].contentRect) return;
            const { width, height } = entries[0].contentRect;
            if (this.chart && width > 0 && height > 0) {
                const isPortrait = height > width || window.innerHeight > window.innerWidth;
                const bottomMargin = isPortrait ? 0.20 : 0.16;
                this.chart.applyOptions({
                    width,
                    height,
                    rightPriceScale: {
                        scaleMargins: { top: 0.1, bottom: bottomMargin }
                    }
                });
                this.chart.timeScale().fitContent();
                requestAnimationFrame(() => {
                    if (this.chart) this.chart.timeScale().fitContent();
                    this._updateRangeBadges();
                });
            }
        });
        this.resizeObserver.observe(div);

        // Orientation change listener for mobile
        this._orientationHandler = () => {
            setTimeout(() => {
                if (this.chart && div) {
                    const width = div.clientWidth;
                    const height = div.clientHeight;
                    if (width > 0 && height > 0) {
                        const isPortrait = height > width || window.innerHeight > window.innerWidth;
                        const bottomMargin = isPortrait ? 0.20 : 0.16;
                        this.chart.applyOptions({
                            width,
                            height,
                            rightPriceScale: {
                                scaleMargins: { top: 0.1, bottom: bottomMargin }
                            }
                        });
                        this.chart.timeScale().fitContent();
                        requestAnimationFrame(() => {
                            if (this.chart) this.chart.timeScale().fitContent();
                            this._updateRangeBadges();
                        });
                    }
                }
            }, 200);
        };
        window.addEventListener('orientationchange', this._orientationHandler);

        // Dynamic "Scrub" Highlight Line
        this.chart.subscribeCrosshairMove(param => {
            if (!this.chart || !this.series) return;

            if (!param.time || !param.point || param.point.x < 0) {
                if (this.scrubPriceLine) this.scrubPriceLine.applyOptions({ visible: false });
                return;
            }

            const data = param.seriesData.get(this.series);
            if (data && (data.value !== undefined || data.close !== undefined)) {
                const price = data.value !== undefined ? data.value : data.close;
                const isAtLastPrice = (this.lastPriceLine && Math.abs(price - this.lastPriceLine.options().price) < 0.001);
                
                if (!this.scrubPriceLine) {
                    this.scrubPriceLine = this.series.createPriceLine({
                        price: price,
                        color: 'rgba(6, 255, 79, 0.4)',
                        lineWidth: 1,
                        lineStyle: 0,
                        axisLabelVisible: !isAtLastPrice,
                        title: '',
                        axisLabelColor: '#00E676',
                        axisLabelTextColor: '#000000',
                    });
                } else {
                    this.scrubPriceLine.applyOptions({
                        price: price,
                        visible: true,
                        axisLabelVisible: !isAtLastPrice
                    });
                }
            } else {
                if (this.scrubPriceLine) this.scrubPriceLine.applyOptions({ visible: false });
            }
        });
    }

    /**
     * Creates the specific series type and applies internal reference.
     * @param {string} type 'candle' | 'bar' | 'line' | 'area'
     */
    _createSeries(type) {
        if (!this.chart) return;

        // Remove old if exists
        if (this.series) {
            this.chart.removeSeries(this.series);
            this.lastPriceLine = null;
            this.scrubPriceLine = null;
        }

        // Theme Colors
        const UP_COLOR = '#06FF4F';
        const DOWN_COLOR = '#FF3131';
        const ACCENT_COLOR = '#a49393'; // Coffee

        // Initial / Default Colors for Area/Line (Coffee)
        // These will be overridden by _updateSeriesColor based on data direction
        const DEFAULT_LINE_COLOR = ACCENT_COLOR;
        const DEFAULT_TOP_COLOR = 'rgba(164, 147, 147, 0.4)';
        const DEFAULT_BOTTOM_COLOR = 'rgba(164, 147, 147, 0)';

        switch (type) {
            case 'bar':
                this.series = this.chart.addBarSeries({
                    upColor: UP_COLOR, downColor: DOWN_COLOR,
                    lastValueVisible: false, // Custom PriceLine used instead
                    priceLineVisible: false,
                });
                break;
            case 'line':
            case 'area':
                // User Request: "Line" should now be a filled area with gradient
                // We use AreaSeries for both 'line' and 'area' to support the gradient fill.
                this.series = this.chart.addAreaSeries({
                    topColor: DEFAULT_TOP_COLOR,
                    bottomColor: DEFAULT_BOTTOM_COLOR,
                    lineColor: DEFAULT_LINE_COLOR,
                    lineWidth: 2,
                    lastValueVisible: false,
                    priceLineVisible: false,
                });
                break;
            case 'candle':
            default:
                this.series = this.chart.addCandlestickSeries({
                    upColor: UP_COLOR, downColor: DOWN_COLOR,
                    borderVisible: false, wickUpColor: UP_COLOR, wickDownColor: DOWN_COLOR,
                    lastValueVisible: false,
                    priceLineVisible: false,
                });
                break;
        }
    }

    _updateLastPriceLine(data) {
        if (!this.series || !data || data.length === 0) return;

        // Find last item
        const last = data[data.length - 1];
        const price = (last.close !== undefined) ? last.close : (last.value !== undefined ? last.value : null);

        if (price === null) return;

        // Remove old if exists to prevent duplication
        if (this.lastPriceLine) {
            this.series.removePriceLine(this.lastPriceLine);
        }

        // Create Price Line
        // We simulate transparent BG by using Chart BG color #111
        // Text Color = Accent #a49393
        this.lastPriceLine = this.series.createPriceLine({
            price: price,
            color: '#a49393', // Line color (Coffee)
            lineWidth: 1,
            lineStyle: 1, // Dotted
            axisLabelVisible: true,
            title: '',
            axisLabelColor: '#a49393', // Background (Coffee)
            axisLabelTextColor: '#ffffff', // Brightest white text for high contrast on mobile
        });
    }

    setStyle(newStyle) {
        if (this.currentStyle === newStyle) return;
        this.currentStyle = newStyle;
        localStorage.setItem('asx_chart_style', newStyle); // Persist

        // Swapping series requires re-setting data
        this._createSeries(newStyle);

        if (this.cachedData && this.series) {
            let dataToSet = this.cachedData;

            if (newStyle === 'line' || newStyle === 'area') {
                dataToSet = this.cachedData.map(d => ({
                    time: d.time,
                    value: d.close
                }));
            }

            this.series.setData(dataToSet);
            this._updateLastPriceLine(dataToSet);
            this._updatePeriodStats(this.cachedData);
            // Apply Dynamic Color for Area/Line
            if (newStyle === 'line' || newStyle === 'area') {
                this._updateSeriesColor(this.cachedData);
            }
            if (this.chart) {
                this.chart.timeScale().fitContent();
                requestAnimationFrame(() => {
                    if (this.chart) this.chart.timeScale().fitContent();
                    this._updateRangeBadges();
                });
            }
        }
    }

    async load(range) {
        this.currentRange = range;
        this._updateButtons();

        const loader = this.container.querySelector(`.${CSS_CLASSES.CHART_OVERLAY_LOADER}`);
        if (loader) loader.style.display = 'flex';

        try {
            const api = AppState.controller.dataService;
            if (!api) throw new Error('DataService not ready');

            const res = await api.fetchHistory(this.code, range);
            if (res && res.ok && res.data) {
                this.cachedData = res.data; // Store for style switching

                // Set data based on current style
                // Set data based on current style
                if (this.chart && this.series) {
                    let dataToSet = this.cachedData;
                    if (this.currentStyle === 'line' || this.currentStyle === 'area') {
                        dataToSet = this.cachedData.map(d => ({
                            time: d.time,
                            value: d.close
                        }));
                    }
                    try {
                        this.series.setData(dataToSet);
                        this._updateLastPriceLine(dataToSet);
                        this._updatePeriodStats(this.cachedData);

                        // Apply Dynamic Colors if Line/Area
                        if (this.currentStyle === 'line' || this.currentStyle === 'area') {
                            this._updateSeriesColor(this.cachedData);
                        }

                        if (this.chart) {
                            this.chart.timeScale().fitContent();
                            requestAnimationFrame(() => {
                                if (this.chart) this.chart.timeScale().fitContent();
                                this._updateRangeBadges();
                            });
                        }
                    } catch (err) {
                        console.warn('Error updating chart data:', err);
                    }
                }
            } else {
                console.warn('Chart load failed:', res);
            }
        } catch (e) {
            console.error('Chart load error:', e);
        } finally {
            if (loader) loader.style.display = 'none';
        }
    }

    async setRange(range) {
        // Just wrapper for load with timescale auto-fit
        await this.load(range);
        if (this.chart) {
            this.chart.timeScale().fitContent();
            requestAnimationFrame(() => {
                if (this.chart) this.chart.timeScale().fitContent();
                this._updateRangeBadges();
            });
        }
    }

    /**
     * Updates the Series color (for Line/Area) based on data trend (Start vs End).
     * @param {Array} data - Full OHLC data array
     */
    _updateSeriesColor(data) {
        if (!data || data.length < 2 || !this.series) return;

        // Ensure we are in a mode that supports these options
        if (this.currentStyle !== 'line' && this.currentStyle !== 'area') return;

        const first = data[0].close;
        const last = data[data.length - 1].close;
        const isPositive = last >= first;

        // Constants
        const COLOR_UP = '#06FF4F';
        const COLOR_DOWN = '#FF3131';
        const COLOR_COFFEE = '#a49393';

        // Choose base color
        const baseColor = isPositive ? COLOR_UP : COLOR_DOWN;

        // Apply visual settings
        // Gradient: 0.4 opacity at top -> 0 opacity at bottom
        const rgb = isPositive ? '6, 255, 79' : '255, 49, 49';

        this.series.applyOptions({
            lineColor: baseColor,
            topColor: `rgba(${rgb}, 0.5)`,
            bottomColor: `rgba(${rgb}, 0.0)`,
            // Optional: You could update price line color too if desired, keeping it Coffee or matching
        });
    }

    _updateButtons() {
        this.container.querySelectorAll('[data-range]').forEach(btn => {
            if (btn.dataset.range === this.currentRange) btn.classList.add(CSS_CLASSES.ACTIVE);
            else btn.classList.remove(CSS_CLASSES.ACTIVE);
        });
    }

    /**
     * Calculate and display the period high/low from loaded candle data.
     * @param {Array} data - Array of candle objects with high/low values
     */
    _updatePeriodStats(data) {
        const statsEl = this.container.querySelector(`[id="chartPeriodStats_${this.code}"]`);
        if (!statsEl) return;

        const highEl = statsEl.querySelector('.chart-period-high');
        const lowEl = statsEl.querySelector('.chart-period-low');
        const changeEl = statsEl.querySelector('.chart-period-change');

        if (!data || data.length === 0) {
            if (highEl) highEl.textContent = 'H: --';
            if (lowEl) lowEl.textContent = 'L: --';
            if (changeEl) changeEl.textContent = '--';
            this._hideRangeBadges();
            return;
        }

        let periodHigh = -Infinity;
        let periodLow = Infinity;
        let highIdx = -1;
        let lowIdx = -1;

        const isLineOrArea = this.currentStyle === 'line' || this.currentStyle === 'area';
        data.forEach((candle, i) => {
            const h = isLineOrArea
                ? (candle.close !== undefined ? candle.close : candle.value)
                : (candle.high !== undefined ? candle.high : candle.close);
            const l = isLineOrArea
                ? (candle.close !== undefined ? candle.close : candle.value)
                : (candle.low !== undefined ? candle.low : candle.close);
            if (h >= periodHigh) {
                periodHigh = h;
                highIdx = i;
            }
            if (l <= periodLow) {
                periodLow = l;
                lowIdx = i;
            }
        });

        // Update Markers on Chart
        this._updateMarkers(data, highIdx, lowIdx);

        // Percentage Change Calculation
        const first = data[0];
        const last = data[data.length - 1];
        const startPrice = first.open !== undefined ? first.open : (first.close || first.value);
        const endPrice = last.close !== undefined ? last.close : last.value;
        const changePct = startPrice !== 0 ? ((endPrice - startPrice) / startPrice) * 100 : 0;

        // Format with appropriate decimal places
        const formatPrice = (val) => {
            if (val >= 1) return '$' + val.toFixed(2);
            return '$' + val.toFixed(4);
        };

        if (highEl) highEl.textContent = 'H: ' + formatPrice(periodHigh);
        if (lowEl) lowEl.textContent = 'L: ' + formatPrice(periodLow);

        if (changeEl) {
            const sign = changePct >= 0 ? '+' : '';
            changeEl.textContent = `${sign}${changePct.toFixed(2)}%`;
            // User Request: Use coffee color instead of sentiment colors
            changeEl.style.color = '#a49393';
        }

        // Update Mirrored Left-Side Range Badges
        this._updateRangeBadges(periodHigh, periodLow, endPrice);
    }

    /**
     * Adds High/Low markers to the chart series.
     */
    _updateMarkers(data, highIdx, lowIdx) {
        if (!this.series || !data || data.length === 0) return;

        // Management of Axis Price Lines
        if (this.highPriceLine) {
            this.series.removePriceLine(this.highPriceLine);
            this.highPriceLine = null;
        }
        if (this.lowPriceLine) {
            this.series.removePriceLine(this.lowPriceLine);
            this.lowPriceLine = null;
        }

        const markers = [];
        const formatDate = (ts) => {
            const d = new Date(ts * 1000);
            return d.toLocaleDateString('en-AU', { day: 'numeric', month: 'short' });
        };

        const isLineOrArea = this.currentStyle === 'line' || this.currentStyle === 'area';

        // 1. High Marker
        if (highIdx !== -1) {
            const highVal = isLineOrArea
                ? (data[highIdx].close !== undefined ? data[highIdx].close : data[highIdx].value)
                : (data[highIdx].high !== undefined ? data[highIdx].high : data[highIdx].close);
            
            // Marker on Graph
            markers.push({
                time: data[highIdx].time,
                position: 'aboveBar',
                color: '#00E676', // Vibrant high-contrast accent green
                shape: 'arrowDown',
                text: `High: ${formatDate(data[highIdx].time)}`,
                size: 1.5
            });

            // Label on Axis
            this.highPriceLine = this.series.createPriceLine({
                price: highVal,
                color: '#00E676',
                lineWidth: 1,
                lineStyle: 2,
                axisLabelVisible: true,
                title: 'HIGH',
                axisLabelColor: '#00E676',
                axisLabelTextColor: '#000000',
            });
        }

        // 2. Low Marker
        if (lowIdx !== -1) {
            const lowVal = isLineOrArea
                ? (data[lowIdx].close !== undefined ? data[lowIdx].close : data[lowIdx].value)
                : (data[lowIdx].low !== undefined ? data[lowIdx].low : data[lowIdx].close);

            // Marker on Graph
            markers.push({
                time: data[lowIdx].time,
                position: 'belowBar',
                color: '#FF5252', // Vibrant coral red
                shape: 'arrowUp',
                text: `Low: ${formatDate(data[lowIdx].time)}`,
                size: 1.5
            });

            // Label on Axis
            this.lowPriceLine = this.series.createPriceLine({
                price: lowVal,
                color: '#FF5252',
                lineWidth: 1,
                lineStyle: 2,
                axisLabelVisible: true,
                title: 'LOW',
                axisLabelColor: '#FF5252',
                axisLabelTextColor: '#ffffff',
            });
        }

        // Sort markers by time
        markers.sort((a, b) => a.time - b.time);
        
        this.series.setMarkers(markers);
    }

    /**
     * Updates or creates mirrored High/Low relative percentage badges on the left side of the chart.
     * High Badge: +((highVal - currentVal) / currentVal * 100).toFixed(1)%
     * Low Badge: ((lowVal - currentVal) / currentVal * 100).toFixed(1)%
     * @param {number} [highVal]
     * @param {number} [lowVal]
     * @param {number} [currentVal]
     */
    _updateRangeBadges(highVal, lowVal, currentVal) {
        if (highVal !== undefined && lowVal !== undefined && currentVal !== undefined) {
            this.lastRangeData = { highVal, lowVal, currentVal };
        } else if (this.lastRangeData) {
            ({ highVal, lowVal, currentVal } = this.lastRangeData);
        }

        if (highVal == null || lowVal == null || currentVal == null || !this.series || !this.chart) {
            this._hideRangeBadges();
            return;
        }

        const canvasContainer = this.container.querySelector(`.${CSS_CLASSES.CHART_CANVAS_CONTAINER}`);
        if (!canvasContainer) return;

        // Ensure badge elements exist
        if (!this.rangeBadges) {
            const highBadge = document.createElement('div');
            highBadge.className = `${CSS_CLASSES.CHART_RANGE_BADGE} ${CSS_CLASSES.CHART_RANGE_BADGE_HIGH}`;
            canvasContainer.appendChild(highBadge);

            const lowBadge = document.createElement('div');
            lowBadge.className = `${CSS_CLASSES.CHART_RANGE_BADGE} ${CSS_CLASSES.CHART_RANGE_BADGE_LOW}`;
            canvasContainer.appendChild(lowBadge);

            this.rangeBadges = { high: highBadge, low: lowBadge };
        }

        // 1. Calculate relative percentage swings from currentVal
        const highDiff = currentVal > 0 ? (((highVal - currentVal) / currentVal) * 100) : 0;
        const lowDiff = currentVal > 0 ? (((lowVal - currentVal) / currentVal) * 100) : 0;

        const highPctStr = (highDiff > 0 ? '+' : '') + highDiff.toFixed(1) + '%';
        const lowPctVal = Math.abs(lowDiff) < 0.05 ? 0 : lowDiff;
        const lowPctStr = (lowDiff > 0 ? '+' : '') + lowPctVal.toFixed(1) + '%';

        this.rangeBadges.high.textContent = `H: ${highPctStr}`;
        this.rangeBadges.low.textContent = `L: ${lowPctStr}`;

        // 2. Convert highVal and lowVal to pixel Y-coordinates
        const highY = this.series.priceToCoordinate(highVal);
        const lowY = this.series.priceToCoordinate(lowVal);

        if (highY === null || lowY === null) {
            requestAnimationFrame(() => this._updateRangeBadges());
            return;
        }

        const containerHeight = canvasContainer.clientHeight;
        const activeBadges = [];

        if (highY >= 0 && highY <= containerHeight) {
            activeBadges.push({ el: this.rangeBadges.high, y: highY });
        } else {
            this.rangeBadges.high.style.display = 'none';
        }

        if (lowY >= 0 && lowY <= containerHeight) {
            activeBadges.push({ el: this.rangeBadges.low, y: lowY });
        } else {
            this.rangeBadges.low.style.display = 'none';
        }

        // Anti-collision with top-left period stats overlay if present
        const overlay = canvasContainer.querySelector('.chart-period-overlay');
        let overlayBottom = 0;
        let overlayRight = 0;
        if (overlay && overlay.offsetParent !== null) {
            overlayBottom = overlay.offsetTop + overlay.offsetHeight;
            overlayRight = overlay.offsetLeft + overlay.offsetWidth;
        }

        // Sort by Y and offset if overlapping or colliding
        activeBadges.sort((a, b) => a.y - b.y);

        let lastY = -999;
        let currentLeft = 8;

        activeBadges.forEach(b => {
            const hitsOverlay = (b.y - 12 < overlayBottom && b.y + 12 > 0);
            const baseLeft = hitsOverlay ? (overlayRight + 8) : 8;

            if (Math.abs(b.y - lastY) < 20) {
                currentLeft += 80;
            } else {
                currentLeft = baseLeft;
            }
            lastY = b.y;

            b.el.style.top = `${b.y}px`;
            b.el.style.left = `${currentLeft}px`;
            b.el.style.transform = 'translateY(-50%)';
            b.el.style.display = 'block';
        });
    }

    _hideRangeBadges() {
        if (!this.rangeBadges) return;
        if (this.rangeBadges.high) this.rangeBadges.high.style.display = 'none';
        if (this.rangeBadges.low) this.rangeBadges.low.style.display = 'none';
    }

    destroy() {
        if (this._orientationHandler) {
            window.removeEventListener('orientationchange', this._orientationHandler);
            this._orientationHandler = null;
        }
        if (this.resizeObserver) this.resizeObserver.disconnect();
        if (this.chart) {
            this.chart.remove();
            this.chart = null;
        }
        this._hideRangeBadges();
        this.rangeBadges = null;
        this.lastRangeData = null;
        this.container.innerHTML = '';
    }
}

/**
 * Modal Wrapper
 */
export class ChartModal {
    static async show(code, name) {
        // Remove existing
        const existing = document.getElementById(IDS.CHART_MODAL);
        if (existing) existing.remove();

        // 1. Create Modal Container
        const modal = document.createElement('div');
        modal.id = IDS.CHART_MODAL;
        // Apply 'modal' and 'hidden' for base styles and animation system
        modal.className = `${CSS_CLASSES.MODAL} ${CSS_CLASSES.HIDDEN}`;
        
        // Ensure high z-index via property (matching Constitution's dynamic elevation)
        // Set to 22000 to ensure it opens ON TOP of Stock Details (21000)
        modal.style.setProperty('z-index', '22000', 'important');

        modal.innerHTML = `
            <div class="${CSS_CLASSES.MODAL_OVERLAY}"></div>
            <div class="${CSS_CLASSES.MODAL_CONTENT} ${CSS_CLASSES.CHART_MODAL_CONTENT} modal-content-medium" style="width: 95%; height: 85%; max-width: 900px; display:flex; flex-direction:column; overflow:hidden;">
                <!-- Header -->
                <div class="${CSS_CLASSES.MODAL_HEADER}" style="display:flex; justify-content:space-between; align-items:center; padding:8px 16px; border-bottom:1px solid var(--border-color); flex-shrink:0;">
                    <div style="background: none; border: none; padding: 0; gap: 8px; display: inline-flex; align-items: center;">
                        <img src="https://files.marketindex.com.au/xasx/96x96-png/${code.toLowerCase()}.png" class="favicon-icon" style="width: 20px; height: 20px;" onerror="this.src='${KANGAROO_ICON_SRC}'" alt="">
                        <h3 class="${CSS_CLASSES.MODAL_TITLE}" style="margin:0; font-size:1.2rem; font-weight:700;">${code}</h3>
                    </div>
                    <div class="${CSS_CLASSES.MODAL_ACTIONS}" style="display:flex; gap:12px;">
                        <button id="${IDS.CHART_MODAL_CLOSE}" class="${CSS_CLASSES.MODAL_ACTION_BTN} ${CSS_CLASSES.MODAL_CLOSE_BTN}" style="border:none; font-size:1.2rem;"><i class="fas fa-times"></i></button>
                    </div>
                </div>
                <!-- Chart Component Host -->
                <div id="${IDS.MODAL_CHART_BODY}" class="${CSS_CLASSES.MODAL_BODY}" style="flex:1; position:relative; width:100%; overflow:hidden; padding: 0;"></div>
            </div>
        `;

        document.body.appendChild(modal);

        // Standard Entrance Animation
        requestAnimationFrame(() => {
            modal.classList.remove(CSS_CLASSES.HIDDEN);
            requestAnimationFrame(() => {
                modal.classList.add(CSS_CLASSES.SHOW);
            });
        });

        // 2. Instantiate Chart
        const body = modal.querySelector(`#${IDS.MODAL_CHART_BODY}`);
        const chartComp = new ChartComponent(body, code, name);

        // 3. Event Handling
        let orientationHandler = null;

        const close = () => {
            if (modal._isClosing) return;
            modal._isClosing = true;

            // Trigger Exit Animation
            modal.classList.remove(CSS_CLASSES.SHOW);
            modal.style.pointerEvents = 'none';

            // Clean up orientation listener
            if (orientationHandler) {
                window.removeEventListener('resize', orientationHandler);
                window.removeEventListener('orientationchange', orientationHandler);
                if (window.visualViewport) {
                    window.visualViewport.removeEventListener('resize', orientationHandler);
                }
            }

            // Deferred Cleanup
            setTimeout(() => {
                chartComp.destroy();
                modal.classList.add(CSS_CLASSES.HIDDEN);
                modal.remove();
            }, 450);

            // Navigation Cleanup: If closed manually, sync history stack
            if (modal._navActive) {
                modal._navActive = false;
                navManager.popStateSilently();
            }
        };
        modal.querySelector(`#${IDS.CHART_MODAL_CLOSE}`).addEventListener('click', close);

        // Fullscreen - apply immediately when modal opens
        const rotator = chartComp.container.querySelector(`#${IDS.CHART_ROTATOR}`);
        const content = modal.querySelector(`.${CSS_CLASSES.CHART_MODAL_CONTENT}`);

        let isFullscreen = true;

        // Helper to resize chart - uses container dimensions to ensure perfect fit
        const resizeChart = () => {
            if (chartComp.chart) {
                const div = chartComp.container.querySelector(`.${CSS_CLASSES.CHART_CANVAS_CONTAINER}`);
                if (div) {
                    // Use actual container dimensions instead of manual viewport calculations
                    // This ensures the chart matches the space allocated by flexbox/CSS.
                    const width = div.clientWidth;
                    const height = div.clientHeight;

                    if (width > 0 && height > 0) {
                        const isPortrait = height > width || window.innerHeight > window.innerWidth;
                        const bottomMargin = isPortrait ? 0.20 : 0.16;
                        chartComp.chart.applyOptions({
                            width,
                            height,
                            rightPriceScale: {
                                scaleMargins: { top: 0.1, bottom: bottomMargin }
                            }
                        });
                        chartComp.chart.timeScale().fitContent();
                        requestAnimationFrame(() => {
                            if (chartComp.chart) chartComp.chart.timeScale().fitContent();
                        });
                    }
                }
            }
        };

        // Apply normal/centered modal styles
        const applyNormal = () => {
            modal.style.cssText = 'z-index: 22000 !important;';
            content.style.cssText = 'width: 95%; height: 85%; max-width: 900px; display:flex; flex-direction:column; overflow:hidden;';
            if (rotator) {
                rotator.title = 'Fullscreen';
                const icon = rotator.querySelector('i');
                if (icon) icon.setAttribute('class', 'fas fa-expand');
            }
        };

        // Apply fullscreen styles with strict overrides to prevent theme-based cropping
        const applyFullscreen = () => {
            // Fullscreen the modal backdrop using inset: 0
            modal.style.cssText = `
                position: fixed !important;
                inset: 0 !important;
                width: 100% !important;
                height: 100% !important;
                background: var(--card-bg) !important;
                z-index: 50000 !important;
                display: flex !important;
                flex-direction: column !important;
                margin: 0 !important;
                padding: 0 !important;
                overflow: hidden !important;
            `;

            // Fullscreen the content using inset: 0 and !important to beat .modal-content mobile overrides
            content.style.cssText = `
                position: absolute !important;
                inset: 0 !important;
                width: 100% !important;
                height: 100% !important;
                max-width: none !important;
                max-height: none !important;
                display: flex !important;
                flex-direction: column !important;
                background: var(--card-bg) !important;
                border-radius: 0 !important;
                margin: 0 !important;
                padding: 0 !important;
                gap: 0 !important;
                overflow: hidden !important;
            `;
            if (rotator) {
                rotator.title = 'Exit Fullscreen';
                const icon = rotator.querySelector('i');
                if (icon) icon.setAttribute('class', 'fas fa-compress');
            }
        };

        // Apply fullscreen immediately when modal opens
        applyFullscreen();

        // Resize chart with multiple delays to wait for layout to settle
        requestAnimationFrame(() => {
            resizeChart();
            setTimeout(resizeChart, 50);
            setTimeout(resizeChart, 150);
            setTimeout(resizeChart, 300);
            setTimeout(resizeChart, 500);
        });

        // Orientation change handler - always resize on any event
        orientationHandler = () => {
            if (isFullscreen) {
                applyFullscreen();
            } else {
                applyNormal();
            }
            resizeChart();
            setTimeout(() => { 
                if (isFullscreen) applyFullscreen(); else applyNormal();
                resizeChart(); 
            }, 100);
            setTimeout(() => { 
                if (isFullscreen) applyFullscreen(); else applyNormal();
                resizeChart(); 
            }, 300);
            setTimeout(() => { 
                if (isFullscreen) applyFullscreen(); else applyNormal();
                resizeChart(); 
            }, 500);
        };

        window.addEventListener('resize', orientationHandler);
        window.addEventListener('orientationchange', orientationHandler);
        if (window.visualViewport) {
            window.visualViewport.addEventListener('resize', orientationHandler);
        }

        // Toggle fullscreen state when the rotator button is clicked
        if (rotator) {
            rotator.addEventListener('click', () => {
                isFullscreen = !isFullscreen;
                if (isFullscreen) {
                    applyFullscreen();
                } else {
                    applyNormal();
                }
                resizeChart();
                setTimeout(resizeChart, 50);
                setTimeout(resizeChart, 150);
            });
        }

        // --- Navigation Support ---
        // Register state so back button dismisses the chart
        modal._navActive = true;
        navManager.pushState(() => {
            if (document.contains(modal)) {
                modal._navActive = false;
                close();
            }
        });
    }
}

/**
 * Mini Chart Preview Component
 * Simplified, non-interactive 52-week line chart for the viewing modal.
 * Uses day sentiment colors (green/red) and opens full ChartModal on click.
 */
export class MiniChartPreview {
    constructor(container, code, name, dayChange = 0, onExpand = null, showScale = true, customColor = null) {
        this.container = container;
        this.code = code;
        this.name = name;
        this.dayChange = dayChange; // Used to determine line color
        this.onExpand = onExpand; // Callback when chart is clicked
        this.showScale = showScale; // Control price scale visibility
        this.customColor = customColor; // Override sentiment color
        this.chart = null;
        this.series = null;
        this.resizeObserver = null;

        this.init();
    }

    // ... (init method remains same)

    init() {
        // ... (styles injection remains same)
        // Inject mini chart specific styles if not present
        if (!document.getElementById('mini-chart-preview-styles')) {
            const style = document.createElement('style');
            style.id = 'mini-chart-preview-styles';
            style.textContent = `
                .mini-chart-container {
                    width: 100%;
                    height: 120px;
                    position: relative;
                    background: transparent;
                    border: 1px solid var(--color-accent);
                    border-radius: 0;
                    overflow: hidden;
                    touch-action: pan-y; /* Allow page scroll */
                    cursor: pointer;
                    transition: opacity 0.2s;
                }
                .mini-chart-container:hover {
                    opacity: 0.85;
                }
                .mini-chart-container:active {
                    opacity: 0.75;
                }
                .mini-chart-stats {
                    position: absolute;
                    top: 6px;
                    left: 8px;
                    font-size: 0.7rem;
                    background: transparent;
                    padding: 0;
                    z-index: 5;
                    pointer-events: none;
                    display: flex;
                    gap: 10px;
                }
                .mini-chart-container canvas,
                .mini-chart-container table {
                    pointer-events: none !important;
                }
                .mini-chart-loader {
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    color: var(--text-muted);
                }
            `;
            document.head.appendChild(style);
        }

        // Build DOM
        this.container.innerHTML = `
            <div class="mini-chart-container" title="Tap to expand chart">
                <div class="mini-chart-stats">
                    <span class="mini-chart-low" style="color:#ffffff;">L: --</span>
                    <span class="mini-chart-high" style="color:#ffffff;">H: --</span>
                </div>
                <div class="mini-chart-loader"><i class="fas ${UI_ICONS.SPINNER} fa-spin"></i></div>
            </div>
        `;

        // Initialize chart
        this.initChart();

        // Bind click handler to container
        const chartContainer = this.container.querySelector('.mini-chart-container');
        if (chartContainer && this.onExpand) {
            chartContainer.addEventListener('click', (e) => {
                e.stopPropagation();
                this.onExpand();
            });
        }

        // Load 1-year data
        this.load();
    }

    initChart() {
        const div = this.container.querySelector('.mini-chart-container');
        if (typeof LightweightCharts === 'undefined') {
            div.innerHTML = '<div style="color:var(--text-muted); padding:20px; text-align:center; font-size:0.8rem;">Chart unavailable</div>';
            return;
        }

        ensureChartMilestoneFormatting();

        this.chart = LightweightCharts.createChart(div, {
            layout: {
                background: { type: 'solid', color: 'transparent' },
                textColor: '#ffffff',
            },
            grid: {
                vertLines: { visible: false },
                horzLines: { visible: false },
            },
            width: div.clientWidth,
            height: div.clientHeight,
            timeScale: {
                visible: false, // Hide time axis for clean look
                borderVisible: false,
            },
            rightPriceScale: {
                visible: this.showScale,
                borderVisible: false,
                scaleMargins: { top: 0.15, bottom: 0.15 },
            },
            crosshair: {
                mode: 0, // Disable crosshair (non-interactive)
            },
            handleScroll: false,
            handleScale: false,
        });

        // Create Area series (instead of Line) to support gradient fill
        // Default to Coffee, updated to Red/Green on load
        const lineColor = this.customColor || '#a49393';
        this.series = this.chart.addAreaSeries({
            topColor: 'rgba(164, 147, 147, 0.4)',
            bottomColor: 'rgba(164, 147, 147, 0)',
            lineColor: lineColor,
            lineWidth: 2,
            lastValueVisible: false,
            priceLineVisible: false,
            crosshairMarkerVisible: false,
        });

        // Resize Observer
        this.resizeObserver = new ResizeObserver(entries => {
            if (!entries[0] || !entries[0].contentRect) return;
            const { width, height } = entries[0].contentRect;
            if (this.chart) this.chart.applyOptions({ width, height });
        });
        this.resizeObserver.observe(div);
    }

    async load(retries = 3) {
        const loader = this.container.querySelector('.mini-chart-loader');

        // Jitter: Add random delay (0-500ms) to scatter simultaneous requests (e.g. initial scroll)
        await new Promise(resolve => setTimeout(resolve, Math.random() * 500));

        try {
            const api = AppState.controller.dataService;
            if (!api) throw new Error('DataService not ready');

            const res = await api.fetchHistory(this.code, '1y');

            // Check specifically for valid data array
            if (res && res.ok && Array.isArray(res.data) && res.data.length > 0 && this.series) {
                // Convert to line data format
                const lineData = res.data.map(d => ({
                    time: d.time,
                    value: d.close
                }));

                this.series.setData(lineData);
                this._updateStats(res.data);

                // --- DYNAMIC COLOR UPDATE ---
                // Calculate trend from loaded data
                const first = res.data[0].close;
                const last = res.data[res.data.length - 1].close;
                const isPositive = last >= first;

                const rgb = isPositive ? '6, 255, 79' : '255, 49, 49';
                const baseColor = isPositive ? '#06FF4F' : '#FF3131';

                this.series.applyOptions({
                    lineColor: baseColor,
                    topColor: `rgba(${rgb}, 0.5)`,
                    bottomColor: `rgba(${rgb}, 0.0)`
                });
                // -----------------------------

                this.chart.timeScale().fitContent();

                // Hide loader only on success
                if (loader) loader.style.display = 'none';
            } else {
                console.warn('[MiniChartPreview] Invalid response debug:', { code: this.code, res });
                throw new Error('Invalid data response');
            }
        } catch (e) {
            console.warn(`[MiniChartPreview] Load error (${retries} retries left):`, e);
            if (retries > 0) {
                // Backoff retry: 1.5s, 3s, 4.5s
                const delay = (4 - retries) * 1500;
                setTimeout(() => this.load(retries - 1), delay);
            } else {
                // Final failure: Hide loader to keep UI clean
                if (loader) loader.style.display = 'none';
            }
        }
    }

    // ... (rest of file)

    _updateStats(data) {
        const highEl = this.container.querySelector('.mini-chart-high');
        const lowEl = this.container.querySelector('.mini-chart-low');

        if (!data || data.length === 0) return;

        let periodHigh = -Infinity;
        let periodLow = Infinity;

        for (const candle of data) {
            const h = candle.high !== undefined ? candle.high : candle.close;
            const l = candle.low !== undefined ? candle.low : candle.close;
            if (h > periodHigh) periodHigh = h;
            if (l < periodLow) periodLow = l;
        }

        const formatPrice = (val) => {
            if (val >= 1) return '$' + val.toFixed(2);
            return '$' + val.toFixed(4);
        };

        if (highEl) highEl.textContent = 'H: ' + formatPrice(periodHigh);
        if (lowEl) lowEl.textContent = 'L: ' + formatPrice(periodLow);
    }

    destroy() {
        if (this.resizeObserver) this.resizeObserver.disconnect();
        if (this.chart) {
            this.chart.remove();
            this.chart = null;
        }
        this.container.innerHTML = '';
    }
}
