/**
 * DataProcessor.js
 * Pure business logic module for processing share data.
 * Handles filtering, merging with live prices, metric calculation, and sorting.
 */

import { UserStore } from './UserStore.js';
import { AppState } from '../state/AppState.js';
import { SIMULATIONS_WATCHLIST_ID } from '../utils/AppConstants.js';

// Instantiate strictly for helper methods (stateless usage of getWatchlistData)
const userStore = new UserStore();

/**
 * Normalizes mixed comment formats into a standard array of { body, date }.
 * Handles:
 * - Simple strings: "My comment" -> { body: "My comment", date: <iso> }
 * - Legacy objects: { text: "...", date: "..." } -> { body: "...", date: "..." }
 * - Legacy titles: { title: "Topic", body: "...", date: "..." } -> { body: "Topic: ...", date: "..." }
 * - Mixed arrays of the above.
 * @returns {Array<Object>}
 */
export function normalizeComments(comments) {
    if (!comments) return [];

    // Ensure we handle single items or arrays
    const raw = Array.isArray(comments) ? comments : [comments];

    return raw.map(c => {
        if (!c) return null;

        // Handle Simple String
        if (typeof c === 'string') {
            return { body: c, date: new Date().toISOString() };
        }

        // Handle Object
        if (typeof c === 'object') {
            const body = c.body || c.text || c.note || c.comment || '';
            const title = c.title || '';
            const date = c.date || c.createdAt || new Date().toISOString();

            // Combine Title and Body as requested
            const combinedBody = title ? `${title}: ${body}`.trim() : body.trim();

            return { 
                body: combinedBody, 
                date: date,
                height: c.height || null 
            };
        }

        return null;
    }).filter(c => c && c.body && c.body.trim().length > 0);
}

/**
 * Resolves the most accurate and valid market price for a share.
 * Cascades gracefully through live quotes, closing prices, and cost bases
 * to ensure out-of-hours feeds or missing prices NEVER collapse a holding to $0.
 * @param {Object|null} priceData - Price object from livePrices map
 * @param {Object} share - Share document
 * @returns {number} Validated price >= 0
 */
export function resolveStockPrice(priceData, share = {}) {
    // 1. Live Price from stream/API
    const live = parseFloat(priceData?.live);
    if (!isNaN(live) && live > 0) return live;

    // 2. Previous Close from stream/API (Essential for out-of-hours & weekends)
    const prevClose = parseFloat(priceData?.prevClose);
    if (!isNaN(prevClose) && prevClose > 0) return prevClose;

    // 3. User entered/purchase price fallbacks from share record
    const entered = parseFloat(share?.enteredPrice);
    if (!isNaN(entered) && entered > 0) return entered;

    const entry = parseFloat(share?.entryPrice);
    if (!isNaN(entry) && entry > 0) return entry;

    const buy = parseFloat(share?.buyPrice);
    if (!isNaN(buy) && buy > 0) return buy;

    const avgPrice = parseFloat(share?.portfolioAvgPrice ?? share?.averageCost ?? share?.avgCost ?? share?.avgPrice);
    if (!isNaN(avgPrice) && avgPrice > 0) return avgPrice;

    const purchase = parseFloat(share?.purchasePrice);
    if (!isNaN(purchase) && purchase > 0) return purchase;

    return 0;
}

/**
 * Processes raw share data into a view-ready format.
 * @param {Array} allShares - List of all user shares.
 * @param {string|null} watchlistId - Current watchlist ID (or 'ALL', null).
 * @param {Map} livePrices - Map of live price data.
 * @param {Object} sortConfig - { field, direction }
 * @returns {Object} { mergedData, summaryMetrics }
 */
export function processShares(allShares, watchlistId, livePrices, sortConfig, hiddenAssets = new Set()) {
    // 1. Filter by Watchlist
    const filteredShares = userStore.getWatchlistData(allShares, watchlistId);

    if (!filteredShares || filteredShares.length === 0) {
        return { mergedData: [], summaryMetrics: null };
    }

    // 2. Merge Data (Per-Share Calculations) & De-Duplication
    const processedMap = new Map();

    filteredShares.forEach(share => {
        // STRICT LOOKUP: Trim and Uppercase to match DataService keys
        const lookupKey = String(share.shareName || share.code || '').trim().toUpperCase();
        if (!lookupKey) return;

        // AUTOREPAIR: If ID is missing (Ghost), try to find it in the master list
        if (!share.id) {
            const masterRecord = allShares.find(s => s.shareName === share.shareName && s.id);
            if (masterRecord) {
                share.id = masterRecord.id;
            }
        }
        // OPTIMISTIC ID PROTECTION: 
        // If we have a protected Real ID for this code, and current share is Ghost or Temp, upgrade it.
        const codeKey = (share.code || share.shareName || '').toUpperCase();
        if (AppState.data.optimisticIds && AppState.data.optimisticIds.has(codeKey)) {
            const guardedId = AppState.data.optimisticIds.get(codeKey);
            // Only upgrade if we are moving UP the quality ladder
            if (!share.id || String(share.id).startsWith('temp_')) {
                share.id = guardedId;
            }
        }

        let priceData = livePrices ? livePrices.get(lookupKey) : null;

        // Fallback: Try appending .AX if not found
        if (!priceData && !lookupKey.includes('.') && livePrices) {
            priceData = livePrices.get(lookupKey + '.AX');
        }
        // Fallback: Try stripping .AX if not found
        if (!priceData && lookupKey.endsWith('.AX') && livePrices) {
            priceData = livePrices.get(lookupKey.replace('.AX', ''));
        }

        // OUT-OF-HOURS RESILIENT PRICE RESOLUTION:
        // Always cascades through live -> prevClose -> entry/buy/cost price
        const currentPrice = resolveStockPrice(priceData, share);
        const dayChangePercent = priceData ? (parseFloat(priceData.pctChange) || 0) : 0;

        const isSimulationsView = watchlistId === SIMULATIONS_WATCHLIST_ID;
        const units = isSimulationsView ? (parseFloat(share.simulatedQty) || 0) : (parseFloat(share.portfolioShares) || 0);

        // Cost Basis Logic: Expanded fallbacks for rewrite compatibility
        const costPrice = isSimulationsView
            ? (parseFloat(share.enteredPrice) || parseFloat(share.entryPrice) || (units > 0 ? (parseFloat(share.simulatedValue) / units) : 0))
            : (parseFloat(share.buyPrice) ||
               parseFloat(share.portfolioAvgPrice) ||
               parseFloat(share.averageCost) ||
               parseFloat(share.avgCost) ||
               parseFloat(share.avgPrice) ||
               parseFloat(share.purchasePrice) ||
               (share.simulatedActive ? 0 : (parseFloat(share.entryPrice) || parseFloat(share.enteredPrice) || 0)));

        const enteredPrice = isSimulationsView
            ? (parseFloat(share.entryPrice) || parseFloat(share.enteredPrice) || costPrice)
            : (share.simulatedActive
                ? (parseFloat(share.entryPrice) || parseFloat(share.enteredPrice) || 0)
                : (parseFloat(share.entryPrice) ||
                   parseFloat(share.enteredPrice) ||
                   parseFloat(share.buyPrice) ||
                   costPrice || 0));

        const value = units * currentPrice;
        const cost = isSimulationsView ? (parseFloat(share.simulatedValue) || 0) : (units * costPrice);

        // Day Change Logic
        const divisor = 1 + (dayChangePercent / 100);
        const previousValue = (divisor !== 0 && !isNaN(divisor)) ? (value / divisor) : value;
        const dayChangeValue = value - previousValue; // Total holdings change
        const previousPrice = (divisor !== 0 && !isNaN(divisor)) ? (currentPrice / divisor) : currentPrice; // Price before change
        const dayChangePerShare = currentPrice - previousPrice; // Per-share change

        const capitalGain = value - cost;
        const capitalGainPercent = cost > 0 ? (capitalGain / cost) * 100 : 0;

        // DE-DUPLICATION LOGIC WITH UNIT PRESERVATION:
        // If an entry already exists for this code, aggregate holding units and cost basis
        // while preserving the most complete metadata (targets, comments, IDs).
        if (processedMap.has(lookupKey)) {
            const existing = processedMap.get(lookupKey);
            if (units > 0) {
                existing.units = (existing.units || 0) + units;
                existing.costBasis = (existing.costBasis || 0) + cost;
                existing.value = existing.units * currentPrice;
                const existingDivisor = 1 + (existing.dayChangePercent / 100);
                const prevExistingVal = (existingDivisor !== 0 && !isNaN(existingDivisor)) ? (existing.value / existingDivisor) : existing.value;
                existing.dayChangeValue = existing.value - prevExistingVal;
                existing.capitalGain = existing.value - existing.costBasis;
                existing.capitalGainPercent = existing.costBasis > 0 ? (existing.capitalGain / existing.costBasis) * 100 : 0;
            }

            // Upgrade metadata if new record has better data
            if ((!existing.targetPrice || Number(existing.targetPrice) === 0) && Number(share.targetPrice) > 0) {
                existing.targetPrice = share.targetPrice;
            }
            if ((!existing.comments || existing.comments.length === 0) && share.comments) {
                existing.comments = normalizeComments(share.comments);
            }
            if ((!existing.id || String(existing.id).startsWith('temp_')) && (share.id && !String(share.id).startsWith('temp_'))) {
                existing.id = share.id;
            }
            return;
        }

        const processedShare = {
            ...share,
            // Robust Link: Usage of 'shareName' (Legacy) vs 'code' (New Schema)
            code: share.shareName || share.code,
            shareName: share.shareName || share.code,
            currentPrice: currentPrice,
            dayChangePercent: dayChangePercent,
            dayChangeValue: dayChangeValue,
            dayChangePerShare: dayChangePerShare,
            units: units,
            value: value,
            costBasis: cost,
            costPrice: costPrice,
            enteredPrice: enteredPrice,
            capitalGain: capitalGain,
            capitalGainPercent: capitalGainPercent,
            comments: normalizeComments(share.comments),
            isHidden: hiddenAssets.has(String(share.id)),
            sector: priceData ? priceData.sector : (share.sector || ''),
            industry: priceData ? priceData.industry : (share.industry || ''),
            high52: priceData ? priceData.high : 0,
            low52: priceData ? priceData.low : 0,
            quoteTime: priceData ? (priceData.quoteTime || null) : null,
            lastUpdate: priceData ? (priceData.lastUpdate || null) : null
        };

        processedMap.set(lookupKey, processedShare);
    });

    // Convert Map back to Array
    const mergedData = Array.from(processedMap.values());
    const liveCount = mergedData.filter(m => m.currentPrice > 0).length;


    // 3. Calculate Totals (ONLY for Portfolio view, usually skip hidden)
    // We pass mergedData but we want the summary to exclude hidden shares.
    const summaryMetrics = calculatePortfolioTotals(mergedData.filter(s => !s.isHidden));

    // 4. Sort Data
    const { field, direction } = sortConfig;
    mergedData.sort((a, b) => {
        // Rule: Hidden shares ALWAYS go to the bottom
        if (a.isHidden && !b.isHidden) return 1;
        if (!a.isHidden && b.isHidden) return -1;

        let valA = a[field];
        let valB = b[field];

        // Pre-process Date fields with fallbacks & robust parsing
        if (field === 'entryDate' || field === 'purchaseDate') {
            const parseDate = (dStr) => {
                if (!dStr) return NaN;
                if (typeof dStr !== 'string') return new Date(dStr).getTime();
                if (dStr.includes('/')) {
                    const p = dStr.split('/');
                    if (p.length === 3) return new Date(`${p[2]}-${p[1]}-${p[0]}`).getTime();
                }
                return new Date(dStr).getTime();
            };

            const actualA = valA || (field === 'entryDate' ? a.purchaseDate : a.entryDate);
            const actualB = valB || (field === 'entryDate' ? b.purchaseDate : b.entryDate);

            const tA = parseDate(actualA);
            const tB = parseDate(actualB);
            valA = isNaN(tA) ? null : tA;
            valB = isNaN(tB) ? null : tB;
        }

        // Handle string comparison for code/names
        if (field === 'code' || field === 'name') {
            valA = String(valA || '').toLowerCase();
            valB = String(valB || '').toLowerCase();
            if (valA < valB) return direction === 'asc' ? -1 : 1;
            if (valA > valB) return direction === 'asc' ? 1 : -1;
            return 0;
        }

        // === Custom Sort: Comments & Targets ===
        // Logic: Presence First, then Code (Asc/Desc based on toggle)
        if (field === 'comments' || field === 'targetPrice') {
            // Determine Presence
            let hasA = false;
            let hasB = false;

            if (field === 'comments') hasA = (a.comments && a.comments.length > 0);
            if (field === 'comments') hasB = (b.comments && b.comments.length > 0);

            if (field === 'targetPrice') hasA = (a.targetPrice && a.targetPrice > 0);
            if (field === 'targetPrice') hasB = (b.targetPrice && b.targetPrice > 0);

            // Primary: Presence
            if (hasA && !hasB) return -1; // A has data, B doesn't -> A first
            if (!hasA && hasB) return 1;  // B has data, A doesn't -> B first

            // Secondary: Code Sort (if both have or both don't)
            // Respect Toggle:
            // High to Low (Green Up) -> 'asc' for Text -> A-Z
            // Low to High (Red Down) -> 'desc' for Text -> Z-A
            const codeA = String(a.code || '').toLowerCase();
            const codeB = String(b.code || '').toLowerCase();

            if (codeA < codeB) return direction === 'asc' ? -1 : 1;
            if (codeA > codeB) return direction === 'asc' ? 1 : -1;
            return 0;
        }

        // Handle Numeric Sorting (Sparse Data Support)
        // Rule: Missing/Invalid values (null, undefined, NaN) ALWAYS go to the bottom.
        // Special Case: For 'starRating' and 'dividendAmount', 0 is considered "Missing".
        const isSparseField = field === 'starRating' || field === 'dividendAmount';
        const isInvalid = (v) => {
            if (v === null || v === undefined || isNaN(Number(v))) return true;
            if (isSparseField && Number(v) === 0) return true;
            return false;
        };

        const badA = isInvalid(valA);
        const badB = isInvalid(valB);

        if (badA && !badB) return 1;  // A is missing -> push to bottom
        if (!badA && badB) return -1; // B is missing -> push to bottom
        if (badA && badB) return 0;   // Both missing -> keep order

        const numA = Number(valA);
        const numB = Number(valB);

        return direction === 'asc' ? numA - numB : numB - numA;
    });

    return { mergedData, summaryMetrics };
}

/**
 * Calculates portfolio summary metrics from processed share data.
 * @param {Array} processedShares - Array of processed share objects (with value, costBasis, dayChangeValue).
 * @returns {Object} { totalValue, dayChangeValue, dayChangePercent, totalCost, totalReturn, totalReturnPercent }
 */
export function calculatePortfolioTotals(processedShares) {
    if (!processedShares || processedShares.length === 0) {
        return {
            totalValue: 0,
            dayChangeValue: 0,
            dayChangePercent: 0,
            totalCost: 0,
            totalReturn: 0,
            totalReturnPercent: 0,
            gainerCount: 0,
            loserCount: 0,
            neutralCount: 0
        };
    }

    let totalValue = 0;
    let totalCost = 0;
    let totalDailyPnL = 0;
    let dayGain = 0;
    let dayLoss = 0;
    let previousTotalValue = 0;
    let gainerCount = 0;
    let loserCount = 0;
    let neutralCount = 0;

    for (const share of processedShares) {
        if (!share) continue;
        const val = Number.isFinite(share.value) ? share.value : 0;
        const cost = Number.isFinite(share.costBasis) ? share.costBasis : 0;
        const dailyChange = Number.isFinite(share.dayChangeValue) ? share.dayChangeValue : 0;

        totalValue += val;
        totalCost += cost;
        totalDailyPnL += dailyChange;

        // Use dayChangePercent for gainer/loser counting (works for all stocks, including watchlist-only)
        const pctChange = Number.isFinite(share.dayChangePercent) ? share.dayChangePercent : 0;
        if (pctChange > 0) {
            dayGain += dailyChange;
            gainerCount++;
        } else if (pctChange < 0) {
            dayLoss += dailyChange;
            loserCount++;
        } else {
            neutralCount++;
        }

        // precise previous value reconstruction for accurate %
        // current = prev * (1 + pct) -> prev = current / (1 + pct)
        // But we already have dayChangeValue = current - prev -> prev = current - change
        previousTotalValue += (val - dailyChange);
    }

    // Total Daily Percent = (Total Daily PnL / Previous Total Value) * 100
    // Fix: If previous value is 0 (new portfolio), handle gracefully.
    const totalDailyPercent = Math.abs(previousTotalValue) > 0.01
        ? (totalDailyPnL / previousTotalValue) * 100
        : 0;

    const dayGainPercent = Math.abs(previousTotalValue) > 0.01
        ? (dayGain / previousTotalValue) * 100
        : 0;

    const dayLossPercent = Math.abs(previousTotalValue) > 0.01
        ? (dayLoss / previousTotalValue) * 100
        : 0;

    const totalReturn = totalValue - totalCost;
    const totalReturnPercent = totalCost > 0 ? (totalReturn / totalCost) * 100 : 0;

    return {
        totalValue: Number.isFinite(totalValue) ? totalValue : 0,
        dayChangeValue: Number.isFinite(totalDailyPnL) ? totalDailyPnL : 0,
        dayGain: Number.isFinite(dayGain) ? dayGain : 0,
        dayLoss: Number.isFinite(dayLoss) ? dayLoss : 0,
        dayChangePercent: Number.isFinite(totalDailyPercent) ? totalDailyPercent : 0,
        dayGainPercent: Number.isFinite(dayGainPercent) ? dayGainPercent : 0,
        dayLossPercent: Number.isFinite(dayLossPercent) ? dayLossPercent : 0,
        totalCost: Number.isFinite(totalCost) ? totalCost : 0,
        totalReturn: Number.isFinite(totalReturn) ? totalReturn : 0,
        totalReturnPercent: Number.isFinite(totalReturnPercent) ? totalReturnPercent : 0,
        gainerCount,
        loserCount,
        neutralCount
    };
}

/**
 * Retrieves and processes data for a single share.
 * @param {string} code - The stock code to look up.
 * @param {Array} allShares - List of all user shares.
 * @param {Map} livePrices - Map of live price data.
 * @param {Array} userWatchlists - List of user's custom watchlists (optional).
 * @returns {Object|null} Processed stock object or null if not found.
 */
export function getSingleShareData(code, allShares, livePrices, userWatchlists = []) {
    // Normalize code upfront for consistent matching
    const normalizedCode = String(code || '').trim().toUpperCase();

    // 1. Find Primary Share (for base fields) - CASE-INSENSITIVE
    const primaryShare = getBestShareMatch(allShares, normalizedCode);
    if (!primaryShare) return null;

    // OPTIMISTIC ID PROTECTION: Check guarded IDs registry
    if (AppState.data.optimisticIds && AppState.data.optimisticIds.has(normalizedCode)) {
        const guardedId = AppState.data.optimisticIds.get(normalizedCode);
        if (!primaryShare.id || String(primaryShare.id).startsWith('temp_')) {
            primaryShare.id = guardedId;
        }
    }

    // 2. Aggregate Memberships from ALL matching share documents
    const membershipSet = new Set();

    // Find all records for this code - CASE-INSENSITIVE
    const matchingShares = allShares.filter(s =>
        String(s.shareName || '').trim().toUpperCase() === normalizedCode
    );

    matchingShares.forEach(s => {
        // Collect from watchlistIds (array) or watchlistId (singular)
        const ids = s.watchlistIds || [];
        if (s.watchlistId) ids.push(s.watchlistId);

        ids.forEach(id => {
            if (id === 'portfolio' || id === 'PORTFOLIO') {
                membershipSet.add('Portfolio');
            } else {
                const wl = userWatchlists.find(w => w.id === id);
                if (wl) membershipSet.add(wl.name);
            }
        });

        // Implicitly in portfolio if it has units
        if ((parseInt(s.portfolioShares) || 0) > 0) {
            membershipSet.add('Portfolio');
        }
    });

    // 3. Fallback: Check each Watchlist's stocks array (Fallback/Parallel Logic)
    if (userWatchlists && Array.isArray(userWatchlists)) {
        userWatchlists.forEach(w => {
            if (w.stocks && Array.isArray(w.stocks)) {
                // Check if any of our matching share document IDs are in this watchlist's array
                // OR if the code itself is in the array
                const hasMatch = matchingShares.some(s => w.stocks.includes(s.id)) || w.stocks.includes(normalizedCode);
                if (hasMatch) {
                    membershipSet.add(w.name);
                }
            }
        });
    }

    // 4. Lookup Price
    const lookupKey = normalizedCode;
    let priceData = livePrices ? livePrices.get(lookupKey) : null;

    // Fallback: Try appending .AX if not found
    if (!priceData && !lookupKey.includes('.') && livePrices) {
        priceData = livePrices.get(lookupKey + '.AX');
    }
    // Fallback: Try stripping .AX if not found
    if (!priceData && lookupKey.endsWith('.AX') && livePrices) {
        priceData = livePrices.get(lookupKey.replace('.AX', ''));
    }

    // 5. Process Primary Data (using fields from the first share found)
    const currentPrice = resolveStockPrice(priceData, primaryShare);
    const dayChangePercent = priceData ? (parseFloat(priceData.pctChange) || 0) : 0;
    const units = matchingShares.reduce((acc, s) => acc + (parseFloat(s.portfolioShares) || 0), 0);
    const value = units * currentPrice;

    // Derived Calculations using aggregated units
    const costPrice = parseFloat(primaryShare.buyPrice) ||
        parseFloat(primaryShare.portfolioAvgPrice) ||
        parseFloat(primaryShare.averageCost) ||
        parseFloat(primaryShare.avgCost) ||
        parseFloat(primaryShare.avgPrice) ||
        parseFloat(primaryShare.purchasePrice) ||
        (primaryShare.simulatedActive ? 0 : (parseFloat(primaryShare.entryPrice) || parseFloat(primaryShare.enteredPrice) || 0));

    const enteredPrice = primaryShare.simulatedActive
        ? (parseFloat(primaryShare.entryPrice) || parseFloat(primaryShare.enteredPrice) || 0)
        : (parseFloat(primaryShare.entryPrice) ||
           parseFloat(primaryShare.enteredPrice) ||
           parseFloat(primaryShare.buyPrice) ||
           costPrice || 0);
    const costBasis = matchingShares.reduce((acc, s) => {
        const u = parseInt(s.portfolioShares) || 0;
        const cp = parseFloat(s.buyPrice) ||
            parseFloat(s.portfolioAvgPrice) ||
            parseFloat(s.averageCost) ||
            parseFloat(s.avgCost) ||
            parseFloat(s.avgPrice) ||
            parseFloat(s.purchasePrice) ||
            costPrice;
        return acc + (u * cp);
    }, 0);

    const capitalGain = value - costBasis;
    const dayChangeValue = priceData && priceData.change ? priceData.change * units : 0;

    // Sort for consistency
    const watchlistNames = Array.from(membershipSet).sort();

    // 6. Return Merged Object
    return {
        ...primaryShare,
        code: normalizedCode,
        name: priceData ? priceData.name : (primaryShare.shareName || ''),
        currentPrice: currentPrice,
        dayChangePercent: dayChangePercent,
        dayChangePerShare: priceData ? priceData.change : 0,
        dayChangeValue: dayChangeValue,
        units: units,
        value: value,
        costBasis: costBasis,
        costPrice: costPrice,
        enteredPrice: enteredPrice,
        capitalGain: capitalGain,
        capitalGainPercent: costBasis !== 0 ? (capitalGain / costBasis) * 100 : 0,
        comments: normalizeComments(primaryShare.comments),
        watchlistNames: watchlistNames,
        high: priceData ? priceData.high : 0,
        low: priceData ? priceData.low : 0,
        pe: priceData ? priceData.pe : 0,
        live: priceData ? priceData.live : currentPrice,
        change: priceData ? priceData.change : 0,
        pctChange: priceData ? priceData.pctChange : dayChangePercent,
        sector: priceData ? priceData.sector : (primaryShare.sector || ''),
        industry: priceData ? priceData.industry : (primaryShare.industry || '')
    };
}

/**
 * Generates status objects for a list of codes based on live price data.
 * @param {Array<string>} codes - List of stock codes.
 * @param {Map} livePrices - Live price map.
 * @returns {Array<Object>} Array of { code, status: 'up'|'down'|'neutral' }
 */
export function getASXCodesStatus(codes, livePrices) {
    return codes.map(code => {
        const lookupKey = String(code).trim().toUpperCase();
        let priceData = livePrices.get(lookupKey);

        // Fallback
        if (!priceData && !lookupKey.includes('.')) {
            priceData = livePrices.get(lookupKey + '.AX');
        }

        let status = 'neutral';

        if (priceData) {
            const pct = parseFloat(priceData.pctChange) || 0;
            if (pct > 0) status = 'up';
            if (pct < 0) status = 'down';
        }

        return { code, status };
    });
}

/**
 * Finds the "best" share document for a given code from a list of shares.
 * Ranking:
 * 1. Has Target Price over No Target Price (Prioritize alert configuration)
 * 2. Real ID over Temp/Ghost
 * 3. Has Portfolio Units over No Units
 * @param {Array} shares 
 * @param {string} code 
 * @returns {Object|null}
 */
export function getBestShareMatch(shares, code) {
    if (!shares || !code) return null;
    const cleanC = String(code).toUpperCase().replace(/\.AX$/i, '').trim();

    const matches = shares.filter(s => {
        const sCode = (s.shareName || s.code || '').toUpperCase().replace(/\.AX$/i, '').trim();
        return sCode === cleanC;
    });

    if (matches.length === 0) return null;
    if (matches.length === 1) return matches[0];

    const score = (s) => {
        let points = 0;
        // Target Presence (CRITICAL for alerts)
        if (Number(s.targetPrice || 0) > 0) points += 200;

        // ID Quality
        if (s.id && !String(s.id).startsWith('temp_')) points += 100;
        else if (s.id) points += 50;

        // Portfolio Presence
        if (Number(s.portfolioShares || 0) > 0) points += 10;

        return points;
    };

    return matches.sort((a, b) => score(b) - score(a))[0];
}
