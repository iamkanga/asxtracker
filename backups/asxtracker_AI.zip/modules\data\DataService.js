/**
 * DataService.js
 * Handles fetching and normalizing stock price data from the API.
 */

import { UserStore } from './UserStore.js';
import { db, AuthService } from '../auth/AuthService.js';
import {
    collection,
    addDoc,
    updateDoc,
    deleteDoc,
    doc
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

const APP_ID = "asx-watchlist-app";

// Initialize and Export UserStore Instance
export const userStore = new UserStore();
export { AuthService };
import { ToastManager } from '../ui/ToastManager.js';
import { MarketSchedule, ASX_SESSION } from '../utils/MarketSchedule.js';
import { API_ENDPOINT, STORAGE_KEYS, SPARKLINE_CONFIG } from '../utils/AppConstants.js';
import { SparklineCache } from './SparklineCache.js';
import { SparklineRefresher } from './SparklineRefresher.js';

/**
 * Helper to detect network/connectivity failures from fetch requests.
 * Standard fetch failures reject with a TypeError containing these signature messages.
 */
function isNetworkError(error) {
    if (error instanceof TypeError) {
        const msg = error.message.toLowerCase();
        return msg.includes('failed to fetch') || 
               msg.includes('networkerror') || 
               msg.includes('fetch failed') || 
               msg.includes('load failed');
    }
    return false;
}

export class DataService {
    constructor() {
        this.API_ENDPOINT = (API_ENDPOINT || '').replace(/\/+$/, '');
        this._historyQueue = [];
        this._isProcessingHistoryQueue = false;
        this._historyInflight = new Map(); // cacheKey -> Promise (de-dupes identical in-flight requests)
        this._liveFetchCount = 0; // In-flight live price requests (foreground traffic signal)
        this._lastSyncUserSettingsTime = 0; // Throttling guard for syncUserSettings

        // Sparkline pipeline: cache-first reads (UI) + quiet background refresh (network)
        this.sparklineCache = new SparklineCache();
        this.sparklineRefresher = new SparklineRefresher({
            cache: this.sparklineCache,
            fetchRows: (code) => this._fetchSparklineRows(code),
            canFetch: () => {
                try { return !!AuthService.getCurrentUser(); } catch (e) { return false; }
            },
            isForegroundBusy: () => this._liveFetchCount > 0 ||
                this._historyQueue.length > 0 ||
                this._isProcessingHistoryQueue
        });
    }

    /**
     * Queues a background sparkline refresh for a code IF the cache says it is stale.
     * Never blocks and never fetches inline. Safe to call on every card render.
     * @param {string} code
     * @returns {Promise<boolean>} true if queued
     */
    requestSparklineRefresh(code) {
        try {
            if (!this.sparklineRefresher) return Promise.resolve(false);
            return this.sparklineRefresher.request(code);
        } catch (e) {
            return Promise.resolve(false);
        }
    }

    /**
     * Opens the background refresher gate. Call after a live price sync completes.
     */
    armSparklineRefresher() {
        try {
            if (this.sparklineRefresher) this.sparklineRefresher.arm();
        } catch (e) {
            console.warn('[DataService] Failed to arm sparkline refresher:', e);
        }
    }

    /**
     * Network fetch of 1y history rows for the sparkline refresher.
     * Does NOT write the legacy full-history cache (sparklines have their own slim cache).
     * @private
     */
    async _fetchSparklineRows(code) {
        const res = await this._execFetchHistory(code, SPARKLINE_CONFIG.RANGE, true, null, false);
        return (res && res.ok && Array.isArray(res.data)) ? res.data : null;
    }
    /**
     * Fetches live prices for specific codes or all stocks if no codes provided.
     * @param {string[]} [codesArray] - Optional array of ASX codes (e.g. ['BHP', 'CBA'])
     * @param {boolean} [silent=false] - If true, suppresses slow connection toast notifications (for background syncs)
     * @returns {Promise<Map<string, Object>>} - Map of clean price objects keyed by code.
     */
    async fetchLivePrices(codesArray = null, silent = false) {
        this._liveFetchCount++;
        try {
            const cleanBase = (this.API_ENDPOINT || API_ENDPOINT).replace(/\/+$/, '');
            const url = new URL(cleanBase);
            url.searchParams.append('_ts', Date.now()); // Prevent caching

            // API STRATEGY:
            // 1. Single Code: use ?stockCode=XYZ (Fastest)
            // 2. Multiple Codes: Fetch ALL (No params). 
            //    Reason: API fails with comma-separated list, and API ignores repeated params (only returns one).
            //    Fetching all is the only reliable way to get a batch.
            if (Array.isArray(codesArray) && codesArray.length === 1 && typeof codesArray[0] === 'string' && codesArray[0].trim()) {
                url.searchParams.append('stockCode', codesArray[0].trim().toUpperCase());
            }

            // TRACE LOGGING
            // TIMEOUT PROTECTION (60 Seconds for Google Apps Script cold starts)
            const controller = new AbortController();
            let warningId = null;
            if (!silent) {
                warningId = setTimeout(() => {
                    ToastManager.info("Retrieving stock prices is taking longer than expected. Please wait...", "Slow Connection");
                }, 40000); // 40s threshold to tolerate Google Apps Script container spin-up times
            }
            const timeoutId = setTimeout(() => controller.abort(), 60000);

            try {
                const response = await fetch(url.toString(), {
                    method: 'GET',
                    redirect: 'follow', // Explicitly handle Google Apps Script 302 -> script.googleusercontent.com
                    cache: 'no-store',  // Bypass browser/proxy cache for live price polling
                    headers: {
                        'Accept': 'application/json'
                    },
                    signal: controller.signal
                });
                if (warningId) clearTimeout(warningId);
                clearTimeout(timeoutId);

                if (!response.ok) {
                    if (response.status === 404) {
                        console.warn(`DataService: Live price fetch returned 404 (likely Google Apps Script container spin-up timeout). Fast retry will re-poll warm container.`);
                    } else {
                        console.error(`DataService Fetch Error: ${response.status} ${response.statusText}`);
                    }
                    return { ok: false, prices: new Map(), dashboard: [] };
                }

                // Protect against HTML responses (e.g. Google error/login pages served with 200)
                const contentType = response.headers.get('content-type') || '';
                let json;
                if (contentType.includes('application/json') || contentType.includes('text/plain') || contentType.includes('application/javascript')) {
                    json = await response.json();
                } else {
                    const text = await response.text();
                    try {
                        json = JSON.parse(text);
                    } catch (parseErr) {
                        console.warn(`DataService: Received non-JSON response (${contentType}, length: ${text.length}).`);
                        return { ok: false, prices: new Map(), dashboard: [] };
                    }
                }

                // Normalize and return both prices and dashboard data
                const normalized = this._normalizePriceData(json);
                return { ok: true, ...normalized };

            } catch (error) {
                if (warningId) clearTimeout(warningId);
                clearTimeout(timeoutId);
                if (error.name === 'AbortError') {
                    console.warn("DataService: Fetch timed out (60s limit).");
                } else if (isNetworkError(error)) {
                    console.warn("DataService: Live prices fetch network failure (Failed to fetch).");
                    if (!silent) {
                        ToastManager.error("Network error while connecting to price servers. Retrying...", "Connection Error");
                    }
                } else {
                    console.error("DataService Exception:", error);
                }
                return { ok: false, prices: new Map(), dashboard: [] };
            }
        } catch (error) {
            // This outer catch handles errors from URL construction or initial setup
            console.error("DataService: Outer fetchLivePrices error:", error);
            return { ok: false, prices: new Map(), dashboard: [] };
        } finally {
            this._liveFetchCount = Math.max(0, this._liveFetchCount - 1);
        }
    }

    /**
     * Triggers the Apps Script to synchronize user profile settings to central global settings.
     * Uses JSONP style fallback (callback param) as the Apps Script handles it via doGet.
     * Throttled with a 15-second minimum gap to prevent redundant network invocations.
     * @param {string} userId - The Firebase UID of the current user.
     */
    async syncUserSettings(userId) {
        if (!userId) return;
        const now = Date.now();
        if (this._lastSyncUserSettingsTime && (now - this._lastSyncUserSettingsTime < 15000)) {
            return;
        }
        this._lastSyncUserSettingsTime = now;
        try {
            const cleanBase = (this.API_ENDPOINT || API_ENDPOINT).replace(/\/+$/, '');
            const url = new URL(cleanBase);
            url.searchParams.append('userId', userId);
            url.searchParams.append('callback', 'sync_callback_' + Date.now());
            url.searchParams.append('_ts', Date.now());

            // We use a simple fetch. Since it's JSONP-style on the backend, 
            // it will return a 200 OK with a javascript body.
            const response = await fetch(url.toString(), {
                method: 'GET',
                redirect: 'follow'
            });
            if (!response.ok) {
                console.warn(`DataService: Sync request failed with status ${response.status}`);
            }
        } catch (err) {
            if (isNetworkError(err)) {
                console.warn('DataService: Sync network failure (Failed to fetch).');
            } else {
                console.error('DataService: Sync Exception:', err);
            }
        }
    }






    /**
     * Triggers a portfolio history snapshot on the backend.
     */
    async recordSnapshot() {
        try {
            const user = AuthService.getCurrentUser();
            const userId = user ? user.uid : null;
            if (!userId) return { ok: false, error: 'No user authenticated' };

            const payload = {
                action: 'recordSnapshot',
                userId: userId
            };

            const cleanBase = (this.API_ENDPOINT || API_ENDPOINT).replace(/\/+$/, '');
            const response = await fetch(cleanBase, {
                method: 'POST',
                redirect: 'follow',
                body: JSON.stringify(payload)
            });

            if (!response.ok) return { ok: false, error: `HTTP ${response.status}` };
            return await response.json();
        } catch (err) {
            if (isNetworkError(err)) {
                console.warn('[DataService] Snapshot Trigger network failure (Failed to fetch).');
            } else {
                console.error('[DataService] Snapshot Trigger Fail:', err);
            }
            return { ok: false, error: err.message };
        }
    }

    /**
     * One-time database scrub routine: Purges corrupted out-of-hours snapshots from Firestore.
     */
    async cleanCorruptedHistorySnapshots() {
        const user = AuthService.getCurrentUser();
        const userId = user ? user.uid : null;
        if (!userId) return { ok: false, error: 'No user authenticated' };
        try {
            return await userStore.cleanCorruptedHistorySnapshots(userId);
        } catch (e) {
            console.error('[DataService] Error scrubbing snapshots:', e);
            return { ok: false, error: e.message };
        }
    }

    /**
     * Saves a manual dividend override (like Franking %) for a specific stock.
     * @param {string} ticker - ASX code
     * @param {Object} data - { franking: number }
     */
    async saveDividendOverride(ticker, data) {
        try {
            const user = AuthService.getCurrentUser();
            if (!user) return { ok: false, error: 'User not logged in' };

            const overrideRef = doc(db, 'user_metadata_overrides', user.uid, 'tickers', ticker);
            await updateDoc(overrideRef, data).catch(async (err) => {
                // If document doesn't exist, use setDoc (which is handled by addDoc-like logic in some wrappers, but here we use Firebase direct)
                // Actually, standard Firebase: if update fails because it doesn't exist, we should use setDoc.
                // For simplicity in this env, we'll try to get the parent or just use a more robust helper.
                const { setDoc } = await import("https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js");
                await setDoc(overrideRef, data, { merge: true });
            });

            return { ok: true };
        } catch (err) {
            console.error('[DataService] Save Override Fail:', err);
            return { ok: false, error: err.message };
        }
    }

    /**
     * Ask Gemini (Smart Alerts or Market Chat).
     * @param {string} mode 'explain' | 'chat'
     * @param {string} query User question (for chat)
     * @param {Object} context Portfolio data or stock info
     */
    async askGemini(mode, query, context) {
        try {
            const user = AuthService.getCurrentUser();
            const userId = user ? user.uid : null;

            if (!userId) return { ok: false, error: 'User not logged in' };

            const payload = {
                action: 'geminiQuery',
                userId: userId,
                mode: mode,
                query: query,
                context: context
            };
            const cleanBase = (this.API_ENDPOINT || API_ENDPOINT).replace(/\/+$/, '');
            const response = await fetch(cleanBase, {
                method: 'POST',
                redirect: 'follow',
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                console.error('[DataService] Ask Gemini HTTP Error:', response.status);
                return { ok: false, error: `HTTP ${response.status}` };
            }

            const json = await response.json();
            if (!json.ok && json.error) console.warn('[DataService] Gemini Error:', json.error);
            return json;

        } catch (err) {
            if (isNetworkError(err)) {
                console.warn('DataService: Gemini Query network failure (Failed to fetch).');
            } else {
                console.error('DataService: Gemini Query Exception:', err);
            }
            return { ok: false, error: err.message };
        }
    }

    /**
     * Universal Gemini 3 AI Research Fetch
     * @param {string} symbol - Ticker (e.g. CBA)
     * @param {string} questionId - ID (e.g. key_risks)
     * @param {string} promptTemplate - The template text
     */
    async fetchAiSummary(symbol, questionId, promptTemplate) {
        try {
            // 1. Variable Replacement
            // Hardened: Ensure promptTemplate and symbol are strings before manipulation
            const safeTemplate = String(promptTemplate || '');
            const safeSymbol = String(symbol || '');

            const prompt = safeTemplate.replace(/\$\{code\}/g, safeSymbol)
                .replace(/\{\{STOCK\}\}/g, safeSymbol);

            const user = AuthService.getCurrentUser();
            const userId = user ? user.uid : null;

            if (!userId) {
                return { ok: false, error: 'User not logged in' };
            }

            const payload = {
                action: 'gemini3Research',
                userId: userId,
                symbol: symbol,
                questionId: questionId,
                prompt: prompt,
                thinking: true // Critical for dividend/technical analysis
            };
            const cleanBase = (this.API_ENDPOINT || API_ENDPOINT).replace(/\/+$/, '');
            const response = await fetch(cleanBase, {
                method: 'POST',
                redirect: 'follow',
                body: JSON.stringify(payload)
            });
            if (!response.ok) {
                if (response.status === 429) return { ok: false, error: 'RATE_LIMIT', retryAfter: 60 };
                return { ok: false, error: `HTTP ${response.status}` };
            }

            const json = await response.json();
            return json;

        } catch (err) {
            if (isNetworkError(err)) {
                console.warn('DataService: AI Research network failure (Failed to fetch).');
            } else {
                console.error('DataService: AI Research Exception:', err);
            }
            return { ok: false, error: err.message };
        }
    }

    /**
     * Normalizes raw API response into a clean Map.
     * @param {Array|Object} apiResponse 
     * @returns {Map<string, Object>}
     * @private
     */
    /**
     * Searches for stocks within the provided live prices map.
     * Prioritizes results: Ticker Start > Name Start > Name Contains.
     * @param {string} query - The search query (ticker or name).
     * @param {Map} livePrices - The Map of live price objects.
     * @returns {Array} - Array of matching stock objects (limit 50).
     */
    searchStocks(query, livePrices, industryFilters = null) {
        if (!livePrices) return [];

        // Allow empty query if industryFilters is present (Scanner Mode)
        // If industryFilters is null/undefined, it means "No Filter" (Show All).
        // If industryFilters is an array (even empty), it means "Whitelist".
        const isWhitelistMode = Array.isArray(industryFilters);
        if ((!query || typeof query !== 'string') && !isWhitelistMode) return [];

        const q = (query || '').toUpperCase().trim();
        const hasQuery = q.length > 0;

        // Priority Buckets
        const bucketTickerStart = []; // Bucket 1: Ticker starts with Q
        const bucketNameStart = [];   // Bucket 2: Name starts with Q
        const bucketNameContains = []; // Bucket 3: Name contains Q

        for (const [code, data] of livePrices) {
            const upperCode = code.toUpperCase();
            const upperName = (data.name || '').toUpperCase();

            const isTickerMatch = upperCode.startsWith(q);
            const isNameStartMatch = upperName.startsWith(q);
            const isNameContainsMatch = upperName.includes(q);

            const resultItem = {
                code: code,
                name: data.name || '',
                ...data
            };

            // 1. FILTER: Industry (Global Scanner)
            if (isWhitelistMode) {
                const itemIndustry = (data.industry || '').trim().toUpperCase();
                // If whitelist is [], match will always be false (None selected)
                const match = industryFilters.some(f => f.toUpperCase() === itemIndustry);

                // RESILIENCE: If it's an exact ticker match, bypass sector filter (User intent override)
                // This prevents "Black Hole" searches when metadata is incomplete or filters are restrictive.
                const isExactTicker = upperCode === q;

                if (!match && !isExactTicker) {
                    continue;
                }
            }

            // 2. FILTER: Query (if present)
            if (hasQuery) {
                if (isTickerMatch) {
                    bucketTickerStart.push(resultItem);
                } else if (isNameStartMatch) {
                    bucketNameStart.push(resultItem);
                } else if (isNameContainsMatch) {
                    bucketNameContains.push(resultItem);
                }
            } else {
                // If no query but whitelist exists, just add to a bucket (Scanner Mode)
                bucketTickerStart.push(resultItem);
            }
        }

        // Helper to sort by ticker alphabetically
        const sortByTicker = (a, b) => a.code.localeCompare(b.code);

        // Sort each bucket (Consistency)
        bucketTickerStart.sort(sortByTicker);
        bucketNameStart.sort(sortByTicker);
        bucketNameContains.sort(sortByTicker);

        // Merge and limit to 50
        return [
            ...bucketTickerStart,
            ...bucketNameStart,
            ...bucketNameContains
        ].slice(0, 50);
    }

    /**
     * Fetches historical price data.
     * Uses in-memory queue to stagger network requests (250ms gap) to avoid choking Google Apps Script.
     * @param {string} code 
     * @param {string} range '1y', '5y', 'max'
     * @param {boolean} silent - If true, suppresses toast notifications for background sparklines
     */
    async fetchHistory(code, range, silent = false) {
        // CACHE IMPLEMENTATION: Check localStorage first to save API quota
        const cacheKey = `${STORAGE_KEYS.HISTORY_CACHE_PREFIX}${code}_${range}`;
        const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours

        try {
            const cached = localStorage.getItem(cacheKey);
            if (cached) {
                const { timestamp, data } = JSON.parse(cached);
                if (Date.now() - timestamp < CACHE_DURATION) {
                    return data; // Return valid cached data instantly without queueing
                }
            }
        } catch (e) {
            console.warn('[DataService] Cache read error:', e);
        }

        // IN-FLIGHT DE-DUPE: identical concurrent requests share one network call
        const inflight = this._historyInflight.get(cacheKey);
        if (inflight) return inflight;

        // Queue Network Request with Staggering.
        // User-initiated (non-silent) requests jump ahead of silent background ones.
        const promise = new Promise((resolve) => {
            const entry = { code, range, silent, cacheKey, resolve };
            if (silent) this._historyQueue.push(entry);
            else this._historyQueue.unshift(entry);
            this._processHistoryQueue();
        }).finally(() => {
            this._historyInflight.delete(cacheKey);
        });
        this._historyInflight.set(cacheKey, promise);
        return promise;
    }

    async _processHistoryQueue() {
        if (this._isProcessingHistoryQueue) return;
        this._isProcessingHistoryQueue = true;

        try {
            while (this._historyQueue.length > 0) {
                const item = this._historyQueue.shift();
                try {
                    const res = await this._execFetchHistory(item.code, item.range, item.silent, item.cacheKey);
                    // FREE SEED: a successful 1y chart fetch also warms the slim sparkline cache
                    if (res && res.ok && item.range === SPARKLINE_CONFIG.RANGE && this.sparklineCache) {
                        this.sparklineCache.saveFromRows(item.code, res.data).catch(() => { });
                    }
                    item.resolve(res);
                } catch (err) {
                    item.resolve({ ok: false, error: err?.message || 'History fetch failed' });
                }

                // Stagger next network request by 250ms if queue remains non-empty
                if (this._historyQueue.length > 0) {
                    await new Promise(r => setTimeout(r, 250));
                }
            }
        } finally {
            this._isProcessingHistoryQueue = false;
        }
    }

    /**
     * @param {boolean} [persist=true] - If false, skips writing the legacy full-history localStorage cache.
     */
    async _execFetchHistory(code, range, silent, cacheKey, persist = true) {
        // RANGE HYGIENE: Yahoo Finance API expects 'mo' for months (1mo, 3mo, 6mo)
        const rangeMap = {
            '1m': '1mo',
            '3m': '3mo',
            '6m': '6mo'
        };
        const mappedRange = rangeMap[range] || range;

        // TIMEOUT PROTECTION (30 Seconds)
        const controller = new AbortController();
        let warningId = null;
        if (!silent) {
            warningId = setTimeout(() => {
                ToastManager.info("Loading stock history chart is taking longer than expected...", "Slow Connection");
            }, 18000);
        }
        const timeoutId = setTimeout(() => controller.abort(), 30000);

        try {
            const user = AuthService.getCurrentUser();
            const userId = user ? user.uid : null;

            if (!userId) {
                if (warningId) clearTimeout(warningId);
                clearTimeout(timeoutId);
                console.warn('DataService: fetchHistory called without logged-in user.');
                return { ok: false, error: 'User not logged in' };
            }

            const payload = {
                action: 'fetchHistory',
                userId: userId,
                code: code,
                range: mappedRange
            };

            const cleanBase = (this.API_ENDPOINT || API_ENDPOINT).replace(/\/+$/, '');
            const response = await fetch(cleanBase, {
                method: 'POST',
                mode: 'cors',
                redirect: 'follow',
                headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                body: JSON.stringify(payload),
                signal: controller.signal
            });

            if (warningId) clearTimeout(warningId);
            clearTimeout(timeoutId);

            if (!response.ok) {
                return { ok: false, error: `HTTP ${response.status}` };
            }

            const json = await response.json();

            // Cache successful valid responses only
            if (persist && cacheKey && json && json.ok && Array.isArray(json.data) && json.data.length > 0) {
                try {
                    localStorage.setItem(cacheKey, JSON.stringify({
                        timestamp: Date.now(),
                        data: json
                    }));
                } catch (e) {
                    if (e.name === 'QuotaExceededError') {
                        console.warn('[DataService] Cache full. Purging history keys...');
                        Object.keys(localStorage).forEach(key => {
                            if (key.startsWith('asx_history_')) localStorage.removeItem(key);
                        });
                        try { localStorage.setItem(cacheKey, JSON.stringify({ timestamp: Date.now(), data: json })); } catch (e2) { }
                    } else {
                        console.warn('[DataService] Cache write error:', e);
                    }
                }
            }

            return json;
        } catch (err) {
            if (warningId) clearTimeout(warningId);
            clearTimeout(timeoutId);
            if (err.name === 'AbortError') {
                console.warn("DataService: fetchHistory timed out (30s limit).");
            } else if (isNetworkError(err)) {
                console.warn('DataService: History Fetch network failure (Failed to fetch).');
                if (!silent) {
                    ToastManager.error("Network failure while loading stock history.", "Connection Error");
                }
            } else {
                console.error('DataService: History Fetch Exception:', err);
            }
            return { ok: false, error: err.message };
        }
    }

    _normalizePriceData(apiResponse) {
        const normalizedPrices = new Map();
        let dashboardData = [];

        // Handle case where response might be structured { prices, dashboard } or flat (backward compatibility)
        const items = apiResponse.prices || (Array.isArray(apiResponse) ? apiResponse : (apiResponse.data || []));
        dashboardData = apiResponse.dashboard || [];

        // RESILIENCE FIX: If dashboardData is missing/empty, auto-extract from the primary items list
        if (dashboardData.length === 0 && Array.isArray(items)) {
            dashboardData = items.filter(item => {
                const code = String(item.ASXCode || item.code || '').trim().toUpperCase();
                const type = String(item.Type || item.type || '').trim();

                // 1. Type-Based Detection (Most Accurate)
                if (['Index', 'Currency', 'Crypto', 'Commodity'].includes(type) || type === 'Index') {
                    return true;
                }

                return code.startsWith('^') ||
                    code.includes('.') ||
                    code.includes('=') ||
                    code === 'XJO' ||
                    code === 'XKO';
            }).map(item => ({
                ...item,
                code: String(item.ASXCode || item.code || '').trim().toUpperCase(),
                name: item.CompanyName || item.Name || item.companyName || item.name || String(item.ASXCode || item.code || '').trim().toUpperCase()
            }));
            if (dashboardData.length > 0) {
            }
        } else if (Array.isArray(dashboardData)) {
            // ROBUST MAPPING: Explicitly normalize keys for the UI to consume directly
            dashboardData = dashboardData.map(item => ({
                ...item,
                code: String(item.ASXCode || item.code || '').trim().toUpperCase(),
                name: item.name || item.CompanyName || item.Name || item.companyName || item.id || item.code || '',
                // CRITICAL FIX: Pass the price directly to the UI object so it doesn't rely solely on the Map
                live: parseFloat(item.LivePrice || item.live || 0),
                valueChange: parseFloat(item.Change || item.valueChange || 0),
                pctChange: parseFloat(item.PctChange || item.pctChange || 0)
            }));
        }

        // VERIFICATION: Log presence and count
        if (dashboardData.length > 0) {
            const sample = dashboardData[0];
        }

        if (!Array.isArray(items)) {
            console.warn("DataService: Unexpected API response format (missing prices array)", apiResponse);
            return { prices: normalizedPrices, dashboard: dashboardData };
        }

        if (items.length === 0 && dashboardData.length === 0) {
            console.warn("DataService: API returned completely empty data payload. This may indicate a temporary backend error.");
        }

        // Premarket Zeroing Logic: 
        // Between 7:00 AM and 10:00 AM (Pre-Open) Sydney time on trading days,
        // we show 0.00% change by treating Yesterday's Price as the baseline.
        const shouldZero = MarketSchedule.getASXStatus().session === ASX_SESSION.PRE_OPEN;
        const overallServerTime = apiResponse.timestamp || apiResponse.serverTime || apiResponse.updatedAt || null;

        items.forEach(item => {
            // ROBUST KEY LOOKUP: Support both ASXCode (API Standard) and code (Normalized)
            const code = String(item.ASXCode || item.code || '').trim().toUpperCase();

            // Skip invalid entries after normalization
            if (!code || code === 'UNDEFINED') return;

            const rawLive = parseFloat(item.LivePrice ?? item.live ?? item.price ?? item.last ?? 0);
            const rawPrevClose = parseFloat(item.PrevClose ?? item.prevClose ?? item.close ?? item.previousClose ?? 0);

            const isRawLiveValid = !isNaN(rawLive) && rawLive > 0;
            const isRawPrevValid = !isNaN(rawPrevClose) && rawPrevClose > 0;

            // OUT-OF-MARKET FALLBACK:
            // If live price is missing or 0 (common when market is closed or no trades yet),
            // safely fallback to previous close price so portfolio valuation never collapses to $0.
            let live = isRawLiveValid ? rawLive : (isRawPrevValid ? rawPrevClose : 0);
            let prevClose = isRawPrevValid ? rawPrevClose : (isRawLiveValid ? rawLive : 0);

            // APPLIED PRE-MARKET ZEROING: 
            // Between 7:00 AM and 10:00 AM (Pre-Open) Sydney time on trading days,
            // we show 0.00% change by treating Yesterday's Price as the baseline.
            // EXEMPTION: Dashboard assets (Indices, Crypto, Currencies, Commodities) should NOT be zeroed,
            // as they often trade 24/7 or have different hours.
            const type = item.Type || item.type || 'Share';
            const isDashboard = ['Index', 'Currency', 'Crypto', 'Commodity'].includes(type);

            if (shouldZero && live > 0 && !isDashboard) {
                prevClose = live;
            }

            // Ensure numbers are valid
            const isLiveValid = !isNaN(live) && live > 0;
            const isPrevValid = !isNaN(prevClose) && prevClose > 0;

            // Calculate change if possible
            let change = 0;
            let pctChange = 0;

            if (isLiveValid && isPrevValid && prevClose > 0) {
                // If live was defaulted to prevClose (out-of-hours no trade), change is strictly 0
                if (!isRawLiveValid && isRawPrevValid) {
                    change = 0;
                    pctChange = 0;
                } else {
                    change = live - prevClose;
                    pctChange = (change / prevClose) * 100;
                }
            }

            // Upstream quote timestamp if supplied
            const quoteTime = item.timestamp || item.lastTradeTime || item.quoteTime || item.date || overallServerTime || null;

            // Set the map key using the strictly normalized code
            normalizedPrices.set(code, {
                code: code,
                name: item.name || item.CompanyName || item.companyName || '',
                live: isLiveValid ? live : 0,
                prevClose: isPrevValid ? prevClose : 0,
                high: parseFloat(item.H52 || item.High52 || item.high52 || item.high_52 || item.high || 0),
                low: parseFloat(item.L52 || item.Low52 || item.low52 || item.low_52 || item.low || 0),
                pe: parseFloat(item.PE || item.pe || 0),
                volume: parseInt(item.Volume || 0),
                change: change,
                pctChange: pctChange,
                sector: item.Sector || item.sector || '',
                industry: item.Industry || item.industry || '',
                type: item.Type || item.type || 'Share',
                quoteTime: quoteTime,
                lastUpdate: Date.now()
            });
        });

        return { prices: normalizedPrices, dashboard: dashboardData, serverTimestamp: overallServerTime, fetchTimestamp: Date.now() };
    }
}
