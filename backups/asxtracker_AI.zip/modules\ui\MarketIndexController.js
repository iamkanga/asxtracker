import { notificationStore } from '../state/NotificationStore.js';
import { EVENTS } from '../utils/AppConstants.js';
import { navManager } from '../utils/NavigationManager.js';
import { LinkHelper } from '../utils/LinkHelper.js';
import { ToastManager } from './ToastManager.js';
import { SwipeGestureHelper } from '../utils/SwipeGestureHelper.js';

export class MarketIndexController {
    constructor() {
        // Defer binding slightly to ensure DOM is ready
        setTimeout(() => this.init(), 100);
    }

    init() {
        this.modal = document.getElementById('modal-market-stream');
        this.sidebarBtn = document.getElementById('sidebar-market-stream-btn');
        this.listContainer = document.getElementById('market-stream-list');
        this.closeBtn = this.modal?.querySelector('.modal-close-btn');

        if (!this.modal) {
            console.warn('[MarketIndexController] Modal missing. Retrying...');
            setTimeout(() => this.init(), 500); // Retry
            return;
        }

        // Prevent duplicate initialization
        if (this._initialized) return;
        this._initialized = true;

        // Sidebar button is optional as it may be rendered dynamically by SidebarCommandCenter
        if (!this.sidebarBtn) {
            // Keep checking for sidebarBtn but don't block
            setTimeout(() => {
                this.sidebarBtn = document.getElementById('sidebar-market-stream-btn') || document.getElementById('nav-announcements');
                if (this.sidebarBtn) this.sidebarBtn.addEventListener('click', () => this.openModal());
            }, 1000);
        }
        this.bindEvents();
    }

    bindEvents() {
        // Bind Events
        this.sidebarBtn?.addEventListener('click', () => this.openModal());
        this.closeBtn?.addEventListener('click', () => this.closeModal());

        // Close on overlay click
        this.modal.querySelector('.modal-overlay')?.addEventListener('click', () => this.closeModal());

        // Listen for Data Updates (New Alerts)
        document.addEventListener(EVENTS.MARKET_INDEX_UPDATED, (e) => {
            if (!this.modal.classList.contains('hidden')) {
                this.render(e.detail.alerts);
            }
        });

        // Listen for State Updates (Mark as Read / Sync)
        document.addEventListener(EVENTS.NOTIFICATION_UPDATE, () => {
            // Update read/unread classes in place instead of full re-render
            // This prevents destroying the DOM elements while the user is interacting with them!
            if (this.modal && !this.modal.classList.contains('hidden') && this.listContainer) {
                const wrappers = this.listContainer.querySelectorAll('.market-stream-item-wrapper');
                wrappers.forEach(wrapper => {
                    const id = wrapper.getAttribute('data-alert-id');
                    if (id) {
                        const bodyLink = wrapper.querySelector('.market-stream-item');
                        const pillsContainer = wrapper.querySelector('.market-stream-pills');
                        const leftUnderlay = wrapper.querySelector('.unread-underlay');
                        if (notificationStore.readAnnouncements.has(id)) {
                            wrapper.classList.add('is-read');
                            if (bodyLink) {
                                bodyLink.style.opacity = '0.35';
                                bodyLink.style.filter = 'grayscale(80%)';
                            }
                            if (pillsContainer) {
                                pillsContainer.style.opacity = '0.35';
                                pillsContainer.style.filter = 'grayscale(80%)';
                            }
                            if (leftUnderlay) {
                                leftUnderlay.innerHTML = `
                                    <span>Mark Unread</span>
                                    <i class="fas fa-envelope-open"></i>
                                `;
                            }
                        } else {
                            wrapper.classList.remove('is-read');
                            if (bodyLink) {
                                bodyLink.style.opacity = '';
                                bodyLink.style.filter = '';
                            }
                            if (pillsContainer) {
                                pillsContainer.style.opacity = '';
                                pillsContainer.style.filter = '';
                            }
                            if (leftUnderlay) {
                                leftUnderlay.innerHTML = `
                                    <span>Mark Read</span>
                                    <i class="fas fa-envelope"></i>
                                `;
                            }
                        }
                    }
                });
            }
        });

        // Clear All Logic
        document.getElementById('stream-clear-all')?.addEventListener('click', () => this.dismissAll());
    }

    /**
     * Internal helper to mark an announcement as read and update UI.
     */
    markAsRead(alertId, wrapperElement) {
        if (!alertId) return;

        // Persist to Store if not already there
        if (!notificationStore.readAnnouncements.has(alertId)) {
            notificationStore.markAnnouncementRead(alertId);
        }

        // Immediate Visual Feedback (Direct & Class-based)
        if (wrapperElement) {
            wrapperElement.classList.add('is-read');
            const bodyLink = wrapperElement.querySelector('.market-stream-item');
            const pillsContainer = wrapperElement.querySelector('.market-stream-pills');
            const leftUnderlay = wrapperElement.querySelector('.unread-underlay');
            if (bodyLink) {
                bodyLink.style.opacity = '0.35';
                bodyLink.style.filter = 'grayscale(80%)';
            }
            if (pillsContainer) {
                pillsContainer.style.opacity = '0.35';
                pillsContainer.style.filter = 'grayscale(80%)';
            }
            if (leftUnderlay) {
                leftUnderlay.innerHTML = `
                    <span>Mark Unread</span>
                    <i class="fas fa-envelope-open"></i>
                `;
            }
            const dismissBtn = wrapperElement.querySelector('.stream-dismiss-btn');
            if (dismissBtn) {
                // User Request: Keep dismiss button at full strength even when ghosted
                dismissBtn.style.opacity = '1';
            }
        }
    }

    openModal(targetId = null, targetSymbol = null) {
        if (!this.modal) return Promise.resolve(false);

        // v1149: Prevent double-opening if already visible
        if (!this.modal.classList.contains('hidden')) return Promise.resolve(false);

        // Ensure initially hidden for animation clarity
        // v2.3 Animation: Reset before showing
        this.modal.classList.add('hidden');
        this.modal.classList.remove('show');
        
        // Optimized Transition (v1149: Remove nested rAF)
        this.modal.classList.remove('hidden');
        void this.modal.offsetWidth; // Force Reflow
        this.modal.classList.add('show');
        document.body.style.overflow = 'hidden';

        // v1156: Re-render with symbol filter if provided from a generic deep link
        const alerts = notificationStore.getMarketIndexAlerts();
        const filtered = targetSymbol 
            ? alerts.filter(a => (a.code || '').replace(/.*[:]/, '').trim().toUpperCase() === targetSymbol)
            : alerts;
        this.render(filtered);

        // Register with NavigationManager for Back Button support
        navManager.pushState(() => {
            if (this.modal && !this.modal.classList.contains('hidden')) {
                this.closeModal(true);
            }
        });

        // v1153: Deep Link Targeting - Scroll to specific announcement
        if (targetId) {
            console.log(`[MarketIndexController] Searching for deep link target: ${targetId}`);
            
            return new Promise((resolve) => {
                const attemptScroll = (retryCount = 0) => {
                    const element = this.listContainer.querySelector(`.market-stream-item-wrapper[data-alert-id="${targetId}"]`);
                    if (element) {
                        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        element.classList.add('pulse-highlight');
                        // Remove highlight class after animation finishes
                        setTimeout(() => element.classList.remove('pulse-highlight'), 3000);
                        console.log(`[MarketIndexController] Successfully targeted ${targetId}`);
                        resolve(true); // Success
                    } else if (retryCount < 3) {
                        // v1153: Retry if not found immediately (data might still be rendering)
                        console.log(`[MarketIndexController] Target ${targetId} not found, retrying... (${retryCount + 1})`);
                        setTimeout(() => attemptScroll(retryCount + 1), 600);
                    } else {
                        console.warn(`[MarketIndexController] Deep link target ${targetId} not found after retries.`);
                        resolve(false); // Failure
                    }
                };
                
                // v1156: Reduced initial delay for better perceived performance
                setTimeout(() => attemptScroll(), 500);
            });
        }

        return Promise.resolve(true); // No targetId, so open is successful by default
    }

    closeModal(fromNav = false) {
        if (!this.modal || this.modal.classList.contains('hidden')) return;

        this.modal.classList.remove('show');
        document.body.style.overflow = '';

        setTimeout(() => {
            if (!this.modal.classList.contains('show')) {
                this.modal.classList.add('hidden');
            }
        }, 450);

        // If closed via UI (X button) instead of Back Button, sync the browser history
        if (!fromNav) {
            navManager.popStateSilently();
        }
    }

    dismissAlert(alertId) {
        if (!alertId) return;
        notificationStore.dismissAnnouncement(alertId);

        const element = this.listContainer.querySelector(`.market-stream-item-wrapper[data-alert-id="${alertId}"]`);
        if (element) {
            element.style.transform = 'translateX(100%)';
            element.style.opacity = '0';
            setTimeout(() => this.render(notificationStore.getMarketIndexAlerts()), 300);
        }
    }

    dismissAll() {
        notificationStore.dismissAllAnnouncements();
        this.render([]); // Immediate empty state
    }

    render(alerts) {
        if (!this.listContainer) return;

        // Filter out dismissed items
        const rawAlerts = alerts || [];
        const visibleAlerts = rawAlerts.filter(a => !notificationStore.dismissedAnnouncements.has(a.id || `${a.code}-${a.timestamp}`));

        console.log(`[MarketIndexController] Rendering: ${visibleAlerts.length} visible / ${rawAlerts.length} total. (${rawAlerts.length - visibleAlerts.length} filtered)`);

        if (visibleAlerts.length === 0) {
            this.listContainer.innerHTML = `
                <div class="empty-state" style="padding: 40px; text-align: center; color: var(--text-muted);">
                    <i class="fas fa-satellite-dish" style="font-size: 24px; margin-bottom: 10px;"></i>
                    <p>No recent announcement data.</p>
                    ${rawAlerts.length > 0 ? `
                        <button id="reset-market-ui-btn" style="margin-top: 15px; padding: 8px 16px; border-radius: 6px; background: rgba(255,255,255,0.1); color: white; border: 1px solid rgba(255,255,255,0.2); cursor: pointer;">
                            Show ${rawAlerts.length} Hidden Items
                        </button>
                    ` : ''}
                </div>`;
            
            const resetBtn = this.listContainer.querySelector('#reset-market-ui-btn');
            if (resetBtn) {
                resetBtn.onclick = () => {
                    notificationStore.resetDismissedAnnouncements();
                    ToastManager.info('Market Index view reset.');
                };
            }
            return;
        }

        const html = visibleAlerts.map(alert => {
            const id = alert.id || `${alert.code}-${alert.timestamp}`;
            const date = new Date(alert.timestamp);
            let dateStr = '';
            if (!isNaN(date.getTime())) {
                const now = new Date();
                const isToday = date.toDateString() === now.toDateString();
                dateStr = isToday ? date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                    : date.toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
            }

            // Extract ASX Code from Title if the provided code is missing, UNKNOWN, or just generic 'ASX'
            let extractedCode = alert.code;
            if ((!extractedCode || extractedCode === 'UNKNOWN' || extractedCode === 'ASX' || extractedCode === 'MARKET') && (alert.title || alert.headline)) {
                const text = alert.title || alert.headline;
                const match = text.match(/^\[?([A-Z]{3,4})\]?\b/);
                if (match) extractedCode = match[1];
            }

            const isCompany = extractedCode && extractedCode !== 'UNKNOWN' && extractedCode !== 'ASX' && extractedCode !== 'MARKET';
            const badgeClass = isCompany ? 'badge-company' : 'badge-report';
            const badgeText = isCompany ? extractedCode : 'MARKET';

            // v1153: Ensure we prefer the direct announcement document link if available
            // If the link is generic (e.g. only company profile), and we have an ID like 6A...,
            // we should technically have gotten a better link from the backend, but we'll trust alert.link first.
            const href = alert.link || alert.url || '#';
            const target = (href && href !== '#') ? '_blank' : '_self';

            const isRead = notificationStore.readAnnouncements?.has(id);
            const readClass = isRead ? 'is-read' : '';
            const readStyle1 = isRead ? 'opacity: 0.35; filter: grayscale(80%);' : '';
            // User Request: Keep dismiss button at full strength at all times
            const readStyle2 = 'opacity: 1;';
            const leftUnderlayText = isRead ? 'Mark Unread' : 'Mark Read';
            const leftUnderlayIcon = isRead ? 'fa-envelope-open' : 'fa-envelope';

            return `
                <div class="market-stream-item-wrapper ${readClass}" data-alert-id="${id}">
                    <!-- Underlay revealed on Swipe Right (Delete) -->
                    <div class="swipe-underlay delete-underlay">
                        <i class="fas fa-trash-alt"></i>
                        <span>Delete</span>
                    </div>
                    <!-- Underlay revealed on Swipe Left (Mark Toggle) -->
                    <div class="swipe-underlay unread-underlay">
                        <span>${leftUnderlayText}</span>
                        <i class="fas ${leftUnderlayIcon}"></i>
                    </div>
                    
                    <!-- Swipe content wrapper containing card content -->
                    <div class="swipe-content">
                        <a href="${href}" target="${target}" class="market-stream-item" style="${readStyle1}">
                            <div class="stream-meta">
                                <span class="stream-badge ${badgeClass}">${badgeText}</span>
                                <span class="stream-time">${dateStr}</span>
                            </div>
                            <div class="stream-title" style="color: var(--text-color);">${alert.title || alert.headline}</div>
                            ${alert.summary ? `<div class="stream-summary" style="margin-top: 5px;">${alert.summary}</div>` : ''}
                        </a>
                        
                        <div class="market-stream-pills" style="display: flex; align-items: center; height: 38px; padding: 0 16px 10px 16px; box-sizing: border-box; z-index: 10; ${readStyle1}">
                            ${isCompany ? `
                            <button class="code-pill" data-code="${extractedCode}" style="border: 1px solid rgba(var(--color-accent-rgb, 100, 150, 255), 0.4); border-radius: 4px; background: rgba(30, 30, 30, 0.9); color: var(--color-accent, #6496ff); padding: 0 10px; height: 26px; font-size: 0.75rem; cursor: pointer; font-weight: 600; display: inline-flex; align-items: center; justify-content: center; gap: 4px; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.2); box-sizing: border-box; margin-right: 8px; line-height: 1;" title="View ${extractedCode} Details">
                                <i class="fas fa-search-dollar" style="vertical-align: middle;"></i> View ${extractedCode}
                            </button>
                            <button class="analysis-pill" data-url="${href}" data-code="${extractedCode}" data-headline="${(alert.title || alert.headline || '').replace(/"/g, '&quot;')}" style="border: 1px solid rgba(var(--color-accent-rgb, 100, 150, 255), 0.4); border-radius: 4px; background: rgba(30, 30, 30, 0.9); color: var(--color-accent, #6496ff); padding: 0 10px; height: 26px; font-size: 0.75rem; cursor: pointer; font-weight: 600; display: inline-flex; align-items: center; justify-content: center; gap: 4px; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.2); box-sizing: border-box; line-height: 1;" title="Analyze Announcement">
                                <i class="fas fa-robot" style="vertical-align: middle;"></i> Analyze
                            </button>
                            ` : ''}
                            
                            <div style="flex: 1;"></div>
                            
                            <button class="announcement-pill" style="border: 1px solid rgba(var(--color-accent-rgb, 100, 150, 255), 0.4); border-radius: 4px; background: rgba(30, 30, 30, 0.9); color: var(--color-accent, #6496ff); padding: 0 10px; height: 26px; font-size: 0.75rem; cursor: pointer; font-weight: 600; display: inline-flex; align-items: center; justify-content: center; gap: 4px; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.2); box-sizing: border-box; line-height: 1;" title="Source Document">
                                <i class="fas fa-satellite-dish" style="vertical-align: middle;"></i> Announcement
                            </button>
                        </div>
                        <button class="stream-dismiss-btn" data-id="${id}" title="Dismiss"
                            style="position: absolute; top: 0; right: 0; background: transparent; border: none; color: var(--text-color); cursor: pointer; z-index: 15; transition: opacity 0.2s, transform 0.2s; ${readStyle2}">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            `;
        }).join('');

        this.listContainer.innerHTML = html;

        // --- BULLETPROOF TAP & NAVIGATION BINDINGS ---
        // We use direct bindings here using a Smart Tap strategy (Touch + Distance)
        // to deliver instant feedback WITHOUT breaking native iOS/PWA link behavior.
        const wrappers = this.listContainer.querySelectorAll('.market-stream-item-wrapper');
        wrappers.forEach(wrapper => {
            const alertId = wrapper.getAttribute('data-alert-id');
            const link = wrapper.querySelector('.market-stream-item');
            const codePill = wrapper.querySelector('.code-pill');
            const analysisPill = wrapper.querySelector('.analysis-pill');
            const announcementPill = wrapper.querySelector('.announcement-pill');
            const dismissBtn = wrapper.querySelector('.stream-dismiss-btn');

            // Initialize Swipe Gestures
            new SwipeGestureHelper(wrapper, {
                threshold: 100,
                onSwipeRight: () => {
                    this.dismissAlert(alertId);
                },
                onSwipeLeft: () => {
                    if (notificationStore.readAnnouncements.has(alertId)) {
                        notificationStore.markAnnouncementUnread(alertId);
                    } else {
                        notificationStore.markAnnouncementRead(alertId);
                    }
                }
            });

            // 1. SMART TAP (Link Ghosting)
            if (link) {
                let startX = 0, startY = 0;
                let isScrolling = false;

                const handleTouchStart = (e) => {
                    if (e.target.closest('.code-pill') || e.target.closest('.analysis-pill') || e.target.closest('.announcement-pill') || e.target.closest('.stream-dismiss-btn')) return;
                    isScrolling = false;
                    startX = e.touches ? e.touches[0].clientX : e.clientX;
                    startY = e.touches ? e.touches[0].clientY : e.clientY;
                };

                const handleTouchEnd = (e) => {
                    if (e.target.closest('.code-pill') || e.target.closest('.analysis-pill') || e.target.closest('.stream-dismiss-btn')) return;
                    if (isScrolling) return;

                    const endX = e.changedTouches ? e.changedTouches[0].clientX : e.clientX;
                    const endY = e.changedTouches ? e.changedTouches[0].clientY : e.clientY;

                    // If finger moved more than 15px, it's a scroll or swipe, NOT a tap.
                    if (Math.abs(endX - startX) > 15 || Math.abs(endY - startY) > 15) {
                        return;
                    }

                    // 👉 DELIBERATE TAP DETECTED 👈
                    // Update visual state instantly.
                    // Because we do this on touchend (before the synthesized click), the browser 
                    // will paint the ghosting state correctly before the native tab transition occurs.
                    this.markAsRead(alertId, wrapper);
                };

                // Bind Touch (Mobile) and Mouse fallback (Desktop)
                link.addEventListener('touchstart', handleTouchStart, { passive: true });
                link.addEventListener('touchmove', () => { isScrolling = true; }, { passive: true });
                link.addEventListener('touchend', handleTouchEnd);

                // Desktop fallback for visual feedback
                link.addEventListener('mousedown', handleTouchStart);
                link.addEventListener('mouseup', handleTouchEnd);

                // We leave the native 'click' event completely ALONE.
                // We do NOT call preventDefault(). The browser naturally sees the <a target="_blank"> 
                // and executes the safest, most trusted new-tab intent possible.
            }

            // 2. VIEW ASX BUTTON
            if (codePill) {
                codePill.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    const code = codePill.dataset.code;
                    if (code) document.dispatchEvent(new CustomEvent(EVENTS.ASX_CODE_CLICK, { detail: { code } }));
                });
            }

            // 3. ANALYSIS BUTTON
            if (analysisPill) {
                analysisPill.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Mark as read (Ghosting effect)
                    this.markAsRead(alertId, wrapper);

                    let url = analysisPill.dataset.url || '';
                    const code = analysisPill.dataset.code || '';
                    const rawHeadline = analysisPill.dataset.headline || '';

                    // Fallback normalization: resolve any residual tracking redirect URLs
                    if (url.includes('click.mail.marketindex') || url.includes('mandrillapp.com') || url.includes('/track/click')) {
                        if (code && code !== 'UNKNOWN' && code !== 'MARKET' && code !== 'ASX') {
                            url = `https://www.marketindex.com.au/asx/${code.toLowerCase()}/announcements`;
                        }
                    }

                    // Build rich, self-contained prompt context for Gemini
                    let promptContext = '';
                    if (rawHeadline && code) {
                        promptContext = `the recent announcement "${rawHeadline}" for ${code} (ASX: ${code})`;
                    } else if (code) {
                        promptContext = `the latest announcement for ${code} (ASX: ${code})`;
                    } else if (rawHeadline) {
                        promptContext = `this announcement: "${rawHeadline}"`;
                    } else {
                        promptContext = 'this announcement';
                    }

                    const textPayload = `Summarize ${promptContext} in a couple of sentences and tell me the likely effect on the share price making sure you highlight any key points: ${url}`;
                    
                    if (navigator.share) {
                        navigator.share({
                            text: textPayload
                        }).catch(err => {
                            if (err.name !== 'AbortError') {
                                console.warn('[MarketIndexController] Share failed:', err);
                            }
                        });
                    } else {
                        // Fallback: Copy to clipboard
                        navigator.clipboard.writeText(textPayload).then(() => {
                            if (window.ToastManager) window.ToastManager.success('Analysis prompt copied to clipboard!');
                            else if (ToastManager) ToastManager.success('Analysis prompt copied to clipboard!');
                        }).catch(err => {
                            console.error('Clipboard copy failed', err);
                        });
                    }
                });
            }

            // 4. ANNOUNCEMENT BUTTON
            if (announcementPill) {
                announcementPill.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();

                    // Mark as read (Ghosting effect)
                    this.markAsRead(alertId, wrapper);

                    const docUrl = link?.getAttribute('href');
                    if (docUrl && docUrl !== '#') window.open(docUrl, '_blank');
                });
            }

            // 5. DISMISS BUTTON
            if (dismissBtn) {
                dismissBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.dismissAlert(alertId);
                });
            }
        });
    }

}

// Singleton for easy import in main.js
export const marketIndexController = new MarketIndexController();
