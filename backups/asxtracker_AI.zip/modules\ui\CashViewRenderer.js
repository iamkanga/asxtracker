/**
 * CashViewRenderer.js
 * Responsible for rendering the Cash & Assets view HTML.
 * Strictly checks for CSS classes from AppConstants.
 */
import { CASH_CATEGORIES, CSS_CLASSES, UI_ICONS, EVENTS, ASSET_CUSTOM_COLORS } from '../utils/AppConstants.js';
import { formatCurrency } from '../utils/formatters.js';
import { convertAssetToAud, formatBaht, getAudThbRate } from '../utils/CurrencyHelper.js';
import { AppState } from '../state/AppState.js';
import { CashPieChart } from './CashPieChart.js';

function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

export class CashViewRenderer {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
    }

    /**
     * Renders the full Cash View: Total Header + Asset List.
     * @param {Array} assets - List of cash asset objects.
     * @param {Number} totalValue - Calculated total value of all assets.
     * @param {Boolean} isLoaded - Whether initial data load is complete. Defaults to false (show loading).
     */
    renderCashView(assets, totalValue, isLoaded = false) {
        if (!this.container) return;



        this.container.innerHTML = '';
        this.container.classList.remove(CSS_CLASSES.VIEW_TABLE, CSS_CLASSES.VIEW_COMPACT, CSS_CLASSES.VIEW_SNAPSHOT); // Clear potentially conflicting classes
        this.container.classList.remove(CSS_CLASSES.HIDDEN); // Redundant if cleared, but safe

        // 1. Render Total Header
        const header = this.createTotalHeader(totalValue, assets);
        this.container.appendChild(header);

        // 2. Render List Container
        const listContainer = document.createElement('div');
        listContainer.className = CSS_CLASSES.CASH_CONTAINER; // 'cash-container'

        // Apply Column Views based on AppState.viewMode
        const mode = (AppState.viewMode || 'TABLE').toUpperCase();
        if (mode === 'COMPACT') {
            listContainer.classList.add(CSS_CLASSES.CASH_VIEW_TWO_COLUMN);
        } else if (mode === 'SNAPSHOT') {
            listContainer.classList.add(CSS_CLASSES.CASH_VIEW_THREE_COLUMN);
        } else {
            listContainer.classList.add(CSS_CLASSES.CASH_VIEW_SINGLE);
        }

        if (assets.length === 0) {
            if (!isLoaded) {
                // STATE: Loading - show skeleton/spinner, NOT "No assets"
                listContainer.innerHTML = `
                    <div class="${CSS_CLASSES.EMPTY_STATE}" style="min-height: 100px;">
                        <i class="fas ${UI_ICONS.SPINNER}" style="font-size: 1.5rem; color: var(--text-muted);"></i>
                    </div>
                `;
            } else {
                // STATE: Loaded and genuinely empty (Premium Design)
                listContainer.innerHTML = `
                <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 50vh; text-align: center; padding: 20px;">
                    <div style="width: 80px; height: 80px; background: rgba(255,255,255,0.03); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 24px;">
                        <i class="fas ${UI_ICONS.WALLET}" style="font-size: 28px; color: var(--text-muted); opacity: 0.5;"></i>
                    </div>
                    <h2 class="${CSS_CLASSES.DISPLAY_TITLE}" style="font-size: 1.5rem; margin-bottom: 12px; color: var(--text-shimmer);">No Cash Assets</h2>
                    <p style="color: var(--text-muted); font-size: 1rem; max-width: 300px; line-height: 1.5; margin-bottom: 32px;">
                        Track your bank accounts, property, crypto, and other assets here.
                    </p>
                    <div style="display: flex; align-items: center; gap: 12px; padding: 12px 24px; background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: 30px; font-size: 0.9rem; color: var(--color-accent); font-weight: 600;">
                        <i class="fas fa-arrow-left"></i>
                        <span>Open Sidebar to Add Asset</span>
                    </div>
                </div>
                `;
            }
        } else {
            assets.forEach(asset => {
                const card = this.createCashCard(asset);
                listContainer.appendChild(card);
            });
        }

        this.container.appendChild(listContainer);
    }

    /**
     * Creates the Total Cash Header element.
     * @param {Number} totalValue 
     * @param {Array} assets
     * @returns {HTMLElement}
     */
    createTotalHeader(totalValue, assets = []) {
        const headerDiv = document.createElement('div');
        headerDiv.className = CSS_CLASSES.CASH_TOTAL_HEADER;

        const stripThickness = 9;
        const baseCardHeight = 70;

        // Overlay & Layout
        headerDiv.innerHTML = `
            <!-- Gloss Overlay -->
            <div style="position: absolute; top: 0; left: 0; width: 100%; height: 50%; background: linear-gradient(to bottom, rgba(255,255,255,0.05), transparent); pointer-events: none;"></div>
            
            <div class="cash-dna-container" style="position: absolute; top: 0; left: 0; height: ${stripThickness}px; width: 100%; border-bottom: 1px solid rgba(255,255,255,0.1); z-index: 5;"></div>
            
            <div style="display: flex; flex-direction: column; justify-content: center; align-items: center; width: 100%; height: 100%; z-index: 1;">
                <span class="cash-total-label" style="margin: 0 0 2px 0; text-transform: uppercase; font-size: 0.6rem; letter-spacing: 1px; opacity: 0.8; font-weight: 600;">Assets Value</span>
                <span class="cash-total-amount" style="font-size: 1.3rem; line-height: 1; font-weight: 800;">${formatCurrency(totalValue)}</span>
            </div>
        `;

        // Apply Card-like Styles to Header
        headerDiv.style.position = 'relative';
        headerDiv.style.padding = `${10 + stripThickness}px 20px 6px`;
        headerDiv.style.minHeight = `${baseCardHeight}px`;
        headerDiv.style.maxHeight = `${baseCardHeight}px`;
        headerDiv.style.display = 'flex';
        headerDiv.style.flexDirection = 'column';
        headerDiv.style.justifyContent = 'center';
        headerDiv.style.alignItems = 'center';
        headerDiv.style.cursor = 'pointer';
        headerDiv.style.transition = 'transform 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275)';

        // Hover Effect
        headerDiv.addEventListener('mouseenter', () => headerDiv.style.transform = 'scale(1.02)');
        headerDiv.addEventListener('mouseleave', () => headerDiv.style.transform = 'scale(1)');

        // Tap for Modal
        const pie = new CashPieChart(assets);
        headerDiv.addEventListener('click', () => pie.showModal());

        // Inject DNA Strip
        const dnaContainer = headerDiv.querySelector('.cash-dna-container');
        if (dnaContainer && assets.length > 0) {
            pie.renderDnaStrip(dnaContainer, stripThickness);
        }

        return headerDiv;
    }

    /**
     * Creates a single Cash Asset Card.
     * @param {Object} asset 
     * @returns {HTMLElement}
     */
    createCashCard(asset) {
        const card = document.createElement('div');
        card.className = CSS_CLASSES.CASH_CARD; // 'cash-card'

        // Apply Side Border & Background based on Category
        let colorVal = 'var(--asset-other)'; // Default

        if (asset.category) {
            // 1. PRIORITY: User Category Theme (Global override)
            const userCat = (AppState.preferences.userCategories || []).find(c => c && c.id === asset.category);

            if (userCat && userCat.color) {
                colorVal = userCat.color;
            } else if (asset.color) {
                // 2. FALLBACK: Explicit Asset Color
                colorVal = asset.color;
            } else {
                // 3. FALLBACK: Standard CSS Vars
                const standardColors = {
                    'cash': 'var(--asset-cash)',
                    'cash_in_bank': 'var(--asset-cash-in-bank)',
                    'term_deposit': 'var(--asset-term-deposit)',
                    'property': 'var(--asset-property)',
                    'crypto': 'var(--asset-crypto)',
                    'shares': 'var(--asset-shares)',
                    'super': 'var(--asset-super)',
                    'personal': 'var(--asset-personal)',
                    'other': 'var(--asset-other)'
                };

                if (standardColors[asset.category]) {
                    colorVal = standardColors[asset.category];
                } else if (asset.category === 'other' && asset.name) {
                    colorVal = this._getColorForString(asset.name);
                }
            }
        } else if (asset.color) {
            colorVal = asset.color;
        }

        // Apply Styles
        // Dynamic "Hue on Black" Background Effect
        const borderStyle = this._getBorderStyles(colorVal);
        card.setAttribute('style', `${borderStyle} background: linear-gradient(135deg, color-mix(in srgb, ${colorVal} 60%, black), color-mix(in srgb, ${colorVal} 5%, black)) !important;`);

        // Handle Ghosting
        if (asset.isHidden) {
            card.classList.add(CSS_CLASSES.GHOSTED);
            card.style.opacity = '0.5';
        } else {
            card.style.opacity = '1';
        }

        // --- CONTENT GRID ---
        const hasComments = Array.isArray(asset.comments) && asset.comments.length > 0;
        const catObj = [...(CASH_CATEGORIES || []), ...(AppState.preferences.userCategories || [])]
            .filter(c => c && c.id)
            .find(c => c.id === asset.category);

        const isThb = (asset.currency || '').toUpperCase() === 'THB';
        const rate = isThb ? getAudThbRate() : 1;
        const audVal = isThb ? convertAssetToAud(asset, rate) : (parseFloat(asset.balance) || 0);

        card.innerHTML = `
            <div class="cash-grid-category">
                ${escapeHtml((catObj ? catObj.label : (asset.category || 'Cash').replace(/^user_/i, '').replace(/_/g, ' ')).toUpperCase())}
                ${isThb ? `<span class="cash-currency-badge" style="display: inline-flex; align-items: center; gap: 3px; font-size: 0.65rem; padding: 1px 6px; border-radius: 4px; background: rgba(16, 185, 129, 0.15); color: var(--color-accent, #10b981); border: 1px solid rgba(16, 185, 129, 0.3); vertical-align: middle; margin-left: 6px; font-weight: 700; text-transform: none; letter-spacing: 0;">🇹🇭 THB</span>` : ''}
                ${hasComments ? `<i class="fas ${UI_ICONS.COMMENTS} cash-comment-indicator" style="font-size: 10px; opacity: 0.4; margin-left: 6px;" title="Comments available"></i>` : ''}
            </div>
            <div class="cash-grid-name">
                ${escapeHtml(asset.name)}
            </div>
            <div class="cash-grid-balance ${asset.balance > 0 ? CSS_CLASSES.CASH_VALUE_POSITIVE : asset.balance < 0 ? CSS_CLASSES.CASH_VALUE_NEGATIVE : ''}" 
                 style="${asset.balance === 0 ? 'color: var(--color-accent);' : ''}">
                ${isThb ? `
                    <span>${formatBaht(asset.balance)}</span>
                    <div class="cash-sub-conversion" style="font-size: 0.75rem; font-weight: 600; opacity: 0.85; color: var(--text-muted); line-height: 1.1; margin-top: 2px;">
                        ≈ ${formatCurrency(audVal)} <span style="font-size: 0.68rem; opacity: 0.75;">(1 AUD = ${rate.toFixed(2)} ฿)</span>
                    </div>
                ` : `
                    ${formatCurrency(asset.balance)}
                `}
            </div>
            <div class="cash-grid-actions">
                <button class="${CSS_CLASSES.ICON_BTN_GHOST} ${CSS_CLASSES.CASH_EYE_BTN}" title="${asset.isHidden ? "Show Asset" : "Hide Asset"}">
                    <i class="fas ${asset.isHidden ? UI_ICONS.EYE_SLASH : UI_ICONS.EYE}"></i>
                </button>
            </div>
        `;
        if (asset.category === 'other') {
        }

        // Eye Button Event
        card.querySelector(`.${CSS_CLASSES.CASH_EYE_BTN}`).addEventListener('click', (e) => {
            e.stopPropagation();
            const event = new CustomEvent(EVENTS.CASH_ASSET_TOGGLE_VISIBILITY, {
                detail: { assetId: asset.id },
                bubbles: true
            });
            this.container.dispatchEvent(event);
        });

        // Card Interaction
        card.addEventListener('click', () => {
            const event = new CustomEvent(EVENTS.CASH_ASSET_SELECTED, {
                detail: { assetId: asset.id, asset: asset },
                bubbles: true
            });
            this.container.dispatchEvent(event);
        });

        return card;
    }

    /**
     * Generates a consistent color for a string from the custom color pool.
     * @param {String} str 
     * @returns {String} Hex Color
     */
    _getColorForString(str) {
        if (!str) return ASSET_CUSTOM_COLORS[0];

        const seed = AppState.preferences?.colorSeed || 0;

        let hash = seed; // Start hash with seed to shift the output
        for (let i = 0; i < str.length; i++) {
            hash = str.charCodeAt(i) + ((hash << 5) - hash);
        }

        const index = Math.abs(hash) % ASSET_CUSTOM_COLORS.length;
        const c = ASSET_CUSTOM_COLORS[index];
        return c;
    }

    /**
     * Internal helper to calculate border style string based on prefs.
     * Uses the provided asset color instead of a hardcoded default.
     * @param {String} color - The effective color of the asset/card.
     */
    _getBorderStyles(color) {
        const prefs = AppState.preferences.containerBorders;
        if (!prefs || !prefs.sides || prefs.sides.every(s => s === 0)) return '';

        // Fallback if no color provided, though createCashCard should always provide one.
        const borderCol = color || 'var(--color-accent)';
        const t = `${prefs.thickness}px`;
        const s = prefs.sides;

        let shadows = [];
        if (s[0]) shadows.push(`inset 0 ${t} 0 0 ${borderCol}`); // Top
        if (s[1]) shadows.push(`inset -${t} 0 0 0 ${borderCol}`); // Right
        if (s[2]) shadows.push(`inset 0 -${t} 0 0 ${borderCol}`); // Bottom
        if (s[3]) shadows.push(`inset ${t} 0 0 0 ${borderCol}`); // Left

        return shadows.length ? `box-shadow: ${shadows.join(', ')} !important; border-radius: 0 !important;` : '';
    }
}
