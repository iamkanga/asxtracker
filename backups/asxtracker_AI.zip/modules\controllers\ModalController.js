/**
 * ModalController.js
 * Handles interaction logic for opening and managing modals (Add Share, Add Cash, etc).
 * Decouples main controller from specific modal UI orchestration.
 */

import { AppState } from '../state/AppState.js';
import { ShareFormUI } from '../ui/ShareFormUI.js';
import { CashAssetUI } from '../ui/CashAssetUI.js';
import { DataService } from '../data/DataService.js';
import { AppService } from '../data/AppService.js';
import { normalizeComments } from '../data/DataProcessor.js'; // Added
import {
    USER_MESSAGES,
    CASH_WATCHLIST_ID,
    SEARCH_WATCHLIST_ID,
    PORTFOLIO_ID,
    IDS,
    CSS_CLASSES,
    EVENTS
} from '../utils/AppConstants.js';
import { ToastManager } from '../ui/ToastManager.js';





// Instantiate services or allow injection. 
const dataService = new DataService();
const appService = new AppService();

export class ModalController {

    constructor(viewRendererUpdateCallback) {
        this.updateCallback = viewRendererUpdateCallback; // Callback to refresh UI after save
    }

    /**
     * Orchestrates the Cash Asset Modal.
     * @param {string|null} assetId 
     */
    handleOpenCashModal(assetId = null) {
        const asset = assetId ? AppState.data.cash.find(c => c.id === assetId) : null;
        const ui = new CashAssetUI();

        ui.showAddEditModal(asset, async (formData) => {
            await appService.saveCashAsset(formData, assetId);

            // Record historical anchor point for this category
            if (formData.category) {
                const now = Math.floor(Date.now() / 1000);
                const points = AppState.preferences.historicalData?.[formData.category] || [];

                // Add new point (assuming current balance is the new value)
                // Filter out any points within the same minute to avoid spam
                const cleanPoints = points.filter(p => Math.abs(p.time - now) > 60);
                cleanPoints.push({ time: now, val: formData.balance });

                // Keep only last 1000 points to avoid bloating localStorage
                const cappedPoints = cleanPoints.sort((a, b) => a.time - b.time).slice(-1000);
                AppState.saveHistoricalData(formData.category, cappedPoints);
            }

            if (this.updateCallback) await this.updateCallback(false);
        }, async () => {
            if (assetId) {
                await appService.deleteCashCategory(assetId);
                if (this.updateCallback) await this.updateCallback(false);
            }
        });
    }

    /**
     * Orchestrates the Add/Edit Share Modal.
     * @param {string|Object|null} input - If string, edits shareId. If object, pre-fills new share.
     */
    async openAddShareModal(input = null, initialSection = null) {
        // 1. Prepare Watchlists
        const availableWatchlists = (AppState.data.watchlists || [])
            .filter(w => w.id !== CASH_WATCHLIST_ID && w.id !== SEARCH_WATCHLIST_ID);

        const watchlistsForUI = [
            { id: 'portfolio', name: 'Portfolio' },
            ...availableWatchlists
        ];

        // Membership Map: watchlistId -> documentId
        const existingMemberships = new Map();
        let initialData = null;
        let stockCode = null;

        // Determine Mode based on Input Type
        // String or Number (ID) -> Edit Mode
        // Object -> Pre-Fill Mode
        if (input && (typeof input === 'string' || typeof input === 'number')) {
            // EDIT MODE (shareId)
            const inputId = String(input);


            // Loose lookup to handle String/Number mismatch in data
            const targetShare = AppState.data.shares.find(s => String(s.id) === inputId);

            if (!targetShare) {
                console.error('[ModalController] Share NOT found for ID:', inputId);

                ToastManager.error(USER_MESSAGES.SHARE_NOT_FOUND);
                return;
            }

            stockCode = targetShare.shareName;
            initialData = {
                ...targetShare,
                title: targetShare.name || targetShare.title || '',
                comments: normalizeComments(targetShare.comments) // Fix: Normalize legacy comments
            };

            // 1. Find explicit share documents (Legacy & Mixed Schema)
            AppState.data.shares.filter(s => (s.shareName || '').toUpperCase() === (stockCode || '').toUpperCase()).forEach(s => {
                const wId = String(s.watchlistId || 'portfolio');
                if (!existingMemberships.has(wId)) {
                    existingMemberships.set(wId, new Set());
                }
                existingMemberships.get(wId).add(s.id);

                // FIX: Check Array memberships too
                if (Array.isArray(s.watchlistIds)) {
                    s.watchlistIds.forEach(id => {
                        const sId = String(id);
                        if (!existingMemberships.has(sId)) {
                            existingMemberships.set(sId, new Set());
                        }
                        existingMemberships.get(sId).add(s.id);
                    });
                }
            });

            // 2. Find implicit memberships in Watchlist 'stocks' arrays (New Schema)
            (AppState.data.watchlists || []).forEach(wl => {
                if (wl.stocks && Array.isArray(wl.stocks)) {
                    if (wl.stocks.some(code => code.toUpperCase() === stockCode.toUpperCase())) {
                        const wId = String(wl.id);
                        if (!existingMemberships.has(wId)) {
                            // Mark as present with empty set (means no doc ID found yet)
                            existingMemberships.set(wId, new Set());
                        }
                    }
                }
            });
        } else if (typeof input === 'object' && input !== null) {
            // PRE-FILL MODE (New Share or Recovery)
            initialData = input;
            stockCode = input.shareName || input.code; // Robustness

            // FIX: Scan for existing memberships (Ghost Shares) even in Pre-fill Mode
            // This ensures that if we are recovering a share that lost its ID (Ghost),
            // or adding a share that is already in a watchlist array, the boxes are checked.
            if (stockCode) {
                // 1. Find explicit share documents (Legacy & Mixed Schema)
                const matchingShares = AppState.data.shares.filter(s => (s.shareName || '').toUpperCase() === stockCode.toUpperCase());


                matchingShares.forEach(s => {
                    const wId = String(s.watchlistId || 'portfolio');
                    if (!existingMemberships.has(wId)) {
                        existingMemberships.set(wId, new Set());
                    }
                    existingMemberships.get(wId).add(s.id);
                    if (Array.isArray(s.watchlistIds)) {
                        s.watchlistIds.forEach(id => {
                            const sId = String(id);
                            if (!existingMemberships.has(sId)) {
                                existingMemberships.set(sId, new Set());
                            }
                            existingMemberships.get(sId).add(s.id);
                        });
                    }
                });

                // 2. Find implicit memberships in Watchlist 'stocks' arrays (New Schema)
                (AppState.data.watchlists || []).forEach(wl => {
                    if (wl.stocks && Array.isArray(wl.stocks)) {
                        if (wl.stocks.some(code => code.toUpperCase() === stockCode.toUpperCase())) {
                            const wId = String(wl.id);
                            if (!existingMemberships.has(wId)) {
                                existingMemberships.set(wId, new Set());
                            }
                        }
                    }
                });

            } else {
                console.warn('[ModalController] Pre-fill Scan Skipped: No Stock Code');
            }
        }

        const activeWatchlistIds = Array.from(existingMemberships.keys());
        if (activeWatchlistIds.length === 0 && AppState.watchlist.id !== SEARCH_WATCHLIST_ID) {
            activeWatchlistIds.push(AppState.watchlist.id || 'portfolio');
        }

        // 2. Open Modal via View Layer
        ShareFormUI.showShareModal({
            watchlists: watchlistsForUI,
            activeWatchlistIds: activeWatchlistIds,
            shareData: initialData,
            initialSection: initialSection,

            // Callback: Live Price Lookup
            onLookupPrice: async (code) => {
                const result = await dataService.fetchLivePrices([code]);
                const prices = result?.prices;
                return prices?.get ? prices.get(code) : null;
            },

            // Callback: Delete
            onDelete: async (id) => {
                if (confirm(USER_MESSAGES.CONFIRM_DELETE)) {
                    try {
                        // Try to find code from data or default before removing
                        const deletedShare = AppState.data.shares.find(s => s.id === id);
                        const code = deletedShare ? deletedShare.shareName : 'Share';

                        // Optimistically remove from state
                        AppState.data.shares = AppState.data.shares.filter(s => String(s.id) !== String(id));
                        if (this.updateCallback) await this.updateCallback();

                        await appService.deleteShareRecord(null, id);

                        ToastManager.success(`${code} deleted.`);
                        document.querySelector('#add-share-modal .modal-close-btn')?.click();
                    } catch (e) {
                        ToastManager.error(USER_MESSAGES.ERROR_DELETE + e.message);
                    }
                }
            },

            // Callback: Save (SYNC LOGIC)
            onSave: async (formData) => {
                try {
                    const newWatchlists = formData.watchlists || [];
                    const previousWatchlists = Array.from(existingMemberships.keys());

                    const errors = [];
                    let successCount = 0;
                    const updatedDocIds = new Set();

                    // Determine if the share already exists in AppState (Global Lookup)
                    const lookupKey = String(formData.shareName).trim().toUpperCase();

                    // 1. Resolve Target Document ID once before loops (Preserve real ID)
                    let targetDocId = formData.id;
                    if (!targetDocId || targetDocId === 'OPTIMISTIC_LOCK' || String(targetDocId).startsWith('temp_')) {
                        targetDocId = null;
                        const found = AppState.data.shares.find(s => (s.shareName || '').toUpperCase() === lookupKey && s.id && !String(s.id).startsWith('temp_') && s.id !== 'OPTIMISTIC_LOCK');
                        if (found) targetDocId = found.id;
                    }

                    if (!targetDocId) {
                        for (const [, docIds] of existingMemberships) {
                            if (docIds && docIds.size > 0) {
                                for (const dId of docIds) {
                                    if (dId && !String(dId).startsWith('temp_') && dId !== 'OPTIMISTIC_LOCK') {
                                        targetDocId = dId;
                                        break;
                                    }
                                }
                            }
                            if (targetDocId) break;
                        }
                    }

                    // Resolve primary watchlist ID
                    const resolvePersistenceId = (wid) => (wid === PORTFOLIO_ID || wid === 'main') ? PORTFOLIO_ID : wid;
                    let primaryWatchlistId = PORTFOLIO_ID;
                    if (formData.watchlistId && newWatchlists.includes(formData.watchlistId)) {
                        primaryWatchlistId = resolvePersistenceId(formData.watchlistId);
                    } else if (newWatchlists.includes(PORTFOLIO_ID)) {
                        primaryWatchlistId = PORTFOLIO_ID;
                    } else if (newWatchlists.length > 0) {
                        primaryWatchlistId = resolvePersistenceId(newWatchlists[0]);
                    }

                    // Prepare consolidated update payload with all watchlists in a single payload
                    const dataToUpdate = {
                        ...formData,
                        watchlistId: primaryWatchlistId,
                        watchlistIds: newWatchlists
                    };
                    delete dataToUpdate.watchlists;

                    // 1. ADD: New watchlists not in existing
                    const toAdd = newWatchlists.filter(w => !existingMemberships.has(w));
                    for (const wid of toAdd) {
                        if (targetDocId && targetDocId !== 'OPTIMISTIC_LOCK' && !String(targetDocId).startsWith('temp_')) {
                            // PATH A: LINK EXISTING (Updated once across all watchlists)
                            if (!updatedDocIds.has(String(targetDocId))) {
                                try {
                                    // Optimistic local update
                                    const shareToUpdate = AppState.data.shares.find(s => String(s.id) === String(targetDocId));
                                    if (shareToUpdate) {
                                        Object.assign(shareToUpdate, dataToUpdate);
                                    }

                                    await appService.updateShareRecord(targetDocId, dataToUpdate);
                                    updatedDocIds.add(String(targetDocId));
                                    successCount++;
                                } catch (err) {
                                    console.error('Failed to link ' + wid + ':', err);
                                    errors.push(wid);
                                }
                            }
                        } else {
                            // PATH B: CREATE NEW (Master Record)
                            try {
                                const priceData = AppState.livePrices?.get(lookupKey);
                                const entryPrice = priceData ? (parseFloat(priceData.live) || 0) : (parseFloat(formData.enteredPrice) || 0);
                                const purchaseDate = formData.purchaseDate || new Date().toISOString();

                                const dataToAdd = {
                                    ...formData,
                                    code: lookupKey,
                                    shareName: lookupKey,
                                    watchlistId: primaryWatchlistId,
                                    enteredPrice: entryPrice,
                                    purchaseDate: purchaseDate,
                                    entryDate: purchaseDate,
                                    watchlistIds: newWatchlists
                                };
                                delete dataToAdd.watchlists;
                                delete dataToAdd.id;

                                // STRICT OPTIMISM: Inject into State with temp ID IMMEDIATELY
                                const tempId = 'temp_' + Date.now();

                                AppState.data.shares.push({
                                    ...dataToAdd,
                                    id: tempId
                                });
                                if (this.updateCallback) await this.updateCallback(); // Force immediate render

                                const newId = await appService.addBaseShareRecord(dataToAdd);

                                if (!newId) {
                                    throw new Error('Failed to create share record for ' + wid + ' (ID was null)');
                                }

                                // Preserve newly created document ID so subsequent iterations do not create duplicates
                                targetDocId = newId;
                                formData.id = newId;
                                updatedDocIds.add(String(newId));
                                successCount++;

                                // Update TEMP ID with REAL ID
                                let tempShare = AppState.data.shares.find(s => s.id === tempId);
                                if (!tempShare) {
                                    tempShare = AppState.data.shares.find(s => (s.shareName || '').toUpperCase() === lookupKey && !s.id);
                                }

                                if (tempShare) {
                                    tempShare.id = newId;
                                    // POPULATE GUARD: Protect this ID from snapshot overwrites for a few minutes
                                    if (AppState.data.optimisticIds) {
                                        AppState.data.optimisticIds.set(lookupKey, newId);
                                    }

                                    if (this.updateCallback) await this.updateCallback(); // RE-RENDER: Important to update DOM with real ID
                                }
                            } catch (err) {
                                console.error('Failed to create for ' + wid + ':', err);
                                // Rollback temp share
                                AppState.data.shares = AppState.data.shares.filter(s => !String(s.id).startsWith('temp_'));
                                if (this.updateCallback) await this.updateCallback();
                                errors.push(wid);
                            }
                        }
                    }

                    // 2. UPDATE: Watchlists that were already there
                    const toUpdate = newWatchlists.filter(w => existingMemberships.has(w));
                    for (const wid of toUpdate) {
                        const docIds = existingMemberships.get(wid);
                        if (!docIds || docIds.size === 0) {
                            // GHOST RECOVERY IN UPDATE LOOP
                            // The user 'kept' this share in the watchlist, but it has no ID (Ghost).
                            // Only resurrect if no document exists yet and none was created in this save operation.
                            if (!targetDocId && updatedDocIds.size === 0) {
                                try {
                                    const entryPrice = formData.enteredPrice || 0;
                                    const purchaseDate = formData.purchaseDate || new Date().toISOString();

                                    const dataToAdd = {
                                        ...formData,
                                        code: lookupKey,
                                        shareName: lookupKey,
                                        watchlistId: primaryWatchlistId,
                                        enteredPrice: entryPrice,
                                        purchaseDate: purchaseDate,
                                        entryDate: purchaseDate,
                                        watchlistIds: newWatchlists
                                    };
                                    delete dataToAdd.watchlists;
                                    delete dataToAdd.id;

                                    const newId = await appService.addBaseShareRecord(dataToAdd);
                                    if (!newId) throw new Error('Ghost Resurrection failed: ID returned null for ' + formData.shareName);

                                    targetDocId = newId;
                                    formData.id = newId;
                                    updatedDocIds.add(String(newId));
                                    successCount++;

                                    const shareNowInState = AppState.data.shares.find(s => s.id === newId || (s.shareName || '').toUpperCase() === lookupKey);
                                    if (shareNowInState) {
                                        if (!shareNowInState.id) shareNowInState.id = newId;
                                    } else {
                                        AppState.data.shares.push({
                                            shareName: lookupKey,
                                            id: newId,
                                            watchlistId: primaryWatchlistId,
                                            watchlistIds: newWatchlists
                                        });
                                    }
                                } catch (err) {
                                    console.error('Failed to resurrect ghost in ' + wid + ':', err);
                                    errors.push(wid);
                                }
                            }
                            continue;
                        }

                        // Update ALL documents found for this code in this watchlist exactly once
                        for (const docId of docIds) {
                            if (!docId || updatedDocIds.has(String(docId))) {
                                continue;
                            }

                            try {
                                // Optimistic local update
                                const shareToUpdate = AppState.data.shares.find(s => String(s.id) === String(docId));
                                if (shareToUpdate) {
                                    Object.assign(shareToUpdate, dataToUpdate);
                                }

                                await appService.updateShareRecord(docId, dataToUpdate);
                                updatedDocIds.add(String(docId));
                                successCount++;
                            } catch (err) {
                                console.error('Failed to update doc ' + docId + ' in ' + wid + ':', err);
                                errors.push(wid);
                            }
                        }
                    }

                    // 3. REMOVE: Watchlists deselected
                    const toRemove = previousWatchlists.filter(w => !newWatchlists.includes(w));
                    const deletedDocIds = new Set();

                    for (const wid of toRemove) {
                        const docIds = existingMemberships.get(wid);
                        // FIX: Use Original Name for removal if renamed
                        const code = formData.originalShareName || formData.shareName;

                        if (!docIds || docIds.size === 0) {
                            // CASE A: Removing a LINK (Array Entry)
                            try {
                                await appService.removeStock(code, wid);
                            } catch (err) {
                                console.error('Failed to remove link from ' + wid + ':', err);
                                errors.push(wid);
                            }
                        } else {
                            // CASE B: Removing or migrating the share document
                            for (const docId of docIds) {
                                if (!docId) continue;

                                if (newWatchlists.length > 0) {
                                    // MIGRATION: The user kept the share in other watchlists.
                                    // Only update if not already updated in this save operation.
                                    if (!updatedDocIds.has(String(docId))) {
                                        try {
                                            // Optimistic local update
                                            const shareToUpdate = AppState.data.shares.find(s => String(s.id) === String(docId));
                                            if (shareToUpdate) {
                                                Object.assign(shareToUpdate, dataToUpdate);
                                            }

                                            await appService.updateShareRecord(docId, dataToUpdate);
                                            updatedDocIds.add(String(docId));
                                        } catch (err) {
                                            console.error('Failed to migrate share ' + docId + ':', err);
                                            errors.push(wid);
                                        }
                                    }
                                } else {
                                    // DELETION: The user removed it from ALL watchlists.
                                    if (!deletedDocIds.has(String(docId))) {
                                        try {
                                            // Optimistic local update
                                            AppState.data.shares = AppState.data.shares.filter(s => String(s.id) !== String(docId));

                                            await appService.deleteShareRecord(null, docId);
                                            deletedDocIds.add(String(docId));
                                        } catch (err) {
                                            console.error('Failed to delete share ' + docId + ':', err);
                                            errors.push(wid);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (successCount > 0 || (toRemove.length > 0 && errors.length === 0)) {
                        if (this.updateCallback) await this.updateCallback();
                        const code = formData.shareName || 'Share';

                        // Fire Refresh for Details Modal if open (or just Close it to force reload)
                        // Simple "Fix Stale UI" strategy: Close the view modal.
                        const detailsModal = document.getElementById(IDS.STOCK_DETAILS_MODAL);
                        if (detailsModal) detailsModal.remove();

                        ToastManager.success(`${code} saved.`);
                        document.querySelector(`#${IDS.ADD_SHARE_MODAL} .${CSS_CLASSES.MODAL_CLOSE_BTN}`)?.click();
                    }

                    if (errors.length > 0) {
                        ToastManager.error(`${USER_MESSAGES.ERR_PARTIAL_FAILURE}${errors.join(', ')}`);
                    }

                } catch (error) {
                    const msg = error.message || error.toString() || 'Unknown Error';
                    console.error("Save Sync Fatal Error:", msg, error);
                    ToastManager.error(USER_MESSAGES.ERROR_SAVE + msg);
                    throw error;
                }
            }
        });
    }
}
